package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Agustus extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 5 Agustus: Hari Dharma Wanita Nasional",
            "Tanggal 8 Agustus: Hari Ulang Tahun ASEAN",
            "Tanggal 10 Agustus: Hari Veteran Nasional",
            "Tanggal 10 Agustus: Hari Kebangkitan Teknologi Nasional[24]",
            "Tanggal 12 Agustus: Hari Wanita TNI Angkatan Udara (Wara)",
            "Tanggal 13 Agustus: Hari Peringatan Pangkalan Brandan Lautan Api",
            "Tanggal 14 Agustus: Hari Pramuka",
            "Tanggal 17 Agustus: Hari Proklamasi Kemerdekaan Republik Indonesia (sejak tahun 1945)",
            "Tanggal 18 Agustus: Hari Konstitusi Republik Indonesia (sejak tahun 1945)",
            "Tanggal 19 Agustus: Hari Departemen Luar Negeri Indonesia",
            "Tanggal 21 Agustus: Hari Maritim Nasional"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_agustus);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Agustus); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilAgustus.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("agustus", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
