package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.view.View;
import android.widget.AdapterView;
import android.content.Intent;

public class Aplikasi extends AppCompatActivity {
    private ListView listView;//variabel yang menampilkan daftar bulan di activity_aplikasi2
    private ArrayAdapter tampilan_data; //variabel yg akan digunakan untuk mengatur tampilan diuser interface

    //nama-nama bulan yg akan ditampilkan pada listview
    private String[] N_Bulan={
            "Januari","Febuari","Maret","April","Mei","Juni","Juli","Agustus","September","Oktober","November","Desember"
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_aplikasi2);
        getSupportActionBar().setTitle("Pilih Bulan");//mengatur judul

        listView=(ListView) findViewById(R.id.Bulan); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,N_Bulan); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                //Mendapatkan Nama Bulan pada salah satu item yang diklik, berdasarkan posisinya lalu membuka activity bulan
                Intent intent;
                if (position == 0) {
                    intent = new Intent(Aplikasi.this, Januari.class);
                    startActivity(intent);
                } else if (position == 1) {
                    intent = new Intent(Aplikasi.this, Febuari.class);
                    startActivity(intent);
                } else if (position == 2) {
                    intent = new Intent(Aplikasi.this, Maret.class);
                    startActivity(intent);
                } else if (position == 3) {
                    intent = new Intent(Aplikasi.this, April.class);
                    startActivity(intent);
                } else if (position == 4) {
                    intent = new Intent(Aplikasi.this, Mei.class);
                    startActivity(intent);
                } else if (position == 5) {
                    intent = new Intent(Aplikasi.this, Juni.class);
                    startActivity(intent);
                } else if (position == 6) {
                    intent = new Intent(Aplikasi.this, Juli.class);
                    startActivity(intent);
                } else if (position == 7) {
                    intent = new Intent(Aplikasi.this, Agustus.class);
                    startActivity(intent);
                } else if (position == 8) {
                    intent = new Intent(Aplikasi.this, September.class);
                    startActivity(intent);
                } else if (position == 9) {
                    intent = new Intent(Aplikasi.this, Oktober.class);
                    startActivity(intent);
                } else if (position == 10) {
                    intent = new Intent(Aplikasi.this, November.class);
                    startActivity(intent);
                } else if (position == 11) {
                    intent = new Intent(Aplikasi.this, Desember.class);
                    startActivity(intent);
                }
            }
        });
    }
}
