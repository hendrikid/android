package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class April extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal  1 April: Hari Bank Dunia",
            "Tanggal  1 April: Hari Marketing Indonesia (Hamari) [11], Hari Penyiaran Nasional[12]",
            "Tanggal  6 April: Hari Nelayan Nasional",
            "Tanggal  7 April: Hari Kesehatan Internasional",
            "Tanggal  9 April: Hari Penerbangan Nasional[13], Hari TNI Angkatan Udara",
            "Tanggal  12 April: Hari Bawa Bekal Nasional[14]",
            "Tanggal  16 April: Hari Komando Pasukan Khusus (Kopassus)",
            "Tanggal  17 April: Hari Pergerakan Mahasiswa Islam Indonesia PMII",
            "Tanggal  18 April: Hari Peringatan Konferensi Asia Afrika",
            "Tanggal  19 April: Hari Pertahanan Sipil (Hansip)",
            "Tanggal  20 April: Hari Konsumen Nasional[15]",
            "Tanggal  21 April: Hari Kartini",
            "Tanggal  22 April: Hari Bumi",
            "Tanggal  23 April: Hari Buku",
            "Tanggal  24 April: Hari Angkutan Nasional",
            "Tanggal  24 April: Hari Solidaritas Asia-Afrika",
            "Tanggal  26 April: Hari Kesiapsiagaan Bencana Nasional[16]",
            "Tanggal  27 April: Hari Permasyarakatan Indonesia",
            "Tanggal  28 April: Hari Puisi Nasional"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_april);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_April); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilApril.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("april", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
