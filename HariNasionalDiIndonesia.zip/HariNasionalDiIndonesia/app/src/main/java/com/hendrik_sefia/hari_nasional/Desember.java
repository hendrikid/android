package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Desember extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 1 Desember: Hari AIDS Sedunia",
            "Tanggal 3 Desember: Hari Penyandang Cacat Internasional",
            "Tanggal 4 Desember: Hari Artileri",
            "Tanggal 5 Desember: Hari Armada",
            "Tanggal 9 Desember: Hari Anti Korupsi",
            "Tanggal 10 Desember: Hari Hak Asasi Manusia",
            "Tanggal 12 Desember: Hari Transmigrasi",
            "Tanggal 12 Desember: Hari Belanja Online Nasional (Harbolnas)",
            "Tanggal 13 Desember: Hari Nusantara[46]",
            "Tanggal 15 Desember: Hari Infanteri[butuh rujukan]",
            "Tanggal 19 Desember: Hari Bela Negara [47]",
            "Tanggal 20 Desember: Hari Kesetiakawanan Sosial Nasional[48]",
            "Tanggal 22 Desember: Hari Ibu Nasional",
            "Tanggal 22 Desember: Hari Sosial",
            "Tanggal 22 Desember: Hari Korps Wanita Angkatan Darat (KOWAD)",
            "Tanggal 25 Desember: Hari Natal"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_desember);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Desember); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilDesember.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("desember", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
