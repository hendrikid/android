package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Febuari extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 5 Februari: Hari Peristiwa Kapal Tujuh", "Tanggal 5 Februari Hari Lahir Himpunan Mahasiswa Islam (HMI)", "Tanggal 9 Februari: Hari Kavaleri",
            "Tanggal 9 Februari: Hari Pers Nasional",
            "Tanggal 14 Februari: Hari Peringatan Pembela Tanah Air (PETA)",
            "Tanggal 14 Februari: Hari Kasih Sayang Sedunia",
            "Tanggal 20 Februari: Hari Pekerja Indonesia[7]",
            "Tanggal 21 Februari: Hari Bahasa Ibu",
            "Tanggal 21 Februari: Hari Peduli Sampah Nasional",
            "Tanggal 22 Februari: Hari Istiqlal",
            "Tanggal 24 Februari: Hari lahir Ikatan Pelajar Nahdlatul Ulama"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_febuari);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Febuari); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilFebuari.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("febuari", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
