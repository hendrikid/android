package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilAgustus extends AppCompatActivity {
    String AGUSTUS;
    TextView infoBulan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_agustus);
        // ambil textview info di acivity
        infoBulan=(TextView) findViewById(R.id.info_agustus);

        // ambil parameter dari intent
        Intent intent = getIntent();
        AGUSTUS = intent.getStringExtra("agustus");

        // panggil
        setAGUSTUS(AGUSTUS);
    }
    private void setAGUSTUS(String tanggal) {
        if(tanggal.equalsIgnoreCase("Tanggal 5 Agustus: Hari Dharma Wanita Nasional")){
            infoBulan.setText(" Pada tanggal 5 Agustus 1974, terdapat sebuah peristiwa penting yaitu lahirnya Hari Dharma Wanita Nasional. Dharma wanita merupakan sebuah organisasi kumpulan para istri Pegawai Republik Indonesia yang mencakul PNS maupun ABRI yang dibentuk pada masa pemerintahan Orde Baru.  \n" +
                    "Pada saat itu yang mendirikan Dharma Wanita adalah Amir Machmud yang menjabat sebagai Ketua Dewan Pembina KORPRI dengan izin dari Ibu Tien Soeharto yang saat itu menjabat sebagai Ibu Negara. Pada mulanya, Dharma wanita ini didirikan dengan adanya muatan politik dari pemerintah. Namun, sejak masa reformasi Dharma wanita pun menjadi oragnisasi yang netral dan juga demokratis. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 8 Agustus: Hari Ulang Tahun ASEAN")){
            infoBulan.setText("HARI Ulang Tahun ASEAN Sedunia diperingati pada 08 Agustus setiap tahunnya. Peringatan Hari Ulang Tahun ASEAN kali ini bertepatan dengan Hari Raya Idul Fitri 1434 H yaitu satu hari yang penting dalam kalender umat Muslim. ASEAN adalah organisasi antar negara yang berada di kawasan Asia Tenggara.\n" +
                    "\n" +
                    "Lima negara dari negara-negara Asia Tenggara, yaitu Indonesia, Singapura, Malaysia, Filipina dan Thailand mengadakan pertemuan (Konferensi) Pada 05 Agustus 1967 di Bangkok. Konferensi tersebut menghasilkan suatu persetujuan yang disebut dengan Persetujuan Bangkok pada 08 Agustus 1967.\n" +
                    "\n" +
                    "“Tema tahun ini, Rakyat Kita, Masa Depan Kita Bersama, kami menekankan peran rakyat dalam upaya pembangunan komunitas ASEAN dan mempersiapkan pasca 015. Berbagai program dikelola bagi kaum muda, kami mempersiapkan mereka dengan atribut dan nilai-nilai yang diperlukan untuk menghadapi tantangan hari esok,” kata pemimpin Brunei Darussalam, Sultan Hasanal Bolkiah, yang tahun ini menjadi Ketua Bergilir ASEAN. “Kepada seluruh umat Muslim ASEAN, saya mengucapkan selamat hari raya Idul Fitri,” tambah Sultan.\n" +
                    "\n" +
                    "Sekretaris Jenderal ASEAN Le Luong Minh juga menyebut bahwa pada saat ini, ASEAN benar-benar focus pada pembangunan masyarakat menjadi sebuah komunitas yang bersama-sama menata masa depan.\n" +
                    "\n" +
                    "“Hari ASEAN mengingatkan kita pada mimpi yang kini akan menjadi kenyataan,” kata Le Luong Minh dalam sambutannya. Sekretariat ASEAN memindahkan acara perayaan hari ulang tahun (HUT) menjadi tanggal 23 Agustus mendatang.\n" +
                    "\n" +
                    "Di beberapa negara seperti Thailand, yang tidak terlalu terpengaruh pada perayaan Idul Fitri, Kementerian Luar Negeri menyelenggarakan ASEAN Quiz, Pameran ASEAN yang juga menampilkan pemenang kompetisi melukis ASEAN. Mereka juga menggelar seminar “Komunitas ASEAN, Satu Visi, Multikulturalisme, dan bagaimana kita bisa hidup bersama?”\n" +
                    "\n" +
                    "Di Myanmar, Presiden dan Wakil Presiden menyampaikan ucapan selamat.  Pada acara resmi juga diserahkan hadiah kepada para pemenang kompetisi menulis esai ASEAN oleh Menteri Pendidikan dan Menteri Luar Negeri Myanmar. Myanmar akan menjadi Ketua ASEAN tahun depan.\n" +
                    "\n" +
                    "Hal serupa juga diselenggarakan di Filipina. Beberapa sekolah bahkan mengadakan aktivitas tersendiri. Vietnam, Laos, Kamboja mengadakan upacara pengibaran bendera ASEAN.  Sementara Singapura akan menyelenggarakan Hari ASEAN pada 15 Agustus. Hari ulang tahun ASEAN bertepatan juga dengan Hari Kemerdekaan Singapura.\n" +
                    "\n" +
                    "Hari Ulang Tahun ASEAN merupakan salah satu hari bagi organisasi yang ada di Asia tenggara dan indonesia pun ikut di dalamnya, dengan adanya organisasi ini maka Indonesia pun mendapatkan banyak sekali manfaat berupa nyamannya melakukan berbagai kerjasama di bidang politik, ekonomi dan budaya.\n" +
                    "\n" +
                    "|Sumber: www.tempo.com dan beberapa sumber lainnya.\n" +
                    "Tags: Fakultas Ekonomi, Fakultas Hukum, hari ulang tahun ASEAN Nasional, Ragam, Universitas Malahayati");
        }else if(tanggal.equalsIgnoreCase("Tanggal 10 Agustus: Hari Veteran Nasional")){
            infoBulan.setText("Veteran (dari bahasa Latin vetus, tua) ialah orang yang pernah memiliki pengalaman di bidang militer (tempur) ataupun penegakan hukum (kepolisian).\n" +
                    "\n" +
                    "Veteran Republik Indonesia[1] adalah warga negara Indonesia yang bergabung dalam kesatuan bersenjata resmi yang diakui oleh pemerintah yang berperan secara aktif dalam suatu peperangan menghadapi negara lain dan/atau gugur dalam pertempuran untuk membela dan mempertahankan kedaulatan Negara Kesatuan Republik Indonesia, atau warga negara Indonesia yang ikut serta secara aktif dalam pasukan internasional di bawah mandat Perserikatan Bangsa-Bangsa untuk melaksanakan misi perdamaian dunia,yang telah ditetapkan sebagai penerima Tanda Kehormatan Veteran Republik Indonesia.\n" +
                    "\n" +
                    "Pemberian Tanda Kehormatan Veteran Republik Indonesia sebagai penghargaan dan penghormatan negara yang diberikan oleh Presiden kepada warga negara Indonesia yang telah berjuang, membela, dan mempertahankan kedaulatan Negara Kesatuan Republik Indonesia dan/atau ikut melaksanakan perdamaian dunia.\n" +
                    "\n" +
                    "Presiden Republik Indonesia menetapkan tanggal 10 Agustus sebagai Hari Veteran Nasional[2] dan dinyatakan bukan hari libur. Peringatan Hari veteran Nasional dimaksudkan untuk mengenang gencatan senjata pada tanggal 10 Agustus 1949 setelah para Pejuang Kemerdekaan Republik Indonesia melawan Tentara Belanda.\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 10 Agustus: Hari Kebangkitan Teknologi Nasional[24]")){
            infoBulan.setText("Hi Feders, ternyata setiap tanggal 10 Agustus itu sebagai hari #specialmoment, karena 10 Agustus ditetapkan sebagai Hari Kebangkitan Teknologi Nasional atau disingkat Hakteknas.\n" +
                    "\n" +
                    "Hakteknas merupakan salah satu hari bersejarah nasional yang diperingati setiap tanggal 10 Agustus. Peringatan ini pertama kali diadakan pada tahun 1995  berdasarkan Keputusan Presiden Republik Indonesia Nomor 71 Tahun 1995.\n" +
                    "\n" +
                    "Hari itu bisa disebut sebagai hari terlahirnya tonggak sejarah kebangkitan teknologi di Indonesia yang ditandai dengan penerbangan perdana pesawat N-250 Gatotkaca di Bandung. Pesawat N-250 yang merupakan pesawat hasil rakitan bangsa sendiri di bawah prakarsa Bapak BJ Habibie.\n" +
                    "\n" +
                    "Seiring berjalannya waktu, perkembangan teknologi terus berkembang, tidak hanya teknologi digital, tapi juga pada industri otomotif.\n" +
                    "\n" +
                    "Di dunia otomotif untuk roda dua maupun roda empat kita tahu teknologi injeksi, ada juga Anti-lock Braking System (ABS).\n" +
                    "\n" +
                    "Teknologi tidak hanya diterapkan pada kendaraan saja lho feders, tapi bisa juga untuk membuat pelumas, karena untuk membuat pelumas tidak bisa sembarangan.\n" +
                    "\n" +
                    "Seperti pelumas federal oil yang memiliki teknologi yang mengandung Wear Protection Technology, yang mampu menjaga mesin tetap awet, tetap stabil dipakai mesin kerja berat,tidak mudah menguap dan suara mesin lebih halus. (Federaloil.co.id )");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 Agustus: Hari Wanita TNI Angkatan Udara (Wara)")){
            infoBulan.setText("Wanita Angkatan Udara (disingkat Wara) adalah sebutan untuk prajurit wanita TNI Angkatan Udara. Wara dibentuk pada tanggal 12 Agustus 1962 dengan tujuan agar kaum wanita dapat menjadi anggota TNI-AU seperti layaknya kaum pria. Kini, sudah cukup banyak perwira tinggi TNI-AU berasal dari kalangan Wara. \n" + "\n" + "Latar belakang pembentukan\n" +
                    "\n" +
                    "Pasca Proklamasi Kemerdekaan Rl, peran serta kaum wanitra dalam perjuangan bangsa lndonesia tidak dapat diabaikan begitu saja. Berbekal semangat juang tokoh-tokoh wanita lndonesia pada era perjuangan merebut kemerdekaan, maka keberadaan kaum wanita pada masa perang kemerdekaan semakin nyata, mereka tidak tinggal diam melainkan ikut serta berjuang mengusir penjajah dari bumi Indonesia.\n" +
                    "\n" +
                    "Untuk merealisasikan cita-cita Kartinidan didorong oleh semangat juang dalam mengabdikan dirinya kepada bangsa dan negara. Pada masa perang kemerdekaan, kaum wanita ikut berjuang di beberapa pangkalan AURI, antara lain di yogyakarta dan Bukittinggi. Mereka bertugas di bidang kesehatan, administrasi, penerangan, pelipat payung, PLLU, PHB dan dapur umum. para pejuang wanita inilah yang kemudian menjadi cikal bakal Wanita Angkatan Udara.\n" +
                    "\n" +
                    "Bertitik tolak dari kenyataan tersebut dan untuk mewadahi peran serta kaum wanita dalam perjuangan AURI, maka pada tahun 1962, Deputy Menteri/Panglima Angkatan Udara Urusan Administrasi Laksamana Muda Udara Suharnoko Harbani mendapat'tugas dan wewenang dari pimpinan TNI Angkatan Udara untuk membentuk Wanita Angkatan Udara (Wara), yang direalisasikan melalui pembukaan pendidikan Wara Pertama pada tanggal 10 Juni 1963 di Kaliurang yang berlokasi di lereng pegunungan Plawangan, Yogyakarta, dengan kepala sekolah Letnan Kolonel Penerbang Sumitro. Pendidikan diikuti oleh 30 orang wanita lulusan sarjana dan sarjana muda dari berbagai jurusan. Mereka mengikuti Pendidikan Dasar Militer selama tiga bulan di Lanuma Adisutjipto, dan dilantik menjadi Perwira Wanita Angkatan Udara Angkatan Pertama pada tanggal 12 Agustus 1963. Sejalan dengan pembentukan Wara, saat itu diputuskan pula bahwa Wara bukan merupakan korps tersendiri, tetapi diintegrasikan dalam korps yang berlaku di lingkungan TNI Angkatan Udara sama dengan anggota militer lainnya.\n" +
                    "\n" +
                    "Sejak tahun 1975, pendidikan Penrvira Wara dilaksanakan di Pusat Pendidikan Korps Wanita Angkatan Darat (Pusdikowad) Lembang bersama korps wanita TNI lainnya. Seiring dengan perkembangan organisasi, pendidikan Wara berikutnya memberikan kesempatan kepada lulusan SLTA untuk dididik menjadi seorang Bintara Wara. Sejalan dengan perkembangan TNI Angkatan Udara, perjalanan Wara terus berkembang. Pelaksanaan tugas yang memerlukan keahlian khusus tidak lagi merupakan monopoli kaum pria, seperti penerbang, teknisi maupun peterjun, tetapi menyertakan anggota Wara yang berpotensi.\n" +
                    "\n" +
                    "Wara boleh berbangga hati, karena tahun 1964 dua anggota Wara tetah dididik untuk menjadi penerbang TNI AU yang pertama, dengan meraih Wing Penerbang Kelas lll, yaitu Letnan Dua Lulu Lugiarti dan Letnan Dua Herdani, mereka juga menjadi penerbang militer pertama di lingkungan korps wanita TNl. Kemudian tahun 1982, TNI Angkatan Udara mencetak kembali penerbang wanita yang berasal dari Bintara Wara yaitu Sertu Hermuntarsih dan Serda Sulastri Baso. Mereka dididik bersama para penerbang pria. Kemudian tahun 1985, kembali mencetak penerbang Wara dari bintara; Serda Veronika Tig, Serda Hendrika, Serda Martini, Serda lnana Musailimah dan Serda Ratih. Setelah 22 tahun berselang, tepatnya pada 2007 TNI Angkatan Udara mencetak dua penerbang Wara atas nama Serda Sekti Ambarwati dan Serda Fariana Dewi. Kedua penerbang yang saat ini berpangkat Kapten Penerbang berdinas di Skadron Udara 2 Lanud Halim dan Skadron Udara 7 Lanud Suryadarma.\n" +
                    "\n" +
                    "Tahun 1990, pimpinan TNI Angkatan Udara mulai memberikan kesempatan bagi Wara untuk mengikuti pendidikan olah raga terjun payung, dan terbang layang. Prestasi Wara dalam bidang olah raga semakin meningkat, dan tidak hanya olahraga dirgantara namun olahraga lainnya berhasil mengukir prestasi yang membanggakan. Cabang olahraga yang berhasil meraih beberapa medali emas dan perak adalah; terjun payung, terbang layang, menembak, tinju, bola voli, tenis lapangan dan Yongmudo. Kemudian pada tahun 2013, dilaksanakan rekrutmen wanita-wanita pilihan untuk dididik menjadi taruni sebagai calon-calon pemimpin TNI/TNI Angkatan Udara masa mendatang, mereka dididik di Akademi Angkatan Udara bersama-sama dengan taruna-taruna lainnya, dan pada tanggal 25 Juli 2017 sebanyak 12 taruni dilantik menjadi letnan dua oleh Presiden Rl di lstana Merdeka Jakarta.\n" +
                    "\n" +
                    "Selama kurun waktu 54 tahun, TNI Angkatan Udara telah memiliki prajurit Wara sebanyak 1710 personel baik perwira maupun bintara. Dengan motto \"Kanya Bhakti Sakti Sejati\", yang berarti prajurit wanita yang mengabdikan diri kepada bangsa dan negara dengan keahlian dan kemahiran yang dimilikinya, memotivasi Wara agar selalu mengasah diri untuk dapat meraih kesempatan lebih luas lagi. Oleh karena itu, tidaklah mengherankan bila anggota Wara pernah dipercaya menduduki jabatan strategis seperti Komandan Pangkalan dan dilibatkan dalam operasi untuk mendukung misi perdamaian dunia, bahkan sudah ada yang meraih pangkat Marsekal Pertama sebanyak sebelas personel.\n" +
                    "\n" +
                    "Selain itu, penempatan anggota Wara dalam mengisi kebutuhan organisasi TNI Angkatan Udara terus berkembang, meliputi semua bidang, baik di bidang staf operasi, personel, kesehatan, pendidikan maupun logistik, dan pramugari. Demikian pula dalam bidang penugasan lainnya, personel Wara tidak hanya bertugas dijajaran TNI Angkatan Udara, tetapi juga di instansi Kemhan/Mabes TNl. Disamping itu, beberapa anggota Wara juga pernah menjadi anggota DPR pusat maupun daerah, dan sampai saat ini Wara tetap menjalin kerja sama dengan korps wanita angkatan lain. Sedangkan dalam bidang pendidikan, berbagaijenjang pendidikan, baik dalam lingkungan TNI Angkatan Udara maupun luar negeri, telah diikuti anggota Wara dengan baik. Keberhasilan Wara dalam mengemban tugasnya tidak hanya memberikan sumbangan positif bagi keberhasilan pelaksanaan tugas-tugas TNI Angkatan Udara, akan tetapi juga merupakan salah satu bukti keberhasilan perjuangan kaum wanita lndonesia. Semoga Wanita TNI Angkatan Udara (Wara), tetap menjadi srikandi kebanggaan Angkatan Udara khususnya, bangsa dan negara pada umumnya. Latar belakang pembentukan\n" +
                    "\n" +
                    "Pasca Proklamasi Kemerdekaan Rl, peran serta kaum wanitra dalam perjuangan bangsa lndonesia tidak dapat diabaikan begitu saja. Berbekal semangat juang tokoh-tokoh wanita lndonesia pada era perjuangan merebut kemerdekaan, maka keberadaan kaum wanita pada masa perang kemerdekaan semakin nyata, mereka tidak tinggal diam melainkan ikut serta berjuang mengusir penjajah dari bumi Indonesia.\n" +
                    "\n" +
                    "Untuk merealisasikan cita-cita Kartinidan didorong oleh semangat juang dalam mengabdikan dirinya kepada bangsa dan negara. Pada masa perang kemerdekaan, kaum wanita ikut berjuang di beberapa pangkalan AURI, antara lain di yogyakarta dan Bukittinggi. Mereka bertugas di bidang kesehatan, administrasi, penerangan, pelipat payung, PLLU, PHB dan dapur umum. para pejuang wanita inilah yang kemudian menjadi cikal bakal Wanita Angkatan Udara.\n" +
                    "\n" +
                    "Bertitik tolak dari kenyataan tersebut dan untuk mewadahi peran serta kaum wanita dalam perjuangan AURI, maka pada tahun 1962, Deputy Menteri/Panglima Angkatan Udara Urusan Administrasi Laksamana Muda Udara Suharnoko Harbani mendapat'tugas dan wewenang dari pimpinan TNI Angkatan Udara untuk membentuk Wanita Angkatan Udara (Wara), yang direalisasikan melalui pembukaan pendidikan Wara Pertama pada tanggal 10 Juni 1963 di Kaliurang yang berlokasi di lereng pegunungan Plawangan, Yogyakarta, dengan kepala sekolah Letnan Kolonel Penerbang Sumitro. Pendidikan diikuti oleh 30 orang wanita lulusan sarjana dan sarjana muda dari berbagai jurusan. Mereka mengikuti Pendidikan Dasar Militer selama tiga bulan di Lanuma Adisutjipto, dan dilantik menjadi Perwira Wanita Angkatan Udara Angkatan Pertama pada tanggal 12 Agustus 1963. Sejalan dengan pembentukan Wara, saat itu diputuskan pula bahwa Wara bukan merupakan korps tersendiri, tetapi diintegrasikan dalam korps yang berlaku di lingkungan TNI Angkatan Udara sama dengan anggota militer lainnya.\n" +
                    "\n" +
                    "Sejak tahun 1975, pendidikan Penrvira Wara dilaksanakan di Pusat Pendidikan Korps Wanita Angkatan Darat (Pusdikowad) Lembang bersama korps wanita TNI lainnya. Seiring dengan perkembangan organisasi, pendidikan Wara berikutnya memberikan kesempatan kepada lulusan SLTA untuk dididik menjadi seorang Bintara Wara. Sejalan dengan perkembangan TNI Angkatan Udara, perjalanan Wara terus berkembang. Pelaksanaan tugas yang memerlukan keahlian khusus tidak lagi merupakan monopoli kaum pria, seperti penerbang, teknisi maupun peterjun, tetapi menyertakan anggota Wara yang berpotensi.\n" +
                    "\n" +
                    "Wara boleh berbangga hati, karena tahun 1964 dua anggota Wara tetah dididik untuk menjadi penerbang TNI AU yang pertama, dengan meraih Wing Penerbang Kelas lll, yaitu Letnan Dua Lulu Lugiarti dan Letnan Dua Herdani, mereka juga menjadi penerbang militer pertama di lingkungan korps wanita TNl. Kemudian tahun 1982, TNI Angkatan Udara mencetak kembali penerbang wanita yang berasal dari Bintara Wara yaitu Sertu Hermuntarsih dan Serda Sulastri Baso. Mereka dididik bersama para penerbang pria. Kemudian tahun 1985, kembali mencetak penerbang Wara dari bintara; Serda Veronika Tig, Serda Hendrika, Serda Martini, Serda lnana Musailimah dan Serda Ratih. Setelah 22 tahun berselang, tepatnya pada 2007 TNI Angkatan Udara mencetak dua penerbang Wara atas nama Serda Sekti Ambarwati dan Serda Fariana Dewi. Kedua penerbang yang saat ini berpangkat Kapten Penerbang berdinas di Skadron Udara 2 Lanud Halim dan Skadron Udara 7 Lanud Suryadarma.\n" +
                    "\n" +
                    "Tahun 1990, pimpinan TNI Angkatan Udara mulai memberikan kesempatan bagi Wara untuk mengikuti pendidikan olah raga terjun payung, dan terbang layang. Prestasi Wara dalam bidang olah raga semakin meningkat, dan tidak hanya olahraga dirgantara namun olahraga lainnya berhasil mengukir prestasi yang membanggakan. Cabang olahraga yang berhasil meraih beberapa medali emas dan perak adalah; terjun payung, terbang layang, menembak, tinju, bola voli, tenis lapangan dan Yongmudo. Kemudian pada tahun 2013, dilaksanakan rekrutmen wanita-wanita pilihan untuk dididik menjadi taruni sebagai calon-calon pemimpin TNI/TNI Angkatan Udara masa mendatang, mereka dididik di Akademi Angkatan Udara bersama-sama dengan taruna-taruna lainnya, dan pada tanggal 25 Juli 2017 sebanyak 12 taruni dilantik menjadi letnan dua oleh Presiden Rl di lstana Merdeka Jakarta.\n" +
                    "\n" +
                    "Selama kurun waktu 54 tahun, TNI Angkatan Udara telah memiliki prajurit Wara sebanyak 1710 personel baik perwira maupun bintara. Dengan motto \"Kanya Bhakti Sakti Sejati\", yang berarti prajurit wanita yang mengabdikan diri kepada bangsa dan negara dengan keahlian dan kemahiran yang dimilikinya, memotivasi Wara agar selalu mengasah diri untuk dapat meraih kesempatan lebih luas lagi. Oleh karena itu, tidaklah mengherankan bila anggota Wara pernah dipercaya menduduki jabatan strategis seperti Komandan Pangkalan dan dilibatkan dalam operasi untuk mendukung misi perdamaian dunia, bahkan sudah ada yang meraih pangkat Marsekal Pertama sebanyak sebelas personel.\n" +
                    "\n" +
                    "Selain itu, penempatan anggota Wara dalam mengisi kebutuhan organisasi TNI Angkatan Udara terus berkembang, meliputi semua bidang, baik di bidang staf operasi, personel, kesehatan, pendidikan maupun logistik, dan pramugari. Demikian pula dalam bidang penugasan lainnya, personel Wara tidak hanya bertugas dijajaran TNI Angkatan Udara, tetapi juga di instansi Kemhan/Mabes TNl. Disamping itu, beberapa anggota Wara juga pernah menjadi anggota DPR pusat maupun daerah, dan sampai saat ini Wara tetap menjalin kerja sama dengan korps wanita angkatan lain. Sedangkan dalam bidang pendidikan, berbagaijenjang pendidikan, baik dalam lingkungan TNI Angkatan Udara maupun luar negeri, telah diikuti anggota Wara dengan baik. Keberhasilan Wara dalam mengemban tugasnya tidak hanya memberikan sumbangan positif bagi keberhasilan pelaksanaan tugas-tugas TNI Angkatan Udara, akan tetapi juga merupakan salah satu bukti keberhasilan perjuangan kaum wanita lndonesia. Semoga Wanita TNI Angkatan Udara (Wara), tetap menjadi srikandi kebanggaan Angkatan Udara khususnya, bangsa dan negara pada umumnya. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 13 Agustus: Hari Peringatan Pangkalan Brandan Lautan Api")){
            infoBulan.setText("KOMPAS.com - Tak hanya Bandung yang terkenal dengan istilah \"Lautan Api\". Pangkalan Brandan, yang berada di Kabupaten Langkat, Sumatera Utara, juga punya julukan ini. Pada masa Hindia Belanda, Pangkalan Brandan terkenal sebagai salah satu ladang minyak tertua di Indonesia. Hari ini 71 tahun lalu, tepatnya 13 Agustus 1947, seluruh instalasi dan fasilitas industri perminyakan di Pangkalan Brandan dibakar. Peristiwa ini kemudian diperingati sebagai \"Pangkalan Brandan Lautan Api\". Sejarah pangkalan minyak di Pangkalan Brandan Sejarah awal pengeboran sumur minyak di Indonesia dilakukan sejak zaman penjajahan Belanda. Pada 1871, pengeboran sumur minyak pertama dilakukan di Cirebon. Namun, sumur produksi pertama adalah sumur Telaga Said di wilayah Sumatera Utara yang dibor pada 1883, kemudian disusul Royal Dutch Company di Pangkalan Brandan pada 1885. Sejak itu, kegiatan eksploitasi minyak di Indonesia dimulai. Hasil eksplorasinya digunakan untuk kepentingan pihak Belanda. Pada 1892, kilang minyak Royal Dutch di Pangkalan Brandan yang menjalankan usaha eksploitasi mulai melakukan produksi massal. Sebagai bahan yang merupakan sumber energi bagi perekonomian dan mesin untuk perang, minyak menjadi sasaran empuk bagi kedua pihak yang berseturu. Pada 1940-an, Pemerintah Hindia Belanda tak mampu menahan serangan Jepang yang melakukan invasi ke Indonesia. Akhirnya, Jepang mengambil alih kekuasaan Belanda atas Indonesia pada waktu itu. Berbagai proyek yang ada di Indonesia dengan cepat dikuasai Jepang, untuk membantu perekenomian penjajah, termasuk menguasai industri minyak di Pangkalan Brandan. Setelah berhasil dikuasai, Jepang melakukan perbaikan lapangan dan kilang minyak menggunakan Romusha dan pekerja yang dulunya telah bekerja di sini. Upaya tersebut digunakan Jepang untuk membantu kepentingan militernya. Dengan mempekerjakan Romusha, kapasitas produksi dari 30 ton per hari bisa menjadi 10.000 ton per hari. Keberhasilan Jepang membangun kilang minyak menjadi perhatian pihak Sekutu, yang kemudian menjatuhkan bom Little Boy dan Fat Man di Hiroshima dan Nagasaki. Peristiwa pengeboman ini akhirnya membuat Jepang menyerah kepada Sekutu. Setelah Jepang menyerah, pekerja dan rakyat yang berada di sekitar Pangkalan Brandan ingin menduduki kilang tersebut. Aksi ini mendapatkan tentangan keras dari Jepang. Akhirnya, pihak pekerja menguasai kilang setelah mendapatkan dukungan sepenuhnya dari Komite Nasional Indonesia Teluk Haru dari Barisan Pemuda Indonesia. Kilang minyak yang dikuasai ini berubah nama menjadi Perusahaan Tambang Minyak Negara Republik Indonesia (PTMNRI) yang merupakan cikal bakal PT PERTAMINA (PERSERO). Pergantian nama yang dilakukan sepihak menjadikan pekerja yang berasal dari Jepang tak bisa berbuat apa-apa, mengingat posisi mereka yang tidak menguntungkan. Di bawah Pemerintah Indonesia Pada Juli 1947, Belanda melakukan Agresi Militer ke berbagai wilayah di Indonesia. Langkah ini merupakan usahanya untuk kembali menguasai Indonesia. Perusahaan tambang minyak juga menjadi sasaran Belanda, salah satunya adalah Pangkalan Brandan. Pasukan Belanda melakukan penyerangan ke berbagai daerah yang dianggapnya vital. Akhirnya, pimpinan Tentara Republik Indonesia (TRI) yang berada di Kabupaten Langkat berencana membumihanguskan seluruh instalasi industri perminyakan berikut objek-objek vital lainnya. Pada 13 Agustus 1947, terjadi pembumihangusan seluruh instalasi dan fasilitas industri perminyakan di Pangkalan Brandan. Peristiwa ini diawali dengan meledakkan tanki-tanki besar, pondasi penyulingan, dan gedung-gedung perusahaan tambang minyak, dan selanjutnya Pangkalan Brandan. Akibat peristiwa ini, Pangkalan Brandan beserta industrinya luluh lantak dan terbakar sehingga sistem ekplorasi yang biasanya berjalan akhirnya berhenti total.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Hari Ini dalam Sejarah: Pangkalan Brandan Lautan Api\", https://nasional.kompas.com/read/2018/08/13/13075751/hari-ini-dalam-sejarah-pangkalan-brandan-lautan-api?page=all.\n" +
                    "Penulis : Aswab Nanda Pratama\n" +
                    "Editor : Inggried Dwi Wedhaswary");
        }else if(tanggal.equalsIgnoreCase("Tanggal 14 Agustus: Hari Pramuka")){
            infoBulan.setText("Liputan6.com, Jakarta - Setiap tanggal 14 Agustus, diperingati sebagai Hari Pramuka, atau disebut dengan Praja Muda Karana. Pada hari ini, Rabu (14/8/2019), para Pramuka di Tanah Air memperingati hari jadinya yang ke-58.\n" +
                    "\n" +
                    "Biasanya, pihak sekolah memeriahkan perayaan Hari Pramuka setiap tahunnya dengan melakukan upacara bendera. Pramuka sendiri merupakan sebuah kegiatan Pendidikan non-formal untuk mengembangkan ketangkasan dan pembentukan karakter. Lalu, kenapa tanggal 14 Agustus diperingati sebagai Hari Pramuka di Indonesia?\n" +
                    "\n" +
                    "Baca Juga\n" +
                    "\n" +
                    "    Selamat Hari Pramuka Puncaki Trending Topic di Twitter\n" +
                    "    Sederet Koleksi Sepatu Bot Agnez Mo yang Bisa Menguras Isi Kantong\n" +
                    "    Kenal Sejak SMA, Manisnya 40 Tahun Persahabatan Menlu Retno Marsudi dan Sri Mulyani\n" +
                    "\n" +
                    "Dilansir dari RRI Voice of Indonesia, Pramuka sudah ada sejak abad 20 dan baru diresmikan pada 1961 di Indonesia. Gerakan pramuka di Indonesia biasa diikuti oleh para siswa tingkat SD sampai SMA dengan penggolongan, Sianga, Penggalang dan Penegak.\n" +
                    "\n" +
                    "Sejarah pramuka tentu tak lepas dengan peran Boden Powell yang diakui sebagai bapak Pandu sedunia. Dia dikenal sebagai pemrakarsa gerakan pramuka di abad ke-20.\n" +
                    "\n" +
                    "Sedangkan di Indonesia gerakan pramuka justru diinisiasi oleh sejumlah organisasi yang telah dibentuk pada masa kemerdekaan yang diperkuat oleh Sumpah Pemuda pada 1928.\n" +
                    "\n" +
                    "Banyaknya organisasi kepanduan Indonesia membuat dibentuklah Persaudaraan Antara Pandu Indonesia (PAPI) pada 23 Mei 1928, yang mewadahi organisasi-organisasi tersebut.  Namun pada masa penjajahan Jepang, gerakan kepanduan sempat dilarang untuk bediri.\n" +
                    "2 dari 3 halaman\n" +
                    "Satu Wadah Organisasi Kepanduan\n" +
                    "Jokowi Lepas Kontingen Pramuka ke Virginia\n" +
                    "Presiden Joko Widodo (kanan) menyalami Kontingen Gerakan Pramuka Indonesia saat upacara pelepasan di Istana Negara, Jakarta, Jumat (19/7/2019). Kontingen Gerakan Pramuka Indonesia mengirimkan 67 peserta untuk menghadiri Jambore Pramuka Dunia XXIV. (Liputan6.com/Angga Yuniar)\n" +
                    "\n" +
                    "Usai proklamasi kemerdekaan, barulah tokoh kepanduan Indonesia membentuk Panitia Kesatuan Kepanduan Indonesia untuk pembentukan satu wadah organisasi kepanduan di Indonesia.\n" +
                    "\n" +
                    "Setelah itu digelar Kongres Kesatuan Kepanduan Indonesia pada 27-29 Desember 1945 di Surakarta yang mengahasilkan terbentuknya Pandu Rakyat Indonesia.\n" +
                    "\n" +
                    "Organisasi tersebut diakui pemerintah sebagai satu-satunya organisasi kepanduan lewat keputusan Menteri Pendidikan, Pengajaran dan Kebudayaan pada 1 Februari 1947. Kemudian pada 1961, Gerakan Pramuka akhirnya terbentuk dengan latar belakang banyaknya organisasi kepanduan di Indonesia.\n" +
                    "\n" +
                    "Pada 14 Agustus 1961 dilakukan pelantikan Mapinas (Majelis Pimpinan Nasional), Kwarnas (Kwartir Nasional) dan Kwarnari (Kwartir Nasional Harian) di Istana Negara di Jakarta, serta penganugerahan Panji-Panji Gerakan Pramuka. \n" +
                    "\n" +
                    "Saat itu Presiden Soekarno menyampaikan anugerah tanda penghargaan dan kehormatan berupa Panji Gerakan Kepanduan Nasional Indonesia yang diserahkan kepada Ketua Kwartir Nasional, Sri Sultan Hamengku Buwono IX.\n" +
                    "\n" +
                    "Setelah itu, setiap 14 Agustus diperingati sebagai Hari Pramuka di Indonesia. Saat ini Gerakan Pramuka Indonesia dipimpin oleh Budi Waseso yang pernah menjadi Kepala Badan Narkotika Nasional (BNN).");
        }else if(tanggal.equalsIgnoreCase("Tanggal 17 Agustus: Hari Proklamasi Kemerdekaan Republik Indonesia (sejak tahun 1945)")){
            infoBulan.setText("Proklamasi Kemerdekaan Indonesia dilaksanakan pada hari Jumat, 17 Agustus 1945 tahun Masehi, atau tanggal 17 Agustus 2605 menurut tahun Jepang, yang dibacakan oleh Soekarno dengan didampingi oleh Drs. Mohammad Hatta bertempat di sebuah rumah hibah dari Faradj bin Said bin Awadh Martak di Jalan Pegangsaan Timur 56, Jakarta Pusat.[1]\n" +
                    "\n" +
                    "Kata-kata dan deklarasi proklamasi tersebut harus menyeimbangkan kepentingan kepentingan internal Indonesia dan Jepang yang saling bertentangan pada saat itu.[2]Proklamasi tersebut menandai dimulainya perlawanan diplomatik dan bersenjata dari Revolusi Nasional Indonesia, yang berperang melawan pasukan Belanda dan warga sipil pro-Belanda, hingga Belanda secara resmi mengakui kemerdekaan Indonesia pada tahun 1949.[3] Pada tahun 2005, Belanda menyatakan bahwa mereka telah memutuskan untuk menerima secara de facto tanggal 17 Agustus 1945 sebagai tanggal kemerdekaan Indonesia.[4] Namun, pada tanggal 14 September 2011, pengadilan Belanda memutuskan dalam kasus pembantaian Rawagede bahwa Belanda bertanggung jawab karena memiliki tugas untuk mempertahankan penduduknya, yang juga mengindikasikan bahwa daerah tersebut adalah bagian dari Hindia Timur Belanda, bertentangan dengan klaim Indonesia atas 17 Agustus 1945 sebagai tanggal kemerdekaannya.[5] Dalam sebuah wawancara tahun 2013, sejarawan Indonesia Sukotjo, antara lain, meminta pemerintah Belanda untuk secara resmi mengakui tanggal kemerdekaan pada 17 Agustus 1945.[6] Perserikatan Bangsa-Bangsa mengakui tanggal 27 Desember 1949 sebagai tanggal kemerdekaan Indonesia.[7]\n" +
                    "\n" +
                    "Naskah Proklamasi ditandatangani oleh Sukarno (yang menuliskan namanya sebagai \"Soekarno\" menggunakan ortografi Belanda) dan Mohammad Hatta,[8] yang kemudian ditunjuk sebagai presiden dan wakil presiden berturut-turut sehari setelah proklamasi dibacakan.[9][10]\n" +
                    "\n" +
                    "Hari Kemerdekaan dijadikan sebagai hari libur nasional melalui keputusan pemerintah yang dikeluarkan pada 18 Juni 1946.[11] ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 18 Agustus: Hari Konstitusi Republik Indonesia (sejak tahun 1945)")){
            infoBulan.setText("Okezone mencoba untuk kembali mengenang peristiwa yang terjadi pada 18 Agustus yang dikutip berdasarkan sumber Wikipedia. Berikut ulasannya :\n" +
                    "\n" +
                    "1868 - Pierre Jules César Janssen menemukan helium\n" +
                    "\n" +
                    "Pierre Jules César Janssen merupakan seorang astronom Prancis, yang bersama dengan ilmuwan Inggris Joseph Norman Lockyer, diakui sebagai penemu gas helium.\n" +
                    "\n" +
                    "1877 - Asaph Hall menemukan Phobos, bulan terbesar Mars\n" +
                    "\n" +
                    "Dia adalah seorang ahli astronomi berkebangsaan Amerika yang terkenal dalam penemuan Bulan Mars (yang bernama Deimos and Phobos) pada tahun 1877. Dia menemukan orbit satelit dari planet lain dan dari bintang ganda, rotasi Saturnus, dan massa Mars.\n" +
                    "\n" +
                    "Hall lahir di Goshen, Connecticut, putra Asaph Hall II, seorang pembuat jam, dan Hannah Palmer. Ayahnya meninggal ketika ia berusia 13 tahun, meninggalkan keluarga dalam kesulitan keuangan. Jadi Asaph meninggalkan sekolah untuk menjadi magang pada seorang tukang kayu pada usia 16 tahun.\n" +
                    "\n" +
                    "1945 - Undang-Undang Dasar Negara Republik Indonesia disahkan dalam sidang Panitia Persiapan Kemerdekaan Indonesia (PPKI)\n" +
                    "\n" +
                    ".\n" +
                    "\n" +
                    "Sehari setelah proklamasi kemerdekaan, sidang PPKI tanggal 18 Agustus 1945 membuat sebuah keputusan penting terkait negara Indonesia :\n" +
                    "\n" +
                    "Bung Hatta Foto: Wikimedia\n" +
                    "\n" +
                    "1. Mengesahkan dan menetapkan Undang-Undang Dasar Republik Indonesia yang telah dipersiapkan oleh Dokuritsu Junbi Coosakai (BPUPKI), yang kemudian dikenal dengan Undang-Undang Dasar 1945.\n" +
                    "\n" +
                    "2. Memilih Ir Soekarno sebagai presiden dan Drs Mohammad Hatta sebagai wakil presiden. Pemilihan presiden dan wakil presiden dilakukan secara aklamasi atas usul dari Otto Iskandardinata.\n" +
                    "\n" +
                    "3. Membentuk sebuah Komite Nasional untuk membantu presiden selama Majelis Permusyawaratan Rakyat (MPR) dan Dewan Perwakilan Rakyat (DPR) belum terbentuk.\n" +
                    "\n" +
                    "2005 - Pemadaman serentak terjadi di Pulau Jawa, memberi dampak pada lebih dari 100 juta orang. 2018 - Mantan Sekjen PBB, Koffi Annan meninggal\n" +
                    "\n" +
                    "Dia adalah diplomat Ghana yang menjabat sebagai Sekretaris Jenderal Perserikatan Bangsa-Bangsa (PBB) ke-7 sejak Januari 1997 sampai Desember 2006.\n" +
                    "\n" +
                    "Mantan Sekjen PBB Koffi Annan (foto: BBC)\n" +
                    "\n" +
                    "Annan dan PBB adalah penerima Hadiah Perdamaian Nobel 2001. Ia adalah pendiri dan ketua Kofi Annan Foundation sekaligus ketua The Elders, organisasi internasional yang didirikan oleh Nelson Mandela.\n" +
                    "\n" +
                    "2018 - Pembukaan Asian Games 2018: Energy of Asia di Stadion Utama Gelora Bung Karno, Jakarta");
        }else if(tanggal.equalsIgnoreCase("Tanggal 19 Agustus: Hari Departemen Luar Negeri Indonesia")){
            infoBulan.setText("Kementerian Luar Negeri Republik Indonesia (disingkat Kemlu RI), dahulu Departemen Luar Negeri (disingkat Deplu), adalah kementerian dalam Pemerintah Indonesia yang membidangi urusan luar negeri negara. Kementerian Luar Negeri dipimpin oleh seorang Menteri Luar Negeri (Menlu) yang sejak tanggal 27 Oktober 2014 dijabat oleh Retno Marsudi dan Wakil Menteri Luar Negeri (Wamenlu) yang sejak 25 Oktober 2019 dijabat oleh Mahendra Siregar.\n" +
                    "\n" +
                    "Kementerian Luar Negeri RI merupakan salah satu dari tiga kementerian (bersama Kementerian Dalam Negeri dan Kementerian Pertahanan) yang disebutkan secara eksplisit dalam UUD 1945 tidak dapat diubah atau dibubarkan oleh presiden.\n" +
                    "\n" +
                    "Menteri Luar Negeri secara bersama-sama dengan Menteri Dalam Negeri dan Menteri Pertahanan bertindak sebagai pelaksana tugas kepresidenan jika Presiden dan Wakil Presiden mangkat, berhenti, diberhentikan, atau tidak dapat melakukan kewajibannya dalam masa jabatannya secara bersamaan.[2] ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 21 Agustus: Hari Maritim Nasional")){
            infoBulan.setText("Tepat pada tanggal 21 Agustus diperingati sebagai hari Maritim Nasional oleh pemerintah Indonesia. 4 hari setelah proklamasi kemerdekaan Indonesia, kekuatan angkatan laut Republik Indonesia berhasil mengambil alih kekuasan militer laut Jepang. Dengan peralatan sederhana, militer Indonesia mampu mengalahkan Jepang yang menggunakan peralatan yang jauh lebih mutakhir. Di samping itu, sejarah membuktikan bahwa angkatan laut Indonesia sangat disegani. Tidak hanya angkatan laut, kelautan Indonesia juga sangat dikagumi karena hampir 75 persen wilayah Indonesia berupa laut yang memiliki kekayaan melimpah.\n" +
                    "\n" +
                    "Secara geografis, Indonesia merupakan negara kepulauan dengan dua pertiga luasnya berupa lautan. Status negara kepulauan didapat melalui perjalanan sejarah yang panjang. Hal itu diawali dengan Deklarasi Djuanda tahun 1957 mengenai kebijakan kelautan Indonesia pertama. Kala itu, Indonesia merasa kebijakan kelautan warisan masa kolonial sudah tidak sesuai lagi dengan konsep “Tanah Air” yang menekankan keterpaduan tanah dan air sebagai kekuatan nasional bangsa Indonesia. Butuh waktu dua 25 tahun bagi Indonesia untuk mendapat pengakuan dunia internasional sebagai negara kepulauan yang kemudian dicantumkan dalam Bab IV Konvensi Hukum Laut 1982\n" +
                    "\n" +
                    "Sumber : pikiranrakyat.com");
        }
    }
}
