package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilApril extends AppCompatActivity {
    String APRIL;
    TextView infoBulan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_april);

        // ambil textview info di acivity_hasil1
        infoBulan=(TextView) findViewById(R.id.info_april);

        // ambil parameter nama_negara dari intent
        Intent intent = getIntent();
        APRIL = intent.getStringExtra("april");

        // panggil setInfo(String negara) dan tampilkan ibukotanya
        setFebuari(APRIL);
    }

    public void setFebuari(String tanggal){
        if(tanggal.equalsIgnoreCase("Tanggal  1 April: Hari Bank Dunia")){
            infoBulan.setText("MATA INDONESIA, JAKARTA – Bank Dunia bersama lembaga multilateral lainnya seperti IMF maupun ADB akan menghadapi pekerjaan berat menghadapi ekonomi dunia yang dibayangi resesi akibat wabah virus corona atau Covid19. Lembaga itu memang dibentuk untuk menciptakan ekonomi global yang seimbang dengan membantu negara-negara miskin.\n" +
                    "\n" +
                    "Soal waktu terbentuknya lembaga mulitelateral tersebut memang banyak versi. Ada yang menyebut 27 Desember 1945 setelah ratifikasi internasional atas perjanjian yang dicapai pada konferensi di Kota Bretton Woods Hew Hampshire Amerika Serikat sejak 1 April 1944.\n" +
                    "\n" +
                    "Namun, ada yang berpegang pada 1 April awal berlangsungnya konferensi itu yang sekarang dikenal dengan Hari Bank Dunia.\n" +
                    "\n" +
                    "Konferensi itu menghasilkan Sistem Bretton Woods yang diadopsi menjadi sistem perekonomian dunia.\n" +
                    "\n" +
                    "Konferensi itu merupakan produk kerjasama antara Amerika Serikat dan Inggris yang memiliki beberapa fitur kunci yang melahirkan tiga institusi keuangan dunia yaitu Dana Moneter Internasional, Bank Dunia, dan Organisasi Perdagangan Dunia.\n" +
                    "\n" +
                    "Ada dua tujuan dari konferensi Bretton Woods yang menciptakan sistem perekonomian dunia yaitu pertama, mendorong pengurangan tarif dan hambatan lain dalam perdagangan internasional.\n" +
                    "\n" +
                    "Hal kedua adalah menciptakan kerangka ekonomi global untuk meminimalisir konflik ekonomi yang terjadi di antara negara-negara, yang salah satu bagiannya adalah mencegah terjadinya Perang Dunia II. Caranya dengan meningkatkan pertumbuhan ekonomi negara-negara miskin dengan berbagai skema ekonomi pembangunan.\n" +
                    "\n" +
                    "Sistem Bretton Woods bubar pada tahun 1976 setelah beberapa negara di Eropa mengalami kehancuran ekonomi sehingga tidak lagi bisa menjadi partner perdagangan Amerika Serikat. Selain itu, resesi ekonomi dunia yang berlangsung besar-besaran pada periode waktu itu  mendorong negara-negara di dunia untuk mengedepankan kepentingan nasionalnya masing-masing.\n" +
                    "\n" +
                    "Sejak itu Bank Dunia menjadi sebuah lembaga keuangan internasional yang menyediakan pinjaman kepada negara berkembang untuk program pemberian modal.\n" +
                    "\n" +
                    "Tujuan resmi Bank Dunia adalah pengurangan kemiskinan. Menurut Articles of Agreement Bank Dunia, sebagaimana telah diubah, efektif sejak 16 Februari 1989 seluruh keputusannya harus diarahkan oleh sebuah komitmen untuk mempromosikan investasi luar negeri, perdagangan internasional, dan memfasilitasi investasi modal.\n" +
                    "\n" +
                    "Tahun ini Bank Dunia kembali mendapat tantangan karena seperti diprediksi The Economist Intellegence Unit (EIU) sebagian besar negara dunia akan mengalami pertumbuhan negatif akibat wabah virus corona atau Covid19. Khusus di kelompok G 20 hanya tiga negara yang masih tumbuh positif setidaknya pada semester pertama tahun ini yaitu Cina, India dan negara kita Indonesia.\n" +
                    "\n" +
                    "Sejak 1963, lembaga itu telah mengeluarkan 36,5 trilyun dolar AS untuk pinjaman dan hibah kepada negara-negara miskin.\n" +
                    "\n" +
                    "Tahun ini, organisasi keuangan dunia itu harus bisa membuat perekonomian dunia pulih seperti sebelum wabah mendera. Selamat Hari Bank Dunia 1 April.");
        }else if(tanggal.equalsIgnoreCase("Tanggal  1 April: Hari Marketing Indonesia (Hamari) [11], Hari Penyiaran Nasional[12]")){
            infoBulan.setText("JAKARTA, KOMPAS.com — Bagi sebagian orang, tanggal 1 April lebih dikenal sebagai \"April Mop\" atau hari kebohongan. Namun, pada hari ini, 1 April telah ditetapkan sebagai Hari Marketing Indonesia (Hamari). Hari Marketing Indonesia ditetapkan oleh Menteri Pariwasata dan Ekonomi Kreatif Mari Elka Pangestu di Balairung Soesila Soedarman, Gedung Sapta Pesona, Jakarta, Selasa (1/4/2014). Pemilihan tanggal 1 April sebagai Hari Marketing Indonesia ialah karena biasanya tanggal tersebut menjadi dasar perusahaan menaikkan harga setelah melewati kuartal I. Pada tanggal yang sama, perusahaan banyak yang meluncurkan produknya dan materi promosi baru. Tujuan penetapan Hari Marketing Indonesia ini adalah untuk mendorong para tenaga pemasaran menjadi lebih kreatif dan inovatif. Dengan demikian, perusahaan mampu menjual produk yang bagus dan brand yang bagus sehingga mampu mengembangkan ekonomi kreatif Indonesia. Penetapan Hari Marketing Indonesia ini diharapkan akan menjadi pengingat dan penggugah semangat bagi para pebisnis di Indonesia agar terus berkreasi dan berinovasi. Pebisnis Indonesia bisa semakin memiliki daya saing dalam ekonomi dunia.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"1 April Ditetapkan Jadi Hari Marketing Indonesia\", https://money.kompas.com/read/2014/04/01/1205080/1.April.Ditetapkan.Jadi.Hari.Marketing.Indonesia.\n" +
                    "Penulis : Yoga Sukmana");
        }else if(tanggal.equalsIgnoreCase("Tanggal  6 April: Hari Nelayan Nasional")){
            infoBulan.setText("Hari nelayan sedunia" + "Indonesiabaik.id - Tahukah kamu? Setiap tahunnya tanggal 6 April diperingati sebagai Hari Nelayan Nasional. Peringatan Hari Nelayan Nasional telah ditetapkan pada tahun 1960 lalu sejak pemerintahan Orde Baru. Hari Nelayan Nasional diperingati sebagai bentuk mengapresiasi jasa para nelayan Indonesia dalam upaya pemenuhan kebutuhan protein dan gizi bagi seluruh lapisan masyarakat Indonesia sekaligus sebagai bentuk pengingat untuk bersyukur dan memajukan kesejahteraan nelayan.\n" +
                    "\n" +
                    "Sejatinya, Hari Nelayan merupakan tradisi turun-temurun untuk mengungkapkan syukur atas kesejahteraan hidup yang diberikan. Upacara ini diisi dengan tarian tradisional dan pelepasan sajen ke laut dengan harapan agar hasil tangkapan nelayan semakin meningkat. \n" +
                    "\n" +
                    "Upacara yang diselenggarakan setiap tanggal 6 April ini didasari oleh keadaan geografis Indonesia yang diapit oleh dua samudera, yaitu Samudera Hindia dan Samudera Pasifik. Oleh karena itu, Indonesia memiliki potensi perikanan yang sangat besar. Hal ini ditunjukkan dengan banyaknya penduduk yang bermata pencaharian sebagai nelayan. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  9 April: Hari Penerbangan Nasional[13], Hari TNI Angkatan Udara")){
            infoBulan.setText("Hari penerbangan nasional\n" + "\n" + "9 April 2019, merupakan hari istimewa bagi dunia dirgantara Indonesia dikarenakan hari ini diperingati sebagai Hari Penerbangan Nasional. Namun dibalik semua itu, terdapat kisah perjalanan dalam dunia penerbangan di langit nusantara kita.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Semua bermula dari 73 tahun silam yang ditandai dengan kelahiran TNI AU yang pada saat itu masih bernama Badan Keamanan Rakyat (BKR) dibentuk pada 23 Agustus 1945, kemudian berubah nama menjadi Tentara Keamanan Rakyat (TKR) pada tanggal 5 Oktober 1945di bawah Komodor Udara Soerjadi Soerjadarma.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Tepat pada 23 Januari 1946, TKR ditingkatkan lagi menjadi TRI sebagai kelanjutan dari perkembangan tunas Angkatan Udara. Maka pada tanggal 9 April 1946, TRI jawatan penerbangan dihapus, lalu diganti dengan nama Angkatan Udara Republik Indonesia dan hari itu kini diperingati sebagai hari kelahiran TNI AU.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Dunia penerbangan kita lahir dari keberanian. Dari pengetahuan yang sama sekali nol tentang kedirgantaraan dengan hanya bermodal semangat dan kegembiraan setelah lepas dari belenggu penjajah, lalu AURI berkembang menjadi Angkatan Udara yang terkuat di Asia pada masa-masa awal berdirinya.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Dunia penerbangan kita khususnya AURI, pernah memiliki kenangan manis. Seperti yang diwartakan Majalah Angkasa edisi 7 April 1999, “AURI mulai tumbuh besar. Buktinya, ketika Perdana Menteri U Nu dari Burma menginjakkan kakinya di Lanud Husein Sastranegara untuk menghadiri konferensi Asia Afrika.Tokoh kelas dunia ini terpana ketika melihat jejeran B-25 begitu banyak di pelataran parkir. Kepada Wiweko yang menjemput, Perdana Menteri U Nu mengatakan, “I have never seen so many aircrafts together.”\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Hal itu pun menginspirasi beberapa media asing untuk menggambarkan kegagahan Angkatan Udara kita. Seperti Majalah berbahasa Belanda Vliegwereld (Dunia Penerbangan) tanpa ragu menulis: “AURI angkatan udara paling ditakuti di Asia Tenggara”. Serta Air Pictorial, majalah penerbangan Inggris turut mengutip: “Ditilik dari sudut material, Angkatan Udara Australia ketinggalan total dari AURI”.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Tentu hal itu membuat kita bangga hati. Meski dalam beberapa waktu terakhir dunia penerbangan Nusantara dirundung banyak kesedihan lantaran sering terjadinya kecelakaan pesawat di dalam negeri. Namun kita masih memiliki semangat untuk bangkit dan melesat secepat kilat di langit nusantara dan angkasa. Selamat Hari Penerbangan Nasional!\n" + "\n" + "Hari TNI Angkatan Darat\n" + "\n" +"Tentara Nasional Indonesia Angkatan Udara (atau biasa disingkat TNI Angkatan Udara atau TNI-AU) adalah salah satu cabang angkatan perang dan merupakan bagian dari Tentara Nasional Indonesia (TNI) yang bertanggung jawab atas operasi pertahanan negara Republik Indonesia di udara.\n" +
                    "\n" +
                    "TNI Angkatan Udara pada awalnya merupakan bagian dari TNI Angkatan Darat yang dulunya bernama Tentara Keamanan Rakyat (TKR Jawatan Penerbangan). TNI Angkatan Udara dibentuk dan mulai berdiri sendiri pada tanggal 9 April 1946 bersamaan dengan dibentuknya Tentara Republik Indonesia (TRI Angkatan Udara) sesuai dengan Penetapan Pemerintah Nomor 6/SD Tahun 1946.\n" +
                    "\n" +
                    "TNI Angkatan Udara dipimpin oleh seorang Kepala Staf Angkatan Udara (KASAU) yang menjadi pemimpin tertinggi di Markas Besar Angkatan Udara (MABESAU). KASAU saat ini dijabat oleh Marsekal TNI Fadjar Prasetyo.\n" +
                    "\n" +
                    "Kekuatan TNI-AU saat ini memiliki tiga komando operasi yaitu Komando Operasi Angkatan Udara I (Koops AU I) yang bermarkas di Bandara Halim Perdanakusuma, Jakarta, Komando Operasi Angkatan Udara II (Koops AU II) yang bermarkas di Makassar, dan Komando Operasi Angkatan Udara III (Koops AU III) yang bermarkas di Biak. TNI Angkatan Udara juga memiliki satuan pasukan darat, yang disebut dengan Korps Pasukan Khas TNI Angkatan Udara (Paskhas TNI-AU). Pasukan ini terkenal dengan sebutan Korps Baret Jingga.\n" +
                    "\n" +
                    "TNI Angkatan Udara saat ini memiliki 37.850 personel dan dilengkapi dengan 110 pesawat tempur. Pesawat tempur tersebut termasuk lima Su-27 dan sebelas Su-30 sebagai pesawat tempur utama (dari Rusia) ditambah dengan 33 F-16 Fighting Falcons (dari Amerika Serikat), Hawk 200, KAI T-50 dan Embraer EMB314.[3] TNI Angkatan Udara juga memiliki rencana untuk membeli 11 Sukhoi Su-35[4] dan sekitar 50 KF-X[5] sebagai pengganti dari F-5E Tiger yang sudah tua sebagai pesawat tempur ringan dalam alat utama sistem persenjataannya[6][7] tetapi kontrak pengiriman untuk Su-35 dan KF-X belum ditandatangani, dan tidak ada pengiriman kedua pesawat ke Indonesia, pada bulan Februari 2020. " );
        }else if(tanggal.equalsIgnoreCase("Tanggal  12 April: Hari Bawa Bekal Nasional[14]")){
            infoBulan.setText("\n" +
                    "\n" +
                    "Hari ini tepat tanggal 12 April 2019, Hari Bawa Bekal Nasional. Hari Bawa Bekal Nasioanal mulai diperingati sejak 2013 lalu setelah digagas oleh salah satu perusahaan multinasional peralatan rumah tangga dan disetujui oleh Kemenkes RI, Kementerian Pendidikan Nasional dan BPOM.\n" +
                    "\n" +
                    "Gerakan ini diciptakan untuk meningkatkan kesadaran akan pentingnya lingkungan sehat dan perilaku hidup bersih dan sehat bagi anak Indonesia. Gerakan Bawa Bekal Nasioanl ini pun dilakukan untuk menjaga keamanan pangan jajanan anak sekolah dengan dasar data temuan dari BPOM, dimana sepanjang tahun 2006 sampai 2010 ditemukan sekitar 40 sampai 44 persen jajanan anak sekolah tidak memenuhi syarat keamanan pangan.\n" +
                    "\n" +
                    "Gerakan Bawa Bekal Nasional memang terasa amat sederhana, namun ternyata membawa bekal dari rumah memberikan banyak manfaat tidak hanya bagi kesehatan namun juga keuangan. Sesuai tujuannya, Hari Bawa Bekal Nasional ini memang digagas sebagai bentuk kampanye meningkatkan pemenuhan gizi dan kualitas makan. Apa saja sih manfaat bawa bekal? Berikut adalah manfaat bawa bekal dari rumah dilansir dari CNN,\n" +
                    "\n" +
                    "Baca juga: Hidup Sehat dengan Makanan Organik\n" +
                    "\n" +
                    "    Lebih higienis\n" +
                    "\n" +
                    "Kebersihan makanan lebih terjamin jika Sobat7 bawa bekal daripada saat membeli makanan dari luar. Bagaimana tidak? Semuanya berasal dari barang-barang rumah dan dibersihkan sendiri. Mulai dari bahan untuk memasak sampai alatnya. Kebersihan yang terjamin ini tentu menghindarkan kita dari bakteri dan virus penyebab penyakit.\n" +
                    "\n" +
                    "    Lebih aman\n" +
                    "\n" +
                    "Karena bekal yang kita bawa dari rumah dibuat sendiri, maka tentu penggunaan bahannya lebih terjaga. Mulai dari zat pewarna, pemanis buatan dan penyedap digunakan sesuai dengan takarannya. Demikian pula dengan kandungan gula, garam dan lemak yang tidak berlebihan. Dengan terjaganya makanan kita maka penyakit seperti obesitas, kolesterol dan tekanan darah tinggi.\n" +
                    "\n" +
                    "    Nutrisi yang lengkap\n" +
                    "\n" +
                    "Menu yang kita pilih ketika menyiapkan bekal dari rumah tentu sesuai dengan kebutuhan gizi. Menurut Kementerian Kesehatan, satu piring makan yang baik harus terdiri atas karbohidrat, sayuran, lauk pauk untuk protein dan buah-buahan.\n" +
                    "\n" +
                    "    Lebih hemat\n" +
                    "\n" +
                    "Bawa bekal dari rumah tentu lebih murah dari membeli di luar. Selain menyehatkan tubuh, membawa bekal dari rumah juga turut menyehatkan bagi dompet. Biaya yang sama dengan yang Sobat7 keluarkan untuk makan seorang diri, dapat digunakan untuk membeli bahan bagi seluruh keluarga.\n" +
                    "\n" +
                    "Yuk Sobat7 mulai sekarang kita latihan mendukung Gerakan Bawa Bekal Nasional dengan bawa bekal dari rumah. Kesehatan tubuh pun akan lebih mudah dikontrol ketika kita memahami makanan yang kita makan. Selamat Hari Bawa Bekal Nasional 2019!\n" + "\n" + "source: https://www.trans7.co.id/seven-updates/hari-bawa-bekal-nasional");
        }else if(tanggal.equalsIgnoreCase("Tanggal  16 April: Hari Komando Pasukan Khusus (Kopassus)")){
            infoBulan.setText("Komando Pasukan Khusus yang disingkat menjadi Kopassus yang nama sebelumnya adalah Resimen Para Komando Angkatan Darat atau RPKAD merupakan bagian dari Komando Utama (KOTAMA) tempur yang dimiliki oleh TNI Angkatan Darat, Indonesia. Kopassus memiliki kemampuan khusus seperti bergerak cepat di setiap medan, menembak dengan tepat, pengintaian, dan anti teror. Tugas Kopasus Operasi Militer Perang (OMP) diantaranya Direct Action serangan langsung untuk menghancurkan logistik musuh, Combat SAR, Anti Teror, Advance Combat Intelligence (Operasi Inteligen Khusus). Selain itu, Tugas Kopasus Operasi Militer Selain Perang (OMSP) diantaranya Humanitarian Asistensi (bantuan kemanusiaan), AIRSO (operasi anti insurjensi, separatisme dan pemberontakan), perbantuan terhadap kepolisian/pemerintah, SAR Khusus serta Pengamanan VVIP.\n" +
                    "\n" +
                    "Prajurit Kopassus dapat mudah dikenali dengan baret merah yang disandangnya, sehingga pasukan ini sering disebut sebagai pasukan baret merah. Kopassus memiliki moto \"Berani, Benar, Berhasil\". \n" + "\n" + "Komando Pasukan Khusus yang disingkat menjadi Kopassus yang nama sebelumnya adalah Resimen Para Komando Angkatan Darat atau RPKAD merupakan bagian dari Komando Utama (KOTAMA) tempur yang dimiliki oleh TNI Angkatan Darat, Indonesia. Kopassus memiliki kemampuan khusus seperti bergerak cepat di setiap medan, menembak dengan tepat, pengintaian, dan anti teror. Tugas Kopasus Operasi Militer Perang (OMP) diantaranya Direct Action serangan langsung untuk menghancurkan logistik musuh, Combat SAR, Anti Teror, Advance Combat Intelligence (Operasi Inteligen Khusus). Selain itu, Tugas Kopasus Operasi Militer Selain Perang (OMSP) diantaranya Humanitarian Asistensi (bantuan kemanusiaan), AIRSO (operasi anti insurjensi, separatisme dan pemberontakan), perbantuan terhadap kepolisian/pemerintah, SAR Khusus serta Pengamanan VVIP.\n" +
                    "\n" +
                    "Prajurit Kopassus dapat mudah dikenali dengan baret merah yang disandangnya, sehingga pasukan ini sering disebut sebagai pasukan baret merah. Kopassus memiliki moto \"Berani, Benar, Berhasil\". \n" + "\n" +"Dalam perjalanan sejarahnya, Kopassus berhasil mengukuhkan keberadaannya sebagai pasukan khusus yang mampu menangani tugas-tugas yang berat. Beberapa operasi yang dilakukan oleh Kopassus diantaranya adalah operasi penumpasan DI/TII, operasi militer PRRI/Permesta, Operasi Trikora, Operasi Dwikora, penumpasan G30S/PKI, Pepera di Irian Barat, Operasi Seroja di Timor Timur, operasi pembebasan sandera di Bandara Don Muang-Thailand (Woyla), Operasi GPK di Aceh, operasi pembebasan sandera di Mapenduma, operasi pembebasan sandera perompak Somalia, serta berbagai operasi militer lainnya. Dikarenakan misi dan tugas operasi yang bersifat rahasia, mayoritas dari kegiatan tugas daripada satuan Kopassus tidak akan pernah diketahui secara menyeluruh. Contoh operasi Kopassus yang pernah dilakukan dan tidak diketahui publik seperti: Penyusupan ke pengungsi Vietnam di pulau Galang untuk membantu pengumpulan informasi untuk di kordinasikan dengan pihak Amerika Serikat (CIA), penyusupan perbatasan Malaysia dan Australia dan operasi patroli jarak jauh (long range recce) di perbatasan Papua nugini. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  17 April: Hari Pergerakan Mahasiswa Islam Indonesia PMII")){
            infoBulan.setText("Pendirian PMII\n" +
                    "Ide dasar berdirinya Pergerakan Mahasiswa Islam Indonesia (PMII) bermula dari adanya hasrat kuat para mahasiswa Nahdliyin untuk membentuk suatu wadah (organisasi) mahasiswa yang berideologi Ahlussunnah Wal Jama’ah (Aswaja). Sebelum berdirinya PMII, sudah ada organisasi mahasiswa Nahdliyin, namun masih bersifat lokal. Organisasi itu diantaranya Ikatan Mahasiswa Nahdlatul Ulama (IMANU) berdiri pada Desember 1955 di Jakarta. Di Surakarta dirikan Keluarga Mahasiswa Nahdlatul Ulama (KMNU) pada tahun yang sama. Kemduian berdiri juga Persatuan Mahasiswa Nahdlatul Ulama (PMNU) di Bandung. Selain organisasi tersebut, ada pula mahasiswa Nahdliyin yang tergabung pada Ikatan Pelajar Nahdlatul Ulama (IPNU) yang terwadahi pada departemen perguruan tinggi.\n" +
                    "Adanya berbegai macam organisasi kemahasiswaan yang berafiliasi kepada Nahdlatul Ulama ternyata tidak mampu membendung hasrat untuk berdirinya organisasi mahasiswa nahdliyin secara nasional. Hal itu terbukti pada Konferensi Besar IPNU pada tanggal 14-17 Maret 1960 di Kaliurang Yogyakarta disepakati untuk berdirinya organisasi kemahasiswaan Nahdliyin.\n" +
                    "Kemudian dibentuklah panitia sponsor berdirinya organisasi mahasiswa Nahdliyin yang berjumlah 13 orang mahasiswa NU dari berbagai daerah. Ketiga belas panitia tersebut kemudian mengadakan pertemuan yang disebut dengan Musyawarah Mahasiswa NU. Pertemuan tersebut diselenggarakan pada tanggal 14-16 April 1960 di Gedung Madrasah Muallimin Nahdlatul Ulama (Gedung Yayasan Khadijah) Wonokromo Surabaya. Selanjutnya hasil musyawarah tersebut diumumkan di Balai Pemuda pada tanggal 21 Syawal 1379 Hijriyah atau bertepatan dengan tanggal 17 April 1960. Maka mulai saat itulah PMII berdiri dan tanggal 17 April 1960 dinyatakan sebagai hari jadi PMII yang diperingati dengan istilah Hari lahir (Harlah).\n" +
                    "Adapun ketiga belas mahasiswa NU sponsor atau panitia yang selanjutnya disepakati sebagai pendiri PMII yaitu:\n" +
                    "1. Sahabat Chalid Mawardi (Jakarta)\n" +
                    "2. Sahabat M. Said Budairy (Jakarta)\n" +
                    "3. Sahabat M. Sobich Ubaid (Jakarta)\n" +
                    "4. Sahabat Makmun Syukri (Bandung)\n" +
                    "5. Sahabat Hilman Badrudinsyah (Bandung)\n" +
                    "6. Sahabat H. Ismail Makky (Yogyakarta)\n" +
                    "7. Sahabat Moensif Nachrowi ( Yogyakarta)\n" +
                    "8. Sahabat Nuril Huda Suaiby (Surakarta)\n" +
                    "9. Sahabat Laily Mansur (Surakarta)\n" +
                    "10. Sahabat Abdul Wahab Jaelani (Semarang)\n" +
                    "11. Sahabat Hisbullah Huda (Surabaya)\n" +
                    "12. Sahabat M. Chalid Narbuko (Malang)\n" +
                    "13. Sahabat Ahmad Hussein (Makasar)\n" +
                    "Kepemimpinan PMII\n" +
                    "Sejak beridiri, PMII telah dipimpin oleh Ketua Umum sebagai berikut:\n" +
                    "1. Sahabat Mahbub Djunaidi (1960-1967)\n" +
                    "2. Sahabat M. Zamroni (1967-1973)\n" +
                    "3. Sahabat Abduh Paddare (1973-1977)\n" +
                    "4. Sahabat Ahmad Bagja (1977-1981)\n" +
                    "5. Sahabat Muhyiddin Arusbusman (1981-1985)\n" +
                    "6. Sahabat Suryadharma Ali (1985-1988)\n" +
                    "7. Sahabat M. Iqbal Assegaf (1988-1991)\n" +
                    "8. Sahabat Ali Masykur Musa (1991-1994)\n" +
                    "9. Sahabat A. Muhaimin Iskandar (1994-1997)\n" +
                    "10. Sahabat Syaiful Bahri Anshori (1997-2000)\n" +
                    "11. Sahabat Nusron Wahid (2000-2003)\n" +
                    "12. Sahabat A. Malik Haramain (2003-2005)\n" +
                    "13. Sahabat Hery Hariyanto Azumi (2005-2008)\n" +
                    "14. Sahabat M. Rodli Kaelani (2008-20011)\n" +
                    "15. Sahabat Addin Jauharudin (2011-2014)\n" +
                    "16. Sahabat Aminuddin Ma’ruf (2014-2017)\n" +
                    "17. Sahabat Agus Mulyono Herlambang (2017-Sekarang)");
        }else if(tanggal.equalsIgnoreCase("Tanggal  18 April: Hari Peringatan Konferensi Asia Afrika")){
            infoBulan.setText("Jakarta | EGINDO.co – Konferensi Tingkat Tinggi Asia-Afrika (KTT Asia-Afrika; kadang juga disebut Konferensi Bandung) adalah sebuah konferensi tingkat tinggi antara negara-negara Asia dan Afrika, yang kebanyakan baru saja memperoleh kemerdekaan. KTT ini diselenggarakan oleh Indonesia, Myanmar (dahulu Burma), Sri Lanka (dahulu Ceylon), India dan Pakistan dan dikoordinasi oleh Menteri Luar Negeri Indonesia Roeslan Abdulgani.\n" +
                    "\n" +
                    "Pertemuan ini berlangsung antara 18 April-24 April 1955, di Gedung Merdeka, Bandung, Indonesia dengan tujuan mempromosikan kerjasama ekonomi dan kebudayaan Asia-Afrika dan melawan kolonialisme atau neokolonialisme Amerika Serikat, Uni Soviet, atau negara imperialis lainnya. 29 negara yang mewakili lebih dari setengah total penduduk dunia mengirimkan wakilnya.\n" +
                    "\n" +
                    "Konferensi ini merefleksikan apa yang mereka pandang sebagai ketidak inginan kekuatan-kekuatan Barat untuk mengkonsultasikan dengan mereka tentang keputusan-keputusan yang mempengaruhi Asia pada masa Perang Dingin; kekhawatiran mereka mengenai ketegangan antara Republik Rakyat Tiongkok dan Amerika Serikat; keinginan mereka untuk membentangkan fondasi bagi hubungan yang damai antara Tiongkok dengan mereka dan pihak Barat; penentangan mereka terhadap kolonialisme, khususnya pengaruh Perancis di Afrika Utara dan kekuasaan kolonial perancis di Aljazair; dan keinginan Indonesia untuk mempromosikan hak mereka dalam pertentangan dengan Belanda mengenai Irian Barat.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Sepuluh poin hasil pertemuan ini kemudian tertuang dalam apa yang disebut Dasasila Bandung, yang berisi tentang “pernyataan mengenai dukungan bagi kedamaian dan kerjasama dunia”. Dasasila Bandung ini memasukkan prinsip-prinsip dalam Piagam PBB dan prinsip-prinsip Nehru. Konferensi ini akhirnya membawa kepada terbentuknya Gerakan Non-Blok pada 1961.\n" +
                    "\n" +
                    "Lanjut ke Museum Konferensi Asia Afrika tak pernah sepi dari pengunjung. Di hari kerja, para pelajar sekolah mulai dari Bandung hingga luar kota berbondong-bondong mendatangi museum ini. Di akhir pekan, wisatawan lokal sampai mancanegara juga menyambangi museum KAA untuk melihat sejarah perdamaian dunia yang diinisiasi Soekarno di Kota Bandung.\n" +
                    "\n" +
                    "Museum tak hanya menyimpan barang-barang bersejarah, tetapi menjadi pusat edukasi dan aktivitas warga. Seperti adanya perpustakaan dan berbagai macam klub yang memberikan sejumlah kegiatan seru. Berikut uraiannya:\n" +
                    "\n" +
                    "1. Membaca Buku AYO BACA : Menapaki Sejarah di Museum Konferensi Asia Afrika Di Museum KAA, pengunjung bisa membaca buku di perpustakaan. Di sana terdapat banyak buku di dalam etalase dan rak yang mengelilingi dinding perpustakaan. Ruangan yang cukup besar ini mempunyai sudut baca yang digelar karpet juga meja-meja untuk sekadar duduk sambil menulis. Tak usah khawatir untuk teman disabilitas karena  terdapat pojok braille bagi teman tunanetra. \n" +
                    "\n" +
                    "2. Ruang Audiovisual Tepat di depan perpustakaan, museum memiliki ruang audiovisual yang menyajikan tontonan 10 menit tentang video dokumenter perjalanan Konferensi Asia Afrika. Cerita dimulai dari ide Bung Karno untuk segera mengakhiri kericuhan dunia dan memerdekakan negara dari Asia Afrika, persiapan menuju KAA 1955, hingga potret sejarah dan pidato Bung Karno di podium ballroom Gedung Merdeka. Ruangan yang diisi dengan kursi merah ini dihiasi oleh piguran berisi foto-foto perdana menteri dari beberapa negara yang terlibat dalam KAA.  AYO BACA : Menyusuri Cita-cita Damai di Museum Konperensi Asia Afrika\n" +
                    "\n" +
                    "3. Gedung Merdeka Jika kamu pergi ke museum KAA, kamu pun akan masuk ke Gedung Merdeka. Di sanalah tempat para delegasi dari 29 negara berkonferensi untuk menyatakan perdamaian dunia. Faktanya, kursi-kursi merah dengan sandaran tangan kayu ini merupakan kursi yang pernah diduduki oleh para delegasi, lho. Mereka masih kuat, apik, dan bisa diduduki oleh pengunjung yang datang. Di sana pula konferensi dilaksanakan. Podium dan panggung dipenuhi bendera-bendera dari benua Asia dan Afrika.Gong perdamaian Asia-Afrika 2015 juga dipajang di sudut kanan panggung. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  19 April: Hari Pertahanan Sipil (Hansip)")){
            infoBulan.setText("TRIBUNKALTIM.CO - Sejarah hari ini sebuah organisasi bernama Pertahanan Sipil atau biasa disingkat Hansip dibentuk oleh pemerintah Indonesia, tepatnya 57 tahun lalu pada tanggal 19 April 1962.\n" +
                    "\n" +
                    "Hansip juga dikenal di kalangan luas masyarakat dengan sebutan Linmas.\n" +
                    "\n" +
                    "Melansir dari laman depdagri.go.id, kehadiran Hansip di Indonesia ini bersamaan dengan adanya peristiwa perang kemerdekaan yang dibentuk atas dasar kehendak rakyat Indonesia.\n" +
                    "\n" +
                    "Saat itu rakyat Indonesia ikut berpartisipasi aktif dengan membantu angkatan perang melalui Pertahanan Garis Belakang dalam bentuk penyelenggaraan keamanan rakyat.\n" +
                    "Hansip\n" +
                    "Hansip (Tribunnews)\n" +
                    "\n" +
                    "Setelah selesainya perang kemerdekaan secara formil, organisasi Hansip dibentuk di seluruh wilayah Republik Indonesia.\n" +
                    "\n" +
                    "Dasar hukum dari pembentukan milisi sipil yaitu berpacu pada Undang-undang no. 20 tahun 1982 yang berisi mengenai pokok-pokok kemanan dan pertahanan negara yang mengakui hak setiap warga negara untuk membela negara.\n" +
                    "\n" +
                    "Lalu mengacu kepada Keputusan Presiden (Keppres) No. 55 tahun 1972, menyebutkan jika seluruh rakyat atas dasar kewajiban dan kehormatan dan sesuai dengan kemampuan individualnya wajib mengikuti segala usaha Pertahanan/Keamanan dan bersama Angkatan Bersenjata Republik Indonesia.\n" +
                    "\n" +
                    "Berdasarkan Keppres No. 55 tahun 1972, organisasi Pertahanan Sipil (Hansip) masuk dalam sistem Hankamrata yang merupakan komponen Hankam dan komplemen ABRI.\n" +
                    "SEJARAH HARI INI Tepat 57 Tahun Lalu Pembentukan Hari Pertahanan Sipil (Hansip) di Indonesia\n" +
                    "SEJARAH HARI INI Peringatan Hari Pertahanan Sipil (Hansip) di Indonesia, Kini Sudah Berusia 57 Tahun. (Tribunnews)\n" +
                    "\n" +
                    "Tujuan dari pembentukan organisasi Hansip yaitu sebagai wadah yang yang senantiasa terlibat dalam kegiatan-kegiatan kemanusiaan, pemerintahan, penanggulangan bencana dan pengungsi, kegiatan bela negara, maupun penyelenggaraan ketertiban umum dan ketenteraman masyarakat.\n" +
                    "\n" +
                    "Keberadaan Hansip yang memiliki fungsi perlindungan masyarakat sebagaimana ditetapkan dalam Undang-undang Nomor 20 Tahun 1982 tentang Ketentuan-ketentuan Pokok Pertahanan Keamanan, mempunyai landasan yuridis yang kuat.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunkaltim.co dengan judul SEJARAH HARI INI Peringatan Hari Pertahanan Sipil (Hansip) di Indonesia, Kini Sudah Berusia 57 Tahun, https://kaltim.tribunnews.com/2019/04/19/sejarah-hari-ini-peringatan-hari-pertahanan-sipil-hansip-di-indonesia-kini-sudah-berusia-57-tahun.\n" +
                    "Penulis: Ayuk Fitri\n" +
                    "Editor: Syaiful Syafar ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  20 April: Hari Konsumen Nasional[15]")){
            infoBulan.setText("\t\n" +
                    "\n" +
                    "TRIBUNTIMURWIKI.COM- Tak banyak yang tahu jika 20 April merupakan Hari Konsumen Nasional.\n" +
                    "\n" +
                    "Penetapan Hari Konsumen Nasional dilakukan berdasarkan Keputusan Presiden No. 13 Tahun 2012 tentang Hari Konsumen Nasional.\n" +
                    "\n" +
                    "Bahkan, tanggal 20 April sebagai Hari Konsumen Nasional didasarkan pada tanggal diterbitkannya Undang-Undang No. 8 Tahun 1999 tentang Perlindungan Konsumen.\n" +
                    "\n" +
                    "Dikutip dari https://kominfo.go.id, adanya Hari Konsumen Nasional bertujuan sebagai upaya penguatan kesadaran secara massif akan arti pentingnya hak dan kewajiban konsumen serta sebagai pendorong meningkatnya daya saing produk yang dihasilkan pelaku usaha dalam negeri.\n" +
                    "\n" +
                    "Menempatkan konsumen pada subyek penentu kegiatan ekonomi sehingga pelaku usaha terdorong untuk dapat memproduksi dan memperdagangkan barang/jasa yang berkualitas serta berdaya saing di era globalisasi.\n" +
                    "\n" +
                    "Menempatkan konsumen untuk menjadi agen perubahan dalam posisinya sebagai subyek penentu kegiatan Ekonomi Indonesia.\n" +
                    "Mendorong pemerintah dalam melaksanakan tugas mengembangkan upaya perlindungan konsumen di Indonesia.\n" +
                    "\n" +
                    "Tema Peringatan Harkonas 2016 adalah “Gerakan Konsumen Cerdas, Mandiri dan Cinta Produk Dalam Negeri” dengan Sub tema “Konsumen Cerdas dengan Nasionalisme Tinggi Menggunakan Produk Dalam Negeri”.\n" +
                    "\n" +
                    "Konsumen yang cerdas adalah konsumen yang mampu menegakkan haknya, melaksanakan kewajibannya serta mampu melindungi dirinya dari barang atau jasa yang merugikan.\n" +
                    "\n" +
                    "Konsumen yang cerdas tentunya hanya membeli produk-produk yang sesuai ketentuan dan mengutamakan penggunaan produk dalam negeri.\n" +
                    "\n" +
                    "Penggunaan produk dalam negeri yang sesuai dengan ketentuan akan meningkatkan daya saing dan perekonomian bangsa, yang pada gilirannya akan meningkatkan kesejahteraan masyarakat.\n" +
                    "\n" +
                    "Adapun cinta produk dalam negeri adalah gerakan penggunaan produk dalam negeri sebagai bentuk rasa bangga dan cinta kepada bangsa Indonesia.\n" +
                    "\n" +
                    "Dengan menggunakan produk dalam negeri dapat memupuk rasa bangga dan cinta kepada bangsa Indonesia, meningkatkan perekonomian bangsa serta meningkatkan kemakmuran masyarakat.\n" +
                    "\n" +
                    "Undang-Undang No. 8 Tahun 1999 tentang Perlindungan Konsumen telah diberlakukan sejak tahun 2000 namun disadari bahwa masih sedikit konsumen yang memahami bahwa mereka mempunyai hak yang dijamin oleh Undang-Undang.\n" +
                    "\n" +
                    "Kurangnya pemahaman konsumen akan hak dan kewajibannya serta kemampuan melindungi diri ketika berinteraksi dengan pasar, menyebabkan banyaknya kasus di masyarakat yang menimbulkan kerugian bagi konsumen pada saat melakukan transaksi, baik yang secara konvensional maupun elektronik, di bidang pembiayaan, penggunaan bahan berbahaya pada pangan, pelayanan purna jual dan lain sebagainya.\n" +
                    "\n" +
                    "Hasil pemetaan Indeks Keberdayaan Konsumen (IKK) Indonesia yang dilakukan oleh Kementerian Perdagangan di tahun 2015 menunjukkan bahwa nilai IKK Indonesia tahun 2015 hanya sebesar 34,17, dari nilai maksimal 100.\n" +
                    "\n" +
                    "Nilai tersebut masih jauh lebih rendah apabila dibandingkan dengan nilai perhitungan IKK di 29 negara Eropa yang sudah mencapai 51,31.\n" +
                    "\n" +
                    "Dengan nilai IKK sebesar 34,17 menunjukkan bahwa keberdayaan konsumen Indonesia pada umumnya masih berada pada level paham, artinya konsumen Indonesia sudah mengenali dan memahami hak dan kewajibannya sebagai konsumen, namun belum sepenuhnya mampu menggunakannya untuk menentukan pilihan konsumsinya serta belum berperan aktif dalam memperjuangkan haknya sebagai konsumen.\n" +
                    "\n" +
                    "Dari survey tersebut juga terlihat bahwa perilaku complain konsumen Indonesia masih sangat rendah dengan nilai indeks 11,14.\n" +
                    "\n" +
                    "Selain itu hanya 30% masyarakat yang sudah mengetahui adanya Undang-Undang No. 8 tahun 1999 tentang Perlindungan Konsumen, dan bahkan 52% diantaranya hanya pernah mendengar.\n" +
                    "\n" +
                    "Sebanyak 42% konsumen yang mengalami masalah dalam pembelian dan/atau penggunaan barang/jasa, lebih memilih untuk tidak melakukan pengaduan, dengan alasan utama resiko kerugian tidak besar (37%); tidak tahu lokasi tempat pengaduan (24%); beranggapan prosesnya rumit dan lama (20%).\n" +
                    "\n" +
                    "Perlindungan konsumen merupakan prasyarat mutlak dalam mewujudkan perekonomian yang sehat melalui keseimbangan antara perlindungan kepentingan konsumen dan pelaku usaha.\n" +
                    "\n" +
                    "Hanya melalui keberadaan dan keberdayaan perlindungan konsumen yang memadai, Indonesia mampu membangun kualitas manusia yang berharkat, bermartabat, cerdas, sehat, inovatif dan produktif untuk membawa Indonesia memiliki ketahanan nasional, dan jauh lebih baik lagi berdaya saing di berbagai bidang di kancah dunia.\n" +
                    "\n" +
                    "Hari Konsumen Nasional diharapkan mampu menjadi momentum bagi seluruh pemangku kepentingan untuk meningkatkan kesetaraan antara konsumen dan pelaku usaha serta mampu mendorong semua pihak untuk mengambil peran aktif dalam mewujudkan konsumen Indonesia yang cerdas, mandiri dan cinta produk dalam negeri, serta dengan nasiolisme tinggi menggunakan produk dalam negeri.\n" +
                    "\n" +
                    "Sayangnya, adanya covid-19 atau virus corona, membuat beberapa instansi pemerintah tak turut merayakan momen Hari Konsumen Nasional tahun ini.\n" +
                    "\n" +
                    "Pada tahun 2016, Manajemen PT Pertamina Marketing Operation Region (MOR) Sulawesi merayakan Hari Konsumen Nasional di stasiun pengisian bahan bakar umum (SPBU) Jalan Urip Sumoharjo, Makassar, Rabu (20/4/2016).\n" +
                    "\n" +
                    "Seluruh pejabat Pertamina turun langsung melayani pelanggan yang datang mengisi bahan bakar di SPBU tersebut.\n" +
                    "\n" +
                    "Mereka antara lain General Manager Pertamina MOR VII Tengku Badarsyah, Manager Retail Fuel Maketing PT Pertamina MOR VII Umar Chatib, Sales Executive Wilayah I PT Pertamina MOR VII Jimmy Wijaya Area Communication & Relations Sulawesi PT Pertamina MOR VII Fety, dan jajaran lainnya.\n" +
                    "\n" +
                    "Momen Hari Konsumen Nasional, dimanfaatkan Pertamina membagi-bagikan pelumas dan voucher Bahan Bakar Khusus (BBK) kepada 50 pelanggan yang beruntung.\n" +
                    "\n" +
                    "Pantauan Tribun, Tengku turun langsung mengisi tangki bahan bakar konsumen yang datang.\n" +
                    "\n" +
                    "\"Acara ini penting untuk mengapresiasi konsumen kami. Terutama masyarkat yang menggunakan bahan bakar non subsidi,\" kata Badarsyah, usai melayani pelanggan.\n" +
                    "\n" +
                    "Adapula yang merayakannya dengan memberi bagi-bagi hadiah pada karyawan.\n" +
                    "\n" +
                    "Seperti, salah satu pegawai Badan SAR Nasional (Basarnas) Provinsi Kepulauan Bangka Belitung yang pada kegiatan jalan santai Fun Walk Hari Konsumen Nasional (Harkonas), di Halaman Kantor Gubenur Babel di Pangkalpinang mendapat hadiah motor.\n" +
                    "\n" +
                    "Dengan tergesa-gesa pegawai Basarnas ini maju ke atas panggung, saat nomor yang ada pada kupon jalan santai dicabut oleh H Rustam Effendi Gubernur Provnsi Kepulauan Bangka Belitung, didampngi Kepala Dinas Perindag Babel Yuliswan, Jumat (22/4/2016).\n" +
                    "\n" +
                    "Lotta Oktavianti langsung menyodorkan kupon yang dipegangnya kepada orang nomor satu di Pemerintah Provinsi Kepulauan Babel.\n" +
                    "\n" +
                    "Kupon yang dimiiki Lotta mendapatkan satu sepeda motor.\n" +
                    "\n" +
                    "Dalam kesempatan itu, H Rustam Efendi menyerahkan secara simbolis kunci sepeda motor, sekaligus memasangkan helm.\n" +
                    "\n" +
                    "Kegiatan jalan santai Fun Walk Harkonas yang digelar Dinas Perindag Provinsi Kepulauan Babel, diikuti H Rustam Effendi Gubernur Provinsi Kepulauan Babel bersama Forum Koordinasi Pimpinan Daerah Provinsi Kepulauan Babel, serta pegawai di jajaran Pemprov Babel, pelajar dan masyarakat.\n" +
                    "\n" +
                    "Peluncuran Logo Maskot Hari Konsumen Nasional 2020\n" +
                    "\n" +
                    "Logo dan maskot Hari Konsumen Nasional ( Harkonas) 2020 resmi diperkenalkan, Jumat (31/1/2020) pagi di Gedung Bhinaloka Adikara Kantor Gubernur Jawa Timur (Jatim), Surabaya.\n" +
                    "\n" +
                    "Menteri Perdagangan (Mendag) RI Agus Suparmanto langsung memperkenalkan logo dan maskot itu didampingi Wakil Gubernur Jawa Timur Emil Elestianto Dardak.\n" +
                    "\n" +
                    "Logo Harkonas 2020 berbentuk perisai dan tangan manusia yang diangkat sambil mengepal. Perisai melambangkan komitmen pemerintah untuk melindungi konsumen.\n" +
                    "\n" +
                    "Sementara itu, tangan mengepal memiliki makna konsumen sudah saatnya berdaya dan memiliki kemampuan untuk memutuskan sesuatu atau bertindak.\n" +
                    "\n" +
                    "Maskot Harkonas 2020 adalah Cak Enda, seekor lumba-lumba sebagai hewan cerdas dan sering membantu manusia.\n" +
                    "\n" +
                    "Enda merupakan kepanjangan Konsumen Berdaya yang bermakna peringatan Harkonas 2020 mampu membuat konsumen Indonesia makin cerdas dan berdaya.\n" +
                    "\n" +
                    "Harkonas kali ini merupakan peringatan kedelapan yang rencananya digelar di Jawa Timur, tepatnya di Lapangan Kodam V Brawijaya, 29-30 Maret 2020.\n" +
                    "\n" +
                    "Tema yang diangkat pada gelaran itu adalah Perlindungan Konsumen Menuju Indonesia Maju.\n" +
                    "\n" +
                    "Jawa Timur, tuan rumah Harkonas 2020\n" +
                    "\n" +
                    "Latar belakang pemilihan Jatim sebagai tuan rumah Harkonas 2020 adalah, provinsi itu merupakan daerah terbaik yang peduli dengan perlindungan konsumen.\n" +
                    "\n" +
                    "Pernyataan tersebut disampaikan langsung Mendag Agus. Ia menambahkan, sudah dua kali Jatim menjadi daerah terbaik yang peduli konsumen.\n" +
                    "\n" +
                    "“Sektor perdagangan Jawa Timur yang besar sangat berkontribusi pada sektor perdagangan nasional,” kata Agus dalam keterangan tertulis.\n" +
                    "\n" +
                    "Mendag berharap agar kepedulian Jatim kepada perlindungan konsumen menjadi panutan wilayah lain.\n" +
                    "\n" +
                    "Sementara itu, Wagub Emil berharap agar sektor perdagangan yang sangat menyumbang perekonomian Jatim bisa terus menjadi penguat ekonomi di wilayahnya.\n" +
                    "\n" +
                    "“Semua konsumen, baik yang bertransaksi secara online atau offline akan mendapat perlindungan yang sama,” kata dia.\n" +
                    "\n" +
                    "Konsumen pun, menurut Emil, penting untuk diedukasi terkait harga dan kualitas barang, serta agar menjadi konsumen cerdas yang tidak mudah ditipu oknum pedagang nakal.\n" +
                    "\n" +
                    "“Edukasi ini yang kemudian kami perlu terobosan dan ide-ide segar di ajang Harkonas 2020,” imbuh dia.\n" +
                    "\n" +
                    "Peringatan Harkonas tahun ini sendiri adalah kerja sama Direktorat Jenderal Perlindungan Konsumen dan Tata Niaga Kementerian Perdagangan RI dengan Pemerintah Provinsi Jatim dan Badan Perlindungan Konsumen Nasional.(*)\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribun-timur.com dengan judul Sejarah Hari Konsumen Nasional yang Diperingati Setiap 20 April, https://makassar.tribunnews.com/2020/04/20/sejarah-hari-konsumen-nasional-yang-diperingati-setiap-20-april?page=all.\n" +
                    "Penulis: Desi Triana Aswan\n" +
                    "Editor: Anita Kusuma Wardana ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  21 April: Hari Kartini")){
            infoBulan.setText("tirto.id - Kartini menjadi salah satu sosok penting dalam emansipasi wanita di Indonesia. Oleh karena itu lah, tanggal 21 April yang juga merupakan hari lahir perempuan asal Jepara, Jawa Timur, tersebut diperingati setiap tahunnya sebagai Hari Kartini untuk mengenang jasa-jasanya dalam kesetaraan gender. Peringatan Hari Kartini tersebut dirayakan setelah 2 Mei 1964, usai Presiden Soekarno mengeluarkan Keputusan Presiden Republik Indonesia No.108 Tahun 1964. Dalam keputusan tersebut, Kartini juga ditetapkan sebagai Pahlawan Kemerdekaan Nasional. Raden Ajeng Kartini lahir pada tanggal 21 April 1879, dan berasal dari kalangan bangsawan Jawa. Ia merupakan putri dari bupati Jepara bernama Raden Mas Adipati Ario Sosroningrat dengan M.A. Ngasirah. Kakek Kartini, Pangeran Ario Tjondronegoro IV dikenal pada pertengahan abad ke-19 sebagai salah satu bupati pertama yang memberi pendidikan Barat kepada anak-anaknya. Sementara itu Sosrokartono, kakak Kartini, merupakan orang yang pandai dalam bidang bahasa. Hingga usianya yang ke 12 tahun, ia diperbolehkan bersekolah di ELS (Europese Lagere School) di mana Kartini belajar bahasa Belanda. Setelahnya, ia terpaksa meninggalkan sekolah karena sudah bisa dipingit untuk kemudian menunggu calon suaminya melamar. Semasa lajang sebagai perempuan mandiri, Kartini telah melahirkan sejumlah tulisan, seperti “Upacara Perkawinan pada Suku Koja” yang terbit di Holandsche Lelie saat berusia 14 tahun. Selama masa pingit yang ia jalani, ia mulai belajar sendiri dan menulis surat kepada teman-teman korespondensi dari Belanda menggunakan kemampuan berbahasa Belanda yang ia miliki. Salah satu temannya adalah Rosa Abendanon yang banyak mendukungnya. Dilansir Intersections, surat-surat yang dikirimkan menguraikan pemikiran Kartini terkait berbagai masalah termasuk tradisi feudal yang menindas, pernikahan paksa dan poligami bagi perempuan Jawa kelas atas, dan pentingnya pendidikan bagi anak perempuan. Di sisi lain, surat-surat tersebut juga mencerminkan pengalaman hidup Kartini sebagai putri seorang bupati Jawa. Dari buku-buku, koran, dan majalah Eropa yang dibacanya, Kartini tertarik pada kemajuan berpikir para perempuan Eropa. Oleh sebab itu lah, timbul keinginannya untuk memajukan perempuan pribumi yang memiliki status sosial yang rendah salah satunya karena pendidikan yang terbatas. Tidak lama, Kartini dijodohkan oleh orang tuanya dengan bupati Rembang bernama K.R.M Adipati Ario Singgih Djojo Adhiningrat yang pernah memiliki tiga istri. Suami Kartini memberikan izin kepadanya untuk mendirikan sekolah wanita. Setelah pernikahannya dengan bupati Rembang, Raden Adipati Djojodiningrat, Kartini merasakan horison pemikirannya berkembang. “Di rumah orang tua saya dulu, saya sudah tahu banyak. Tetapi di sini, di mana suami saya bersama saya memikirkan segala sesuatu, di mana saya turut menghayati seluruh kehidupannya, turut menghayati pekerjaannya, usahanya, maka saya jauh lebih banyak lagi menjadi tahu tentang hal-hal yang mula-mula tidak saya ketahui. Bahkan tidak saya duga, bahwa hal itu ada”, tulis Kartini kepada Nyonya Abendanon yang menjadi sahabat penanya (Surat kepada Ny. R.M. Abendanon-Mandri, 10 Agustus 1904). Kartini meninggal usai melahirkan anaknya, Soesalit Djojoadhiningrat, tanggal 17 September 1904 di usia 25 tahun. Sepeninggalnya, J.H. Abendanon, yang juga merupakan Menteri Kebudayaan, Agama, dan Kerajinan Hindia Belanda tahun 1900-1905, mengumpulkan surat-surat yang pernah dikirimkan R.A Kartini pada teman-temannya di Eropa. Buku pertamanya diberi judul Door Duisternis tot Licht yang berarti Dari Kegelapan Menuju Cahaya, yang diterbitkan pada 1911. Di tahun 1922, Balai Pustaka menerbitkan buku tersebut dalam bahasa Melayi dengan judul Habis Gelap Terbitlah Terang: Boeah Pikiran. Kemudian tahun 1938, keluarlah Habis Gelap Terbitlah Terang versi Armijn Pane, seorang sastrawan Pujangga Baru. Sementara itu, surat-surat Kartini dalam bahasa Inggris juga pernah diterjemahkan oleh Agnes L. Symmers. Terbitnya surat-surat Kartini sangat menarik perhatian masyarakat Belanda. Di sisi lain, pemikiran-pemikiran Kartini juga mulai mengubah pandangan masyarakat Belanda terhadap perempuan pribumi di Jawa. Salah satunya adalah Van Deventer, seorang tokoh politik etis atau politik balas budi. Ketika surat-surat Kartini diterbitkan pada tahun 1911, Van Deventer terkesan sehingga tergerak untuk menulis sebuah resensi untuk menyebarluaskan cita-cita Kartini. Cita-cita Kartini tersebut ia rasa cocok dengan cita-cita Deventer sendiri yakni mengangkat bangsa pribumi secara rohani dan ekonomis, serta memperjuangkan emansipasi mereka. Sesudah Van Deventer meninggal di tahun 1915, istrinya mendirikan Yayasan Kartini untuk membuka sekolah-sekolah bagi wanita pribumi. Nyonya Deventer sendirilah yang mengurus segala-galanya hingga ribuan murid puteri pun memasuki Sekolah Kartini yang bernaung dibawah Yayasan Kartini.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Kartini 21 April dan Catatan Pemikirannya\", https://tirto.id/ePG3");
        }else if(tanggal.equalsIgnoreCase("Tanggal  22 April: Hari Bumi")){
            infoBulan.setText("Hari Bumi adalah hari pengamatan tentang bumi yang dicanangkan setiap tahun pada tanggal 22 April dan diperingati secara internasional.[1][2] Hari Bumi dirancang untuk meningkatkan kesedaran dan apresiasi terhadap planet yang ditinggali manusia ini yaitu bumi. Dicanangkan oleh Senator Amerika Serikat Gaylord Nelson pada tahun 1970 seorang pengajar lingkungan hidup. Tanggal ini bertepatan pada musim semi di Northern Hemisphere (belahan Bumi utara) dan musim gugur di belahan Bumi selatan. PBB sendiri merayakan hari Bumi pada 20 Maret sebuah tradisi yang dicanangkan aktivis perdamaian John McConnell pada tahun 1969, adalah hari di mana matahari tepat di atas khatulistiwa yang sering disebut Ekuinoks Maret.\n" +
                    "\n" +
                    "Kini hari bumi diperingati di lebih dari 175 negara dan dikoordinasi secara global oleh Jaringan Hari Bumi (Earth Day Network).[3] ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  23 April: Hari Buku")){
            infoBulan.setText("Hari buku intenasional penjelasan:\n" + "\n Hari Buku Sedunia, dikenal pula dengan Hari Buku dan Hak Cipta Sedunia dan Hari Buku Internasional, merupakan hari perayaan tahunan yang jatuh pada tanggal 23 April yang diadakan oleh UNESCO untuk mempromosikan peran membaca,[1] penerbitan, dan hak cipta. Di Inggris, hari perayaan ini jatuh pada hari Kamis pertama setiap bulan Maret. Hari Buku Sedunia dirayakan pertama sekali pada tanggal 23 April 1995. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  24 April: Hari Angkutan Nasional")){
            infoBulan.setText("TRIBUNKALTIM.CO - Sejarah hari ini, setiap tanggal 24 April diperingati sebagai Hari Angkutan Nasional.\n" +
                    "\n" +
                    "Meski diperingati setiap tahun pada tanggal 24 April, namun tidak semua orang mengetahui adanya Hari Angkutan Nasional.\n" +
                    "\n" +
                    "Mengutip sejarahlengkap.com, informasi mengenai sejarah Hari Angkutan Nasional sulit didapatkan sehingga tidak diketahui apa dan bagaimana awal mula dari ditetapkannya hari besar ini.\n" +
                    "\n" +
                    "Yang lebih dikenal justru Hari Perhubungan Nasional pada 17 September.\n" +
                    "\n" +
                    "Akibatnya masyarakat menyambut dingin akan datangnya peringatan Hari Angkutan Nasional.\n" +
                    "\n" +
                    "Sebab, banyak yang tidak mengetahui bahwa sejarah Hari Angkutan Nasional bahkan memang ada untuk diperingati, walaupun ada juga sejarah museum angkut dari salah satu objek wisata di Malang.\n" +
                    "\n" +
                    "Kisah DAMRI\n" +
                    "\n" +
                    "Sejak zaman penjajahan hingga sekarang angkutan umum sudah ada di Indonesia.\n" +
                    "\n" +
                    "Berikut kisahnya sebagaimana dirangkum TribunSolo.com dari berbagai sumber:\n" +
                    "\n" +
                    "Angkutan umum pertama sejak Republik ini berdiri adalah DAMRI.\n" +
                    "\n" +
                    "DAMRI, singkatan dari Djawatan Angkoetan Motor Repoeblik Indonesia (EYD: Jawatan Angkutan Motor Republik Indonesia).\n" +
                    "Bus DAMRI.\n" +
                    "Bus DAMRI. (Tribun Lampung/Heru Prasetyo)\n" +
                    "\n" +
                    "Dikutip dari Wikipedia, tahun 1943, terdapat dua usaha angkutan di zaman pendudukan Jepang, yaitu Jawa Unyu Zigyosha yang mengkhususkan diri pada angkutan barang dengan truk, gerobak atau cikar.\n" +
                    "\n" +
                    "Dan juga terdapat Zidosha Sokyoku yang melayani angkutan penumpang dengan kendaraan bermotor atau bus.\n" +
                    "\n" +
                    "Pada 1945, setelah Indonesia merdeka, dibawah pengelolaan Departemen Perhubungan RI, Jawa Unyu Zigyosha berubah nama menjadi Djawatan Pengangkoetan untuk Angkutan Barang.\n" +
                    "\n" +
                    "Sedangkan Zidosha Sokyoku beralih menjadi Djawatan Angkutan Darat untuk angkutan penumpang.\n" +
                    "\n" +
                    "Pada 25 November 1946, kedua jawatan itu digabungkan berdasarkan Maklumat Menteri Perhubungan RI No.01/DAM/46 sehingga dibentuklah \"Djawatan Angkoetan Motor Repoeblik Indonesia\", disingkat DAMRI.\n" +
                    "\n" +
                    "Tugas utama DAMRI adalah menyelenggarakan pengangkutan darat dengan bus, truk, dan angkutan bermotor lainnya.\n" +
                    "\n" +
                    "Tugas tersebut menjadikan semangat kesejarahan DAMRI yang telah memainkan peranan aktif dalam kiprah perjuangan mempertahankan kemerdekaan melawan agresi Belanda di Jawa.\n" +
                    "\n" +
                    "Tahun 1961, terjadi peralihan status DAMRI menjadi Badan Pimpinan Umum Perusahaan Negara (BPUPN) berdasarkan Peraturan Pemerintah No. 233 Tahun 1961.\n" +
                    "\n" +
                    "Kemudian pada tahun 1965 BPUPN dihapus dan DAMRI ditetapkan menjadi Perusahaan Negara (PN).\n" +
                    "\n" +
                    "Tahun 1982, DAMRI beralih status menjadi Perusahaan Umum (PERUM) dan berkelanjutan hingga saat ini, di mana PERUM DAMRI diberi tugas dan wewenang untuk menyelenggarakan jasa angkutan umum untuk penumpang dan atau barang di atas jalan dengan kendaraan bermotor.\n" +
                    "\n" +
                    "Saat ini, DAMRI merupakan salah satu perusahaan yang dimiliki pemerintah dibawah Kementerian Badan Usaha Milik Negara (BUMN).\n" +
                    "\n" +
                    "Masalah Mengenai Angkutan Umum\n" +
                    "\n" +
                    "Di balik peringatan Hari Angkutan Nasional masih terselip masalah esensial mengenai sarana angkutan umum di Indonesia.\n" +
                    "\n" +
                    "Bagi masyarakat dimanapun, ketergantungan terhadap angkutan sangat tinggi untuk mendukung mobilitas mereka sehingga keberadaan sarana angkutan umum yang memadai sangat dibutuhkan.\n" +
                    "\n" +
                    "Sebagian besar masyarakat masih menggantungkan diri pada angkutan umum sebagai sarana transportasinya.\n" +
                    "\n" +
                    "Namun, kondisi sarana angkutan umum di Indonesia masih sangat jauh dari kata baik sehingga orang-orang lebih memilih menggunakan dan membeli kendaraan pribadi.\n" +
                    "Kendaraan berjalan merayap saat terjadi kepadatan di pintu Tol Pasteur, Kota Bandung, Sabtu (10/9/2016). Kepadatan terjadi akibat warga luar Kota Bandung mengisi libur panjang dan libur Idul Adha. Bandung termasuk salah satu kota di Indonesia yang mendapat indeks kepuasan pengendara rendah.\n" +
                    "Kendaraan berjalan merayap saat terjadi kepadatan di pintu Tol Pasteur, Kota Bandung, Sabtu (10/9/2016). Kepadatan terjadi akibat warga luar Kota Bandung mengisi libur panjang dan libur Idul Adha. Bandung termasuk salah satu kota di Indonesia yang mendapat indeks kepuasan pengendara rendah. (TRIBUN JABAR/GANI KURNIAWAN)\n" +
                    "\n" +
                    "Sebagai akibatnya, jalanan dipenuhi oleh mobil pribadi dan motor yang pada akhirnya menimbulkan kemacetan tiada akhir di berbagai penjuru kota.\n" +
                    "\n" +
                    "Bukan hanya itu saja, berbagai masalah yang ada pada angkutan umum masih membuat para pengguna akhirnya merasa tidak nyaman.\n" +
                    "\n" +
                    "Rendahnya kedisiplinan dan juga peraturan yang kurang ditegaskan membuat kondisi dunia angkutan umum di semua moda transportasi menjadi kurang kondusif, contohnya:\n" +
                    "\n" +
                    "    Masih terdapat kejadian pelecehan seksual dan gangguan lain berupa ancaman kejahatan pada perempuan di angkutan umum.\n" +
                    "    Kondisi kendaraan yang buruk dan tidak laik jalan seringkali ditemukan pada kendaraan umum seperti bus kota sehingga membahayakan penumpang.\n" +
                    "    Kerap terjadi kecelakaan sebagai kombinasi dari manajemen yang buruk, human error dan kondisi kendaraan yang tidak layak.\n" +
                    "    Supir yang tidak mengalami pelatihan mengemudi yang layak dan cara menghadapi penumpang dengan baik.\n" +
                    "    Menunggu angkutan umum memerlukan waktu lama sekali, harus berdesakan dan berjejalan.\n" +
                    "    Calo tiket yang selalu mengambil keuntungan terutama ketika musim puncak liburan .\n" +
                    "    Harga tiket yang mahal dan tidak efektif.\n" +
                    "    Perilaku supir yang kurang terpuji seperti menyetir ugal – ugalan.\n" +
                    "    Pengamen dan pedagang yang bebas keluar masuk angkutan umum terutama bus dan kereta.\n" +
                    "    Tidak terjaganya kebersihan sarana angkutan.\n" +
                    "    Kurangnya etika sesama penumpang di angkutan umum, misalnya tidak mengetahui dan memberi kemudahan pada penumpang prioritas seperti ibu hamil, ibu dengan anak, penyandang cacat dan lansia.\n" +
                    "    Kurangnya fasilitas yang memudahkan penumpang prioritas menaiki kendaraan umum.\n" +
                    "\n" +
                    "Apabila diurutkan masih banyak masalah yang carut marut terjadi walaupun Hari Angkutan Nasional diperingati setiap tahunnya.\n" +
                    "\n" +
                    "Bukti bahwa kondisi angkutan kita belum dibenahi dengan serius adalah masih banyaknya terjadi kecelakaan yang melibatkan kendaraan umum di darat, laut maupun udara.\n" +
                    "\n" +
                    "Selain itu kebijakan yang tidak konsisten dan selalu berganti setelah adanya pergantian pemimpin atau pemegang kebijakan juga turut mempengaruhi.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunkaltim.co dengan judul SEJARAH HARI INI Peringatan Hari Angkutan Nasional, Terkuak Kisah Angkutan Umum Pertama di Indonesia, https://kaltim.tribunnews.com/2019/04/24/sejarah-hari-ini-peringatan-hari-angkutan-nasional-terkuak-kisah-angkutan-umum-pertama-di-indonesia?page=all.\n" +
                    "Penulis: Syaiful Syafar\n" +
                    "Editor: Ayuk Fitri\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunkaltim.co dengan judul SEJARAH HARI INI Peringatan Hari Angkutan Nasional, Terkuak Kisah Angkutan Umum Pertama di Indonesia, https://kaltim.tribunnews.com/2019/04/24/sejarah-hari-ini-peringatan-hari-angkutan-nasional-terkuak-kisah-angkutan-umum-pertama-di-indonesia?page=all.\n" +
                    "Penulis: Syaiful Syafar\n" +
                    "Editor: Ayuk Fitri ");
        }else if(tanggal.equalsIgnoreCase("Tanggal  24 April: Hari Solidaritas Asia-Afrika")){
            infoBulan.setText("\n" +
                    "Jakarta, CNN Indonesia -- Bertepatan dengan usainya peringatan 60 tahun Konferensi Asia-Afrika, tanggal 24 April ditetapkan sebagai Hari Solidaritas Asia Afrika.\n" +
                    "\n" +
                    "Menteri Luar Negeri RI Retno Marsudi menyatakan penetapan ini merupakan upaya mengukuhkan penetapan kota Bandung sebagai ibu kota solidaritas Asia-Afrika.\n" +
                    "\n" + "Bandung sudah lama dikenal sebagai ibu kota Asia-Afrika sudah lama, maka upaya kita hanya untuk mengukuhkan,\" kata Retno seusai rangkaian acara peringatan 60 tahun KAA di Jakarta, Kamis (23/4).\n" +
                    "\n" +
                    "\n" +
                    "Dalam kesempatan tersebut, Retno juga memaparkan rencana pembangunan Pusat Asia-Afrika. Namun hingga saat ini belum dipastikan di mana pusat tersebut akan dibangun.\n" +
                    "\n" +
                    "\"Itu nanti akan dibangun...tetapi kami tidak terikat dulu pada satu bangunan dulu yang fix. Itu sambil berjalan,\" ujar Retno.\n" +
                    "\n" +
                    "Retno memaparkan bahwa rencana tersebut akan ditindaklanjuti dengan berbagai program yang akan dijalankan di sana, seperti program kerja sama Selatan-Selatan yang menjadi tema besar dalam peringatan 60 tahun KAA.\n" +
                    "\n" +
                    "\"Ini juga sebenarnya bukan hal yang baru bagi Indonesia karena Indonesia sudah sangat aktif di dalam pelaksanaan kerjasama Selatan-Selatan,\" kata Retno.\n" +
                    "\n" +
                    "Perhelatan peringatan 60 tahun KAA akan dilanjutkan di Bandung pada Jumat (24/4). Peringatan 60 tahun KAA di Bandung akan diisi beberapa agenda, diantaranya napak tilas dari Hotel Savoy Homann menuju Gedung Merdeka via Jalan Asia Afrika, pidato Presiden Republik Indonesia dan kepala negara yang mewakili Asia dan Afrika serta penandatanganan Pesan Bandung. (utd/utd)\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal  26 April: Hari Kesiapsiagaan Bencana Nasional[16]")){
            infoBulan.setText("\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"26 April, Hari Kesiapsiagaan Bencana\", https://www.kompas.com/skola/read/2020/04/26/120000069/26-april-hari-kesiapsiagaan-bencana?page=all.\n" +
                    "Penulis : Arum Sutrisni Putri\n" +
                    "Editor : Arum Sutrisni Putri");
        }else if(tanggal.equalsIgnoreCase("Tanggal  27 April: Hari Permasyarakatan Indonesia")){
            infoBulan.setText("tirto.id - Tanggal 27 April diperingati sebagai Hari Pemasyarakatan Indonesia atau Hari Bhakti Pemasyarakatan (HBP). Peringatan HBP tahun 2020 ini akan dilaksanakan serentak secara virtual dengan memperhatikan protokol kesehatan penyebaran virus corona COVID-19. Menurut Kementerian Hukum dan Ham (Kemenkumham), peringatan ke HBP ke-56 tahun ini akan sangat berbeda karena adanya COVID-19. Namun hal tersebut tidak akan menurunkan semangat jajaran Pemasyarakatan untuk tetap memberikan pelayanan prima kepada narapidana. Dalam hal ini, semua aspek pemasyarakatan akan terus melakukan upaya-upaya dalam rangka penyelamatan, pencegahan, dan penanggulangan penyebaran COVID-19 di unit pelaksana teknis Pemasyarakatan. Salah satu bentuk upayanya adalah program asimilasi dan integrasi. Pada 20 April 2020 sebanyak 38.822 narapidana dewasa dan anak telah dikeluarkan atau dibebaskan dari lembaga pemasyarakatan, rumah tahanan, dan lembaga pembinaan khusus anak. Pada HBP tahun ini, warga binaan di seluruh Indonesia secara serentak menyerahkan hasil karya berupa alat pelindung diri (APD) kepada para tenaga medis dan masyarakat yang membutuhkan, terkait penanganan COVID-19 di Tanah Air. Penyerahan hasil karya tersebut dilakukan dalam kegiatan bertajuk Bakti Sosial Narapidana untuk Negeri. \"Dari warga binaan kami di seluruh Indonesia untuk membantu penanganan COVID-19, berupa perlengkapan alat pelindung diri (APD), dan sarana pendukung pencegahan penyebaran COVID-19 lainnya yang memang saat ini sangat dibutuhkan, khususnya oleh insan medis dan masyarakat umum lainnya,\" ujar Pelaksana Tugas Direktur Jenderal Pemasyarakatan Nugroho dalam keterangan tertulis, di Jakarta, Jumat (24/7/2020). Sekitar 40 ribu perangkat APD berupa gown, masker, pelindung muka, penutup kepala, sepatu boot, cairan disinfektan, sarung tangan, pembersih tangan, serta tiang infus telah diproduksi warga binaan dan disumbangkan kepada masyarakat dan instansi terkait, khususnya tenaga medis. Pada Kamis (23/4), sebanyak 9.463 APD diserahkan ke rumah sakit khusus penanganan Pasien COVID-19, Wisma Atlet, Kemayoran, Jakarta. Perangkat APD yang diserahkan yakni 500 buah gown, 1.515 masker berstandar Kementerian Kesehatan, 400 buah pelindung wajah, 450 buah pelindung sepatu, serta 1.118 sarung tangan dan pembersih tangan. Bantuan itu diterima langsung oleh Asisten Operasional Komando Tugas Gabungan Terpadu (Kogasgapad) Rumah Sakit Darurat COVID-19 Kol Inf Prabowo Setiaji. Pada hari yang sama, Nugroho menyerahkan hasil karya warga binaan kepada masyarakat di wilayah Tangerang, dirangkaikan dengan kegiatan pemberian bantuan sosial Kementerian Hukum dan HAM, dan dihadiri Kepala Kantor Wilayah Kemenkumham Banten Imam Suyudi, serta Wakil Wali Kota Tangerang Sachrudin. \"Kegiatan ini adalah bagian dari keinginan tulus warga binaan dan petugas kami untuk memberikan kontribusi bagi negeri dalam pencegahan dan penanganan COVID-19 telah menjadi bencana nonalam yang juga melanda dunia,\" kata Nugroho. Dia menyampaikan bahwa kegiatan bansos tersebut serentak dilakukan oleh lembaga pemasyarakatan (lapas), rumah tahanan negara (rutan), lembaga pembinaan khusus anak (LPKA), balai pemasyarakatan (bapas), dan rumah penyimpanan benda sitaan negara (rupbasan) yang berkolaborasi memberikan donasi kepada masyarakat dan pihak yang membutuhkan. Selain perangkat APD, warga binaan juga menyumbangkan hasil produksi ketahanan pangan, seperti sayur, buah-buahan, ikan, dan telur. Nugroho mengatakan sumbangan tersebut diberikan kepada masyarakat yang terdampak COVID-19 dan warga binaan yang sedang menjalankan program asimilasi di rumah. Selain itu, APD dan sarana pendukung karya warga binaan juga didonasikan ke puskemas, rumah sakit, panti asuhan, kaum dhuafa, dan masyarakat umum lainnya yang membutuhkan, serta aparat penegak hukum yang kerap bersentuhan langsung dalam pencegahan dan penanganan COVID-19. \"Sebagai bagian dari masyarakat Indonesia, inilah sumbangsih warga binaan kami untuk negeri, dari jemari dan tangan mereka yang menghasilkan karya manfaat, diharapkan dapat membantu meringankan dampak dari pandemik ini,\" ujar Nugroho. \"Kami memahami bahwa bantuan ini tidak dapat sepenuhnya memenuhi kebutuhan warga untuk jangka waktu yang cukup lama. Namun kami berharap dapat sedikit meringankan dalam penanganan COVID-19 di Indonesia,\" kata dia pula. Sejarah Hari Pemasyarakatan Hari ini tepat 56 tahun sistem pemasyarakatan lahir sebagai sistem perlakuan terhadap narapidana, di mana momentum peringatan ini akan selalu dijadikan sebagai instropeksi sekaligus memperkokoh komitmen seluruh Insan Pemasyarakatan dalam mewujudkan tujuan sistem Pemasyarakatan. Istilah pemasyarakatan pertama kali diungkap oleh Menteri Kehakiman Sahardjo pada 5 Juli 1963. Ia menyatakan bahwa Pemasyarakatan merupakan tujuan dari pidana penjara. Dalam prosesnya kemudian, Pemasyarakatan mengganti istilah Kepenjaraan dengan tujuan Pemasyarakatan sebagai suatu pengejawantahan keadilan yang bertujuan untuk mencapai reintegrasi sosial dalam pembinaan Warga Binaan Pemasyarakatan. Konsep ini kemudian dikokohkan dalam Undang-Undang Nomor 12 Tahun 1995 tentang Pemasyarakatan. Dinas Perhubungan Karawang menjelaskan, fungsi dari lembaga pemasyarakat ini akan selalu dipastikan memenuhi hak napi sebagai manusia, di mana di dalam lembaga permasyarakan nantinya para napi akan mendapatkan pembinaan khusus seperti keterampilan, pembentukan akhlak, penguatan mental dan masih banyak yang lainnnya lagi.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Bhakti Pemasyarakatan yang Diperingati 27 April\", https://tirto.id/fa8n");
        }else if(tanggal.equalsIgnoreCase("Tanggal  28 April: Hari Puisi Nasional")){
            infoBulan.setText("");
        }
    }
}
