package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilDesember extends AppCompatActivity {
    String DESEMBER;
    TextView infoBulan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_desember);
        // ambil textview info di acivity
        infoBulan=(TextView) findViewById(R.id.info_desember);

        // ambil parameter
        Intent intent = getIntent();
        DESEMBER = intent.getStringExtra("desember");

        // panggil
        setDESEMBER(DESEMBER);
    }
    private void setDESEMBER(String tanggal) {
        if(tanggal.equalsIgnoreCase("Tanggal 1 Desember: Hari AIDS Sedunia")){
            infoBulan.setText("Hari Buruh pada umumnya dirayakan pada tanggal 1 Mei, dan dikenal dengan sebutan May Day.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 3 Desember: Hari Penyandang Cacat Internasional")){
            infoBulan.setText("......");
        }else if(tanggal.equalsIgnoreCase("Tanggal 4 Desember: Hari Artileri")){
            infoBulan.setText("......");
        }else if(tanggal.equalsIgnoreCase("Tanggal 5 Desember: Hari Armada")){
            infoBulan.setText("erbentuknya organisasi militer Indonesia yang dikenal dengan Tentara Kemanan Rakyat (TKR) menjadi asal usul berdirinya Komando Armada Angkatan Laut Indonesia (ALRI). ALRI merupakan bagian dari TKR, yang dahulu dikenal dengan TKR Laut.\n" +
                    "\n" +
                    "TKR Laut pun sempat mengalami perubahan nama, dari Tentara Republik Indonesia Laut (TRI Laut) hingga akhirnya menjadi ALRI.\n" +
                    "\n" +
                    "Selanjutnya, setelah kualitas unsur armada semakin canggih dan modern serta kuantitasnya semakin besar. Maka terbentuklah sebuah Komando Armada, yang berdasarkan SK KSAL No. A. 4/2/10 tanggal 14 September 1959 diresmikan pembentukannya pada 5 Desember 1959 oleh KSAL Komodor Laut R.E. Martadinata. Setiap tanggal tersebut pun diperingati sebagai Hari Armada RI. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 9 Desember: Hari Anti Korupsi")){
            infoBulan.setText("Jakarta - Hari Antikorupsi sedunia diperingati setiap tanggal 9 Desember. Melalui resolusi 58/4 pada 31 Oktober 2003, PBB menetapkan 9 Desember sebagai Hari Antikorupsi Internasional.\n" +
                    "\n" +
                    "\n" +
                    "Korupsi menurut kamus besar bahasa Indonesia adalah penyelewengan atau penyalahgunaan uang negara (perusahaan, organisasi, yayasan, dan sebagainya) untuk keuntungan pribadi atau orang lain. Peringatan ini dimulai setelah Konvensi PBB Melawan Korupsi pada 31 Oktober 2003 untuk meningkatkan kesadaran anti korupsi.\n" +
                    "\n" +
                    "\n" +
                    "Majelis itu mendesak semua negara dan organisasi integrasi ekonomi regional yang kompeten untuk menandatangani dan meratifikasi Konvensi PBB melawan Korupsi. Hal itu dilakukan untuk memastikan pemberlakuan Hari Anti Korupsi Sedunia secepatnya.\n" +
                    "\n" +
                    "Baca juga:\n" +
                    "Di Hari Antikorupsi, Ketua MPR Bamsoet Soroti Asset Recovery\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Bagaimana dengan di Indonesia? Dilansir dari laman Anti-Corruption Clearing House (ACCH) milik Komisi Pemberantasan Korupsi (KPK), perjalanan panjang memberantas korupsi di Indonesia seperti mendapatkan angin segar ketika muncul sebuah lembaga negara yang memiliki tugas dan kewenangan yang jelas untuk memberantas korupsi. Meskipun sebelumnya, ini dibilang terlambat dari agenda yang diamanatkan oleh ketentuan Pasal 43 UU Nomor 31 Tahun 1999 sebagaimana telah diubah dengan UU Nomor 20 Tahun 2001, pembahasan RUU KPK dapat dikatakan merupakan bentuk keseriusan pemerintahan Megawati Soekarnoputri dalam pemberantasan korupsi.\n" +
                    "\n" +
                    "\n" +
                    "Keterlambatan pembahasan RUU tersebut dilatarbelakangi oleh banyak sebab. Pertama, perubahan konstitusi uang berimplikasi pada perubahan peta ketatanegaraan. Kedua, kecenderungan legislative heavy pada DPR. Ketiga, kecenderungan tirani DPR. Keterlambatan pembahasan RUU KPK salah satunya juga disebabkan oleh persoalan internal yang melanda sistem politik di Indonesia pada era Reformasi.\n" +
                    "\n" +
                    "\n" +
                    "Di era Presiden SBY, visi pemberantasan korupsi tercermin dari langkah awal yang dilakukannya dengan menerbitkan Instruksi Presiden Nomor 5 Tahun 2004 dan kemudian dilanjutkan dengan penyiapan Rencana Aksi Nasional Pemberantasan Korupsi (RAN) yang disusun oleh Bappenas.\n" +
                    "\n" +
                    "\n" +
                    "RAN Pemberantasan Korupsi itu berlaku pada tahun 2004-2009. Dengan menggunakan paradigma sistem hukum, pemerintah Susilo Bambang Yudhoyono diuntungkan sistem hukum yang mapan, keberadaan KPK melalui Undang-undang Nomor 30 Tahun 2002, Pengadilan Tindak Pidana Korupsi (Tipikor) yang terpisah dari pengadilan umum, dukungan internasional (structure), dan instrument hukum yang saling mendukung antara hukum nasional dan hukum internasional.\n" +
                    "\n" +
                    "\n" +
                    "Pada era saat ini, Presiden Jokowi belum memutuskan penerbitan Perppu KPK. Jokowi masih ingin mengevaluasi program-program terkait pencegahan-pemberantasan korupsi.\n" +
                    "\n" +
                    "\n" +
                    "Peringatan Hari Antikorupsi\n" +
                    "\n" +
                    "\n" +
                    "Di Jakarta, Hari Antikorupsi Sedunia digelar di Gedung Merah Putih KPK. Acara dihadiri sejumlah pejabat pemerintah pusat, seperti Wakil Presiden Ma'ruf Amin, Menko Polhukam Mahfud MD, Menteri PAN-RB Tjahjo Kumolo, dan Menkominfo Johnny G Plate.\n" +
                    "\n" +
                    "\n" +
                    "Beberapa kepala daerah juga tampak hadir, antara lain Gubernur Jawa Tengah Ganjar Pranowo, Gubernur Jawa Timur Khofifah Indar Parawansa, dan Wali Kota Bogor Bima Arya Sugiarto. Beberapa toloh lainnya juga terlihat hadir, seperti Ketua MPR Bambang Soesatyo, Ketua DPD La Nyalla Mattaliti, Ketua DPP PDI-P Djarot Saiful Hidayat, dan Kepala Baharkam Polri yang juga Ketua KPK terpilih, Komjen Firli Bahuri.\n" +
                    "\n" +
                    "\n" +
                    "Sementara Presiden Jokowi menghadiri menghadiri pentas Prestasi Tanpa Korupsi di SMKN 57, Jakarta. Pada acara ini, tiga menteri Jokowi beradu peran dalam drama antikorupsi. Mereka adalah Menteri Pendidikan dan Kebudayaan Nadiem Makarim, Menteri Pariwisata dan Ekonomi Kreatif (Menparekraf) Wishnutama, dan Menteri BUMN Erick Thohir.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 10 Desember: Hari Hak Asasi Manusia")){
            infoBulan.setText("KOMPAS.com - Hari Hak Asasi Manusia (HAM) Internasional diperingati setiap 10 Desember. Melansir laman United Nations, tahun ini, tema yang diangkat adalah Youth Standing Up for Human Rights atau Pemuda Membela Hak Asasi Manusia. Dengan tema tersebut, peringatan HAM tahun ini salah satunya bertujuan untuk merayakan potensi pemuda sebagai agen perubahan konstruktif, menguatkan suara pemuda, dan melibatkan mereka dalam jangkauan yang lebih luas untuk mempromosikan perlindungan atas hak- hak asasi manusia. Kampanye ini dipimpin oleh Office of the High Commissioner for Human Rights (OHCHR) dan didesain untuk mendorong serta menunjukkan bagaimana kaum muda di seluruh dunia membela hak-hak dalam melawan rasisme, ujaran kebencian, perundungan, diskriminasi, dan perubahan cuaca. Pemuda dipilih sebagai tokoh utama dalam peringatan tahun ini karena alasan-alasan berikut: Partisipasi pemuda sangat penting untuk mencapai pembangunan berkelanjutan untuk semua Pemuda memainkan peranan penting dalam perubahan yang positif Memberdayakan pemuda untuk mengenal lebih dan mengklaim hak-hak mereka dan menghasilkan manfaat secara global Baca juga: Mengenang HS Dillon, dari Pejuang HAM hingga Turban Khasnya yang Ikonik Sejarah Hari HAM Hari HAM dirayakan oleh masyarakat internasional setiap tahunnya pada tanggal 10 Desember. Peringatan ini adalah untuk mengenang hari diadopsinya Deklarasi Universal Hak Asasi Manusia tahun 1948. Dokumen deklarasi ini terdiri atas bagian Pembukaan dan 30 Pasal yang mengatur tentang Hak Asasi Manusia. Melansir laman OHCHR, peringatan ini secara resmi dimulai dari tahun 1950, setelah Majelis Umum meloloskan resolusi 423 dan mengundang seluruh negara ataupun organisasi yang tertarik untuk mengadopsi 10 Desember sebagai Hari HAM tiap tahunnya. Ketika Majelis Umum mengadopsi dekrarasi ini, 48 negara mendukung dan 8 negara abstain. Deklarasi ini kemudian dinyatakan sebagai standar umum pencapaian bagi semua bangsa.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Diperingati Tiap 10 Desember, Ini Sejarah Hari HAM Internasional\", https://www.kompas.com/tren/read/2019/12/10/133000365/diperingati-tiap-10-desember-ini-sejarah-hari-ham-internasional.\n" +
                    "Penulis : Vina Fadhrotul Mukaromah\n" +
                    "Editor : Sari Hardiyanto Penulis Vina Fadhrotul Mukaromah | Editor Sari Hardiyanto Setiap individu dan masyarakat harus berjuang dengan langkah-langkah progresif, nasional, dan internasional, untuk memperoleh pengakuan dan ketaatan yang universal dan efektif. Meskipun Deklarasi ini tidak mengikat, dokumen ini mengilhami lebih dari 60 instrumen Hak Asasi Manusia membentuk standar HAM internasional. Hari ini, persetujuan umum dari semua Negara Anggota PBB tentang Hak Asasi Manusia yang tercantum dalam Deklarasi membuatnya semakin kuat. Dokumen ini pun menekankan relevansi Hak Asasi Manusia dalam kehidupan kita sehari-hari. Hingga kini, dokumen deklarasi HAM telah diterjemahkan ke dalam lebih dari 500 bahasa. Setelah 71 tahun dokumen ini diadopsi, Deklarasi HAM masih menjadi dasar ketika menemukan hal ataupun tantangan baru dalam pemenuhan hak-hak asasi manus Baca juga: Sepak Terjang Yasonna Laoly, dari Politisi, Menkumham hingga Guru Besar Kriminologi\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Diperingati Tiap 10 Desember, Ini Sejarah Hari HAM Internasional\", https://www.kompas.com/tren/read/2019/12/10/133000365/diperingati-tiap-10-desember-ini-sejarah-hari-ham-internasional?page=2.\n" +
                    "Penulis : Vina Fadhrotul Mukaromah\n" +
                    "Editor : Sari Hardiyanto");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 Desember: Hari Transmigrasi")){
            infoBulan.setText("TRIBUNNEWS.COM - Tanggal 12 Desember diperingati sebagai Hari Bhakti Transmigrasi (HBT).\n" +
                    "\n" +
                    "Hari Bhakti Transmigrasi dimulai pada 12 Desember 1950. \n" +
                    "\n" +
                    "Kata 'transmigrasi' sendiri diperkenalkan oleh Presiden Soekarno dan Mohammad Hatta.\n" +
                    "\n" +
                    "Pada saat itu, Soekarno memperkenalkan kata tersebut melalui sebuah tulisan di Harian Soeloeh Indonesia.\n" +
                    "\n" +
                    "Presiden Soekarno mencetuskan istilah transmigrasi pada 1927.\n" +
                    "\n" +
                    "Transmigrasi merupakan sebuah program yang dibuat pemerintah Indonesia untuk memindahkan penduduk dari suatu daerah yang padat penduduk ke daerah lain di wilayah Indonesia. \n" +
                    "\n" +
                    "Sementara itu, penduduk yang melakukan transmigrasi disebut sebagai transmigran.\n" +
                    "\n" +
                    "Pada 12 Desember kemudian ditetapkan sebagai Hari Bhakti Transmigrasi karena bersamaan dengan pertama kalinya pemerintah Indonesia memulai penyelenggaraan transmigrasi.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di Tribunnews.com dengan judul Mengenal Hari Bhakti Transmigrasi, Diperingati Setiap 12 Desember hingga Dicetuskan oleh Soekarno, https://www.tribunnews.com/nasional/2019/12/12/mengenal-hari-bhakti-transmigrasi-diperingati-setiap-12-desember-hingga-dicetuskan-oleh-soekarno.\n" +
                    "Penulis: Nur Afitria Cika Handayani\n" +
                    "Editor: Adya Rosyada Yonas ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 Desember: Hari Belanja Online Nasional (Harbolnas)")){
            infoBulan.setText(".....");
        }else if(tanggal.equalsIgnoreCase("Tanggal 13 Desember: Hari Nusantara[46]")){
            infoBulan.setText("Hari Nusantara merupakan perwujudan dari Deklarasi Djuanda yang dianggap sebagai Deklarasi Kemerdekaan Indonesia kedua. Melalui deklarasi tersebut, Indonesia merajut dan mempersatukan kembali wilayah dan lautannya yang luas, menyatu menjadi kesatuan yang utuh dan berdaulat.[1]\n" +
                    "\n" +
                    "Melalui Keppres No.126/2001 dikukuhkan sebagai Hari Nusantara, artinya setiap tanggal 13 Desember mulai diperingati sebagai salah satu Hari Nasional.[2]\n" +
                    "\n" +
                    "Hari Nusantara yang diperingati setiap tanggal 13 Desember merupakan penegasan dan pengingatan bahwa Indonesia adalah Negara Kepulauan terbesar di dunia. Sayangnya, potensi sumberdaya kelautan Indonesia sebesar kurang lebih 3000 triliun rupiah/tahun belum tergarap secara maksimal. Laut belum dilihat sebagai sumber pertumbuhan, penciptaan lapangan kerja, dan pemecah masalah kemiskinan.[1]\n" +
                    "\n" +
                    "Berikut pidato resmi kenegaraan yang disampaikan oleh Wakil Presiden (saat itu) Boediono saat puncak acara Hari Nusantara tahun 2010 di Balikpapan, Kalimantan Timur:[");
        }else if(tanggal.equalsIgnoreCase("Tanggal 15 Desember: Hari Infanteri[butuh rujukan]")){
            infoBulan.setText(".....");
        }else if(tanggal.equalsIgnoreCase("Tanggal 19 Desember: Hari Bela Negara [47]")){
            infoBulan.setText("Hari Bela Negara atau HBN adalah hari bersejarah Indonesia yang jatuh pada tanggal 19 Desember untuk memperingati deklarasi Pemerintahan Darurat Republik Indonesia oleh Mr. Sjafruddin Prawiranegara di Sumatra Barat pada tanggal 19 Desember 1948. Keputusan ini ditetapkan oleh Presiden Susilo Bambang Yudhoyono melalui Keppres No. 28 tahun 2006.[1] ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 20 Desember: Hari Kesetiakawanan Sosial Nasional[48]")){
            infoBulan.setText("PERANG mempertahankan kemerdekaan yang terjadi dari tahun 1945 hingga tahun 1948 mengakibatkan permasalah sosial semakin bertambah jumlahnya.Kementerian Sosial menyadari bahwa untuk menanggulangi dan mengatasi permasalahan sosial tersebut diperlukan dukungan menyeluruh dari unsur masyarakat. Oleh sebab itu, maka pada bulan Juli 1949 di kota Yogyakarta, Kementerian Sosial mengadakan Penyuluhan Sosial bagi tokoh-tokoh masyarakat dan Kursus Bimbingan Sosial bagi Calon Sosiawan atau Pekerja Sosial, dengan harapan dapat menjadi mitra bagi pemerintah dalam menanggulangi dan mengatasi permasalahan sosial yang sedang terjadi.\n" +
                    "\n" +
                    "Para Sosiawan atau Pekerja Sosial telah bekerja dengan jiwa dan semangat kebersamaan, kegotongroyongan, kekeluargaan serta kerelaan berkorban tanpa pamrih yang tumbuh di dalam masyarakat dapat diperkokoh, sehingga masyarakat dapat menanggulangi dan mengatasi permasalahan sosial yang timbul saat itu dalam rangka mencapai kesejahteraan sosial bagi masyarakat.\n" +
                    "\n" +
                    "Nilai kesetiakawanan sosial yang telah tumbuh didalam masyarakat perlu dilestarikan dan diperkokoh.Begitu juga dengan kinerja dan persatuan para sosiawan atau pekerja sosial perlu ditingkatkan. Untuk hal tersebut,maka Kementerian Sosial berinisiatif membuat Lambang Pekerjaan Sosial dan Kode Etik atau Sikap Sosiawan. Lambang Pekerjaan Sosial dan Kode Etik Sosiawan diciptakan pada tanggal 20 Desember 1949, tanggal tersebut dipilih karena bertepatan dengan peristiwa bersejarah bersatunya seluruh lapisan masyarakat untuk mengatasi permasalahan dalam mempertahankan kedaulatan negara, yaitu pada tanggal 20 Desember 1948, sehari setelah tentara kolonial Belanda menyerbu dan menduduki ibukota negara Yogyakarta.Maka tanggal tersebut oleh Kementerian Sosial dijadikan sebagai HARI SOSIAL.\n" +
                    "\n" +
                    "Hari Sosial atau Hari Kesetiakawanan Sosial Nasional (HKSN) diperingati pada tanggal 20 Desember setiap tahun sebagai rasa syukur dan hormat atas keberhasilan seluruh lapisan masyarakat Indonesia dalam menghadapi ancaman bangsa lain yang ingin menjajah kembali bangsa kita.\n" +
                    "\n" +
                    "Peringatan Hari Sosial atau Hari Kesetiakawanan Sosial Nasional (HKSN) tersebut merupakan upaya untuk mengenang, menghayati dan meneladani semangat persatuan, kesatuan, kegotongroyongan dan kekeluargaan rakyat Indonesia yang secara bahu membahu mengatasi permasalahan dalam mempertahankan kedaulatan bangsa atas pendudukan kota Yogyakarta sebagai Ibu Kota Republik Indonesia oleh tentara Belanda pada tahun 1948.\n" +
                    "\n" +
                    "Adapun sejarah lahirnya Hari Sosial yang pada akhirnya berubah menjadi Hari Kebhaktian Sosial, dan berganti lagi menjadi Hari Kesetiakawanan Sosial Nasional adalah sebagai berikut :\n" +
                    "\n" +
                    "    HARI SOSIAL ke I atau pertama kali diperingati pada tanggal 20 Desember 1958 dicetuskan oleh Menteri Sosial, H Moeljadi Djojomartono.\n" +
                    "    Peringatan yang ke XIX tanggal 20 Desember 1976 oleh Menteri Sosial, HMS Mintardja SH. Nama HARI SOSIAL diubah menjadi HARI KEBAKTIAN SOSIAL.\n" +
                    "    Dan pada Peringatan yang XXVI tanggal 20 Desember 1983 oleh Menteri Sosial, Nani Soedarsono SH. Nama HARI KEBAKTIAN SOSIAL diubah lagi menjadi HARI KESETIAKAWANAN SOSIAL NASIONAL.\n" +
                    "\n" +
                    "Jiwa dan semangat kebersamaan, kegotongroyongan, kekeluargaan dan kerelaan berkorban tanpa pamrih yang tumbuh di dalam masyarakat tersebut harus dikembangkan, direvitalisasi, didayagunakan dalam kehidupan berbangsa.\n" +
                    "\n" +
                    "Pada saat ini bangsa Indonesia masih berhadapan dengan berbagai masalah kesejahteraan sosial yang meliputi kemiskinan, keterlantaran, ketunaan, keterpencilan dan kebencanaan yang jumlahnya tidak kecil. Sementara pemerintah memiliki kemampuan terbatas, sehingga diperlukan peran serta masyarakat.\n" +
                    "\n" +
                    "Kesetiakawanan sosial masa kini adalah instrumen menuju kesejahteraan masyarakat melalui gerakan peduli dan berbagi oleh, dari dan untuk masyarakat baik sendiri-sendiri maupun secara bersamaan berdasarkan nilai kemanusiaan, kebersamaan, kegotongroyongan dan kekeluargaan yang dilakukan secara terencana, terarah dan dan berkelanjutan menuju terwujudnya Indonesia Sejahtera (INDOTERA).\n" +
                    "\n" +
                    "Peringatan HKSN diharapkan dapat menjadi “alat pengungkit” untuk menggerakkan kembali nilai-nilai kesetiakawanan sosial yang ada dimasyarakat, yang dilaksanakanditingkat pusat, propinsi dan kabupaten/kota dengan berdasarkan pada tiga prinsip, yaitu :\n" +
                    "\n" +
                    "    Prinsip dari, oleh dan untuk masyarakat,yang berarti bahwa kegiatan Peringatan HKSN memerlukan peran aktif seluruh unsur masyarakat, antara lain TNI dan Polri, organisasi sosial/lembaga swadaya masyarakat, unsur generasi muda, lembaga pendidikan, dunia usaha, media massa, pemuka masyarakat dan agama, relawan sosial dan masyarakat secara umum yang didayagunakan untuk kepentingan masyarakat.\n" +
                    "    Prinsip Tri Daya, yaitu bahwa penyelenggaraan HKSN diharapkan dapat memberdayakan manusia, usaha, dan lingkungan sosial sebagai satu kesatuan.\n" +
                    "    Prinsip berkelanjutan, bahwa kegitan-kegiatan dalam rangka Kesetiakawanan Sosial Nasional hendaknya dilaksanakan secara terus menerus sepanjang tahun (No Day Without Solidarity) dengan berdasarkan pada kedua prinsip tersebut di atas.\n" +
                    "\n" +
                    "Peringatan Hari Kesetiakawanan sosial Nasioal saat ini dilaksanakan dalam bentuk Gerakan Indonesia Setiakawan yang dimaksudkan sebagai upaya mengarahkan percepatan gerakan Indonesia Peduli menuju terwujudnya Indonesia baru, dengan tujuan menumbuhkan kesadaran dan tanggungjawab sosial masyarakat untuk mengkristalisasikan kesetiakawanan sosial serta meningkatkan jumlah masyarakat peduli dalam penyelenggaraan kesejahteraan sosial.\n" +
                    "\n" +
                    "Peringatan HKSN diharapkan mampu mengatasi berbagai permasalahan sosial yang ada, dengan mengacu pada parameter kesejahteraan :\n" +
                    "\n" +
                    "    Terpenuhinya kebutuhan dasar setiap warga negara Indonesia (sandang, pangan, papan, pendidikan dan kesehatan).\n" +
                    "    Terlindungi hak sipil setiap warga negara (hak memperoleh KTP, Akte Kelahiran, hak berorganisasi, hak mengemukakan pendapat dll).\n" +
                    "    Terlindunginya setiap warga negara dariberbagai resiko yang bertautan dengan siklus hidup, ketidakpastian ekonomi, resiko kerusakan lingkungan dan resiko sosial maupun politik (kecacatan, konflik, bencana, pengangguran).\n" +
                    "    Terdapatnyakemudahan memperoleh berbagai aksespelayanan dasar (pendidikan, kesehatan, ekonomi/keuangan, politik dll).\n" +
                    "    Terpenuhinya jaminan keberlangsungan hidup bagi setiap warga negara (asuransi, jaring pengamanan sosial, bantuan sosial dan lain-lain).\n" +
                    "\n" +
                    "Nilai moral yang terkandung dalam kesetiakawanan sosial diantaranya sebagai berikut:\n" +
                    "\n" +
                    "    Nilai moral Tolong menolong. Nilai moral ini tampak dalam kehidupan masyarakat, seperti: tolong menolong sesama tetangga. Misalnya membantu korban bencana alam atau menengok tetangga yang sakit.\n" +
                    "    Gotong-royong, misalnya menggarap sawah atau membangun rumah.\n" +
                    "    Kerjasama. Nilai moral ini mencerminkan sikap mau bekerjasama dengan orang lain walaupun berbeda suku bangsa, ras, warna kulit, serta tidak membeda-bedakan perbedaan itu dalam kerjasama.\n" +
                    "    Nilai kebersamaan. Nilai moral ini ada karena adanya keterikatan diri dan kepentingan kesetiaan diri dan sesama, saling membantu dan membela. Contohnya menyumbang sesuatu ke tempat yang mengalami bencana, apakah itu kebanjiran, kelaparan atau diserang oleh bangsa lain.\n" +
                    "\n" +
                    "Sebagai bagian dari unsur nilai, maka kesetiakawanan Sosial dijadikan nilai dasar penyelengggaraan kesejahteraan sosial. Nilai sosial ini terus digali, dikembangkan dan didayagunakan dalam mewujudkan cita-cita Indonesia mewujudkan Indonesia sejahtera. Sebagai nilai dasar kesejahteraan sosial, kesetiakawanan sosial harus terus direvitalisasi sesuai dengan kondisi aktual bangsa dan diimplementasikan dalam wujud nyata dalam kehidupan masyarakat. Jiwa dan semangat tersebut telah teruji dalam berbagai peristiwa sejarah, dengan puncak manifestasinya terwujud dalam tindak dan sikap berdasarkan rasa kebersamaan dari seluruh bangsa Indonesia pada saat menghadapi ancaman dari penjajah yang membahayakan kelangsungan hidup bangsa. Sejarah telah membuktikan bahwa bangsa Indonesia mencapai kemerdekaan berkat semangat kesetiakawanan sosial yang tinggi.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 22 Desember: Hari Ibu Nasional")){
            infoBulan.setText("KOMPAS.com – Hari Ibu di Indonesia diperingati setiap 22 Desember. Pada Minggu (22/11/2019) besok, menjadi momen peringatan Hari Ibu untuk tahun ini. Penetapan 22 Desember sebagai peringatan Hari Ibu di Indonesia sejak 1938. Kala itu, diselenggarakan Kongres Perempuan Indonesia III pada 22-27 Juli 1938 di Bandung. Salah satu keputusannya menetapkan Hari Ibu diperingati setiap 22 Desember. Pemilihan 22 Desember karena bertepatan dengan diselenggarakannya Kongres Perempuan I pada 22 Desember 1928. Jika di Indonesia peringatan Hari Ibu setiap 22 Desember, di beberapa negara juga memiliki tanggal peringatan sendiri. Selain berbeda tanggal, setiap negara juga memiliki pemaknaan berbeda terhadap Hari Ibu.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Hari Ibu di Indonesia 22 Desember, Tanggal Berapa di Negara Lain?\", https://www.kompas.com/tren/read/2019/12/21/191200465/hari-ibu-di-indonesia-22-desember-tanggal-berapa-di-negara-lain-.\n" +
                    "Penulis : Luthfia Ayu Azanella\n" +
                    "Editor : Inggried Dwi Wedhaswary");
        }else if(tanggal.equalsIgnoreCase("Tanggal 22 Desember: Hari Sosial")){
            infoBulan.setText("Hari Sosial (22 Desember)\n" +
                    "Diposkan pada 15 Desember 2015\t\n" +
                    "\n" +
                    "Cerita ini akan dipersembahkan untuk #Challenge IOCWP 22 Desember #HariSosial\n" +
                    "\n" +
                    "Pasti sebagian dari masyarakat Indonesia tak tahu hari nasional yang bertepatan jatuh pada tanggal dua puluh dua Desember itu bukan hanya Hari Ibu saja, melainkan Hari Sosial.\n" +
                    "\n" +
                    "Apa pendapatmu dengan kata “sosial”?\n" +
                    "Teringat akan sesuatu hal?\n" +
                    "\n" +
                    "Pernahkah kalian mendengar sebuah pepatah yang berkata “Manusia tidak bisa hidup sendiri. Karena manusia adalah makhluk sosial”?\n" +
                    "\n" +
                    "Dari sebuah kutipan di atas. Kita bisa menyimpulkan. Bahwa yang dimaksud “sosial” adalah sesuatu yang tidak dapat berdiri sendiri, bisa dikatakan “sosial” adalah saling membutuhkan orang lain.\n" +
                    "\n" +
                    "Benarkah seperti itu?\n" +
                    "Ya, karena tanpa makhluk lain kita tak akan bisa hidup.\n" +
                    "\n" +
                    "Coba bayangkan, jika kamu hidup sendiri tanpa ada orang lain. Lalu kamu sakit keras sampai tidak bisa bangun ataupun berjalan. Sedangkan di sekitarmu tidak ada siapa-siapa. Kamu akan meminta bantuan dengan siapa? Dengan angin? Jangan bercanda! Apa kamu bisa hidup dengan seperti itu? Tentu tidak!\n" +
                    "\n" +
                    "Lalu kita masih saja egois dan selalu ingin melakukan sendiri dan hanya selalu mementingkan diri sendiri? Sedangkan kita tahu bahwa kita seharusnya saling membantu, menolong.\n" +
                    "\n" +
                    "Masih pantaskah kita berkelakuan seperti itu? Sementara di luar sana masih banyak orang lain yang membutuhkan tangan kita.\n" +
                    "\n" +
                    "Hari Sosial. Apa yang akan kalian lakukan untuk hari ini, esok, lusa, minggu, bulan, tahun ini?\n" +
                    "Apa kalian tetap akan menutup semua pintu hati kalian untuk membantu seseorang yang dalam kesusahan?\n" +
                    "\n" +
                    "Apa kita pernah berpikir kenapa Hari Sosial dikatakan hari nasional?\n" +
                    "Bisakah kamu renungkan?\n" +
                    "Ya, jawabannya karena negara kita ini sangat peduli dengan “sosial”\n" +
                    "Tapi kenapa ya kita masih saja menutup pintu hati kita untuk membantu orang dalam kesusahan?\n" +
                    "\n" +
                    "dyahyuukita 1512’15\n" +
                    "\n" +
                    "Sumber : https://id.m.wikipedia.org/wiki/Daftar_hari_penting_di_Indonesia");
        }else if(tanggal.equalsIgnoreCase("Tanggal 22 Desember: Hari Korps Wanita Angkatan Darat (KOWAD)")){
            infoBulan.setText("Korps Wanita Angkatan Darat\n" +
                    "Loncat ke navigasi\n" +
                    "Loncat ke pencarian\n" +
                    "Korps Wanita TNI Angkatan Darat\n" +
                    "(Kowad)\n" +
                    "Lambang Kowad.png\n" +
                    "Lambang Korps Wanita TNI AD\n" +
                    "Dibentuk\t22 Desember 1961\n" +
                    "Negara\tIndonesia\n" +
                    "Cabang\tInsignia of the Indonesian Army.svg TNI Angkatan Darat\n" +
                    "Bagian dari\tKomando Wanita TNI\n" +
                    "Moto\tDharma Puspha\n" +
                    "Situs web\twww.tniad.mil.id\n" +
                    "\n" +
                    "Korps Wanita Angkatan Darat atau di singkat (Kowad) Pembentukan Korps Wanita Angkatan Darat diilhami oleh hasil perjuangan para Pahlawan Wanita Indonesia yang ikut serta menegakkan kemerdekaan Indonesia dan usaha para pendahulu untuk meraih kemajuan bagi kaum wanita. Untuk itu pada tahun 1959 Asisten 3 personel Kasad Kolonel Dr. Sumarno menyampaikan gagasannya tentang penggunaan tenaga militer wanita untuk bidang-bidang penugasan tertentu yang membutuhkan ketelitian, ketekunan, kesabaran, dan sifat-sifat keibuan yang menjadi kodrat wanita untuk lebih mencapai afiliasi organisasi. Sebagai realisasi pembentukan Kowad dikeluarkan Surat Keputusan Pangad No.1056/12/1960 tanggal 21 Desember 1960, lahirlah Corps Wanita Angkatan Darat. Meskipun Kowad disyahkan pada tanggal 21 Desember 1960, namun Hari Kowad ditetapkan tanggal 22 Desember. Penetapan ini dimaksudkan karena pada tanggal 22 Desember 1938 dilangsungkan Kongres Wanita Pertama yang dikenal Hari Ibu, karena Hari Ibu adalah kehormatan bagi ibu Indonesia sebagai ibu keluarga, ibu masyarakat dan ibu bangsa, maka lahirnya Kowad diharapkan sebagai kebanggaan kaum ibu. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 25 Desember: Hari Natal")){
            infoBulan.setText(".....");
        }
    }
}
