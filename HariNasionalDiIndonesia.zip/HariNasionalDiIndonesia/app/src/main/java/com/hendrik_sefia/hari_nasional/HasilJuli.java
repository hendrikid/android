package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilJuli extends AppCompatActivity {
    String JULI;
    TextView infoBulan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_juli);
        // ambil textview info di acivity_hasil1
        infoBulan=(TextView) findViewById(R.id.info_juli);

        // ambil parameter nama_negara dari intent
        Intent intent = getIntent();
        JULI = intent.getStringExtra("juli");

        // panggil setInfo(String negara) dan tampilkan ibukotanya
        setJULI(JULI);
    }
    private void setJULI(String tanggal) {
        if(tanggal.equalsIgnoreCase(" Tanggal 1 Juli: Hari Bhayangkara")){
            infoBulan.setText("KOMPAS.com - Tanggal 1 Juli menjadi hari istimewa bagi Kepolisian Negara Republik Indonesia. Setiap tahun, pada tanggal ini, menjadi titik peringatan Hari Bhayangkara. Apa itu Hari Bhayangkara? Banyak yang mengira Hari Bhayangkara merupakan peringatan ulang tahun atau terbentuknya Kepolisian RI (Polri). Akan tetapi, bukan itu makna di balik hari ini. Hari Bhayangkara merupakan hari Kepolisian Nasional yang diambil dari momentum turunnya Peraturan Presiden Nomor 11 Tahun 1946. Peraturan itu menyatukan kepolisian yang semula terpisah sebagai kepolisian daerah, menjadi satu kesatuan nasional dan bertanggung jawab secara langsung pada pimpinan tertinggi negara, presiden. Baca juga: Hari Bhayangkara, Momentum Reformasi Kepolisian Dilansir dari keterangan Divisi Humas Polri melalui akun Facebook-nya, nama Bhayangkara adalah istilah yang digunakan Patih Gadjah Mada dari Majapahit untuk menamai pasukan keamanan yang ditugaskan menjaga raja dan kerajaan kala itu. Namun, keberadaan pasukan pengamanan mengalami perubahan bentuk dan komando. Kala itu, Indonesia dijajah oleh bangsa Belanda dan Jepang selama kurun waktu yang cukup panjang. Masa penjajahan Belanda Saat di bawah jajahan Belanda, pasukan keamanan diambil dari warga pribumi dan ditugaskan untuk menjaga aset dan kekayaan orang-orang Eropa di Hindia Belanda. Pasukan keamanan ini terbagi menjadi beberapa bentuk, misalnya Veld Politie (Polisi Lapangan), Stands Politia (Polisi Kota), Cultur Politie (Polisi Pertanian), dan Bestuurs Politie (Polisi Pamong Praja). Akan tetapi, saat itu pribumi yang menjadi bagian dari anggota keamanan tidak bisa menempati posisi-posisi tinggi seperti hood agent (bintara), inspekteur van politie, dan commisaris van politie. Baca juga: HUT Bhayangkara ke-73, Brimob Kibarkan Merah Putih di Puncak Cartenz Papua Mereka hanya diperkenankan menjadi mantri polisi, asisten wedana, dan wedana polisi. Koloni Belanda juga sempat membentuk kepolisian modern selama 1897-1920. Inilah yang menjadi cikal bakal terbentuknya Polri saat ini. Masa kolonialisasi Jepang Saat jepang menguasai Nusantara, kepolisian dibagi-bagi berdasarkan wilayah. Ada kepolisian Jawa dan Madura yang berpusat di Jakarta, Kepolisian Sumatera dengan pusat di Bukittinggi, Kepolisian Indonesia Timur berpusat di Makassar, dan Kepolisian Kalimantan yang pusatnya ada di Banjarmasin. Berbeda dengan zaman Belanda yang hanya mengizinkan jabatan tinggi diisi oleh orang-orang mereka, saat di bawah Jepang, Kepolisian dipimpin oleh warga Indonesia. Baca juga: Alasan Polri Gelar Peringatan Hari Bhayangkara Indoor Akan tetapi, meski menjadi pemimpin, orang pribumi masih didampingi pejabat Jepang yang pada praktiknya lebih memegang kuasa. Masa kemerdekaan Setelah Jepang menyerah tanpa syarat kepada sekutu, polisi bentukan Jepang seperti PETA dan Gyu-Gun dibubarkan. Dan setelah Soekarno-Hatta memproklamirkan kemerdekaan pada 17 Agustus 1945, kepolisian yang tersisa dari masa penjajahan menjadi kepolisian Indonesia yang merdeka. Pada 19 Agustus 1945, Panitia Persiapan Kemerdekaan Indonesia (PPKI) membentuk Badan Kepolisian Negara (BKN). Selanjutnya, pada 29 September 1945, Presiden Soekarno menetapkan dan melantik R.S. Soekanto Tjokrodiatmodjo menjadi Kepala Kepolisian Negara (KKN). Kala itu, kepolisian masih ada di bawah Kementerian Dalam Negeri dengan nama Djawatan Kepolisian Negara untuk urusan administrasi. Akan tetapi pertanggungjawaban operasional dilakukan kepada Jaksa Agung. Namun, sejak terbitnya PP Nomor 11 Tahun 1946, kepolisian negara bertanggung jawab secara langsung kepada presiden. Sejak ditetapkan pada tahun 1946, pada hari ini, Kepolisan merayakan Hari Bhayangkara yang ke-73. Selamat Hari Bhayangkara untuk segenap jajaran anggota juga institusi Kepolisian Negara Republik Indonesia. Artikel ini telah tayang di Kompas.com dengan judul \"Sejarah di Balik Penetapan 1 Juli sebagai Hari Bhayangkara\", https://nasional.kompas.com/read/2019/07/01/08524211/sejarah-di-balik-penetapan-1-juli-sebagai-hari-bhayangkara?page=all. Penulis : Luthfia Ayu Azanella Editor : Inggried Dwi Wedhaswary\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Sejarah di Balik Penetapan 1 Juli sebagai Hari Bhayangkara\", https://nasional.kompas.com/read/2019/07/01/08524211/sejarah-di-balik-penetapan-1-juli-sebagai-hari-bhayangkara?page=all.\n" +
                    "Penulis : Luthfia Ayu Azanella\n" +
                    "Editor : Inggried Dwi Wedhaswary\n" + "\n" + "sorce:https://nasional.kompas.com/read/2019/07/01/08524211/sejarah-di-balik-penetapan-1-juli-sebagai-hari-bhayangkara?page=all");
        }if(tanggal.equalsIgnoreCase(" Tanggal 1 Juli: Hari Buah")){
            infoBulan.setText("\n" +
                    "\n" +
                    "International Fruit Day atau Hari Buah Internasional adalah hari perayaan internasional yang dirayakan setiap tanggal 1 Juli di tiap tahunnya. Hari Buah Internasional ditetapkan pada tahun 2007 di Jerman. Tujuan diadakannya Hari Buah Internasional adalah untuk meningkatkan kepedulian masyarakat terhadap konsumsi buah-buahan lokal.\n" +
                    "\n" +
                    "Setiap tahunnya, Hari Buah Internasional memiliki sebuah program yang bernama “Fruit of the Year”. Buah yang terpilih sebagai “Fruit of the Year” untuk tahun 2017 ini adalah buah quince. Buah quince yang memiliki nama Latin berupa Cydonia oblonga merupakan buah eksotis asal Turki yang masih “bersaudara” dengan buah apel dan buah pir.\n" + "\n" + "sorce:https://www.greeners.co/agenda-hari-lingkungan-hidup-juli/hari-buah-internasional/");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 2 Juli: Hari Kelautan Nasional")){
            infoBulan.setText("Kumparan.com, Makassar - Indonesia adalah Negara kepulauan terbesar di dunia dengan lautannya membentang seluas lebih dari 5 juta km persegi. Bandingkan dengan daratannya yang kurang dari 2 juta km persegi saja. Dengan luas dan potensi sumber daya alam laut yang sangat besar, Indonesia adalah surga laut yang indah dan kaya.\n" +
                    "\nADVERTISEMENT\n" +
                    "\nPemandangan dalam laut yang mempesona dengan keunikan biota bawah laut yang membentang dari Aceh hingga Papua. Diperkirakan lebih dari 2.500 jenis ikan dan 500 jenis karang hidup di dalam perairan Nusantara.\n" +
                    "\nMaka tidak mengherankan jika lautan Indonesia menjadi tujuan wisata menyelam bagi Divers dari seluruh dunia serta menjadi obyek penelitian yang juga tidak pernah sepi dari perhatian peneliti kelas dunia.\n" +
                    "\nBerangkat dari hal tersebut, di Hari Kelautan Nasional yang jatuh setiap tanggal 2 Juli, Pakar Kemaritiman, Abdul Rivai Ras, mengungkapkan kecemasan dan keprihatinannya terhadap pengelolaan kekayaan laut Indonesia yang masih membutuhkan banyak perhatian dari Pemerintah.\n" +
                    "\nSaya sekarang merasa cemas dan prihatin. Kekayaan hayati laut Indonesia saat ini begitu rapuh dan bisa saja punah, bila generasi kita sekarang ini tidak lagi peduli dan gagal menjaganya dari tindakan eksploitasi oleh oknum yang tidak bertanggungjawab,” ucap Rivai Ras, dilansir dari laman resmi brorivai.com, Senin, 2 Juli 2018.\n" +
                    "\nSelain itu, lanjut Rivai Ras, kurangnya kesadaran masyarakat akan kebersihan laut juga menjadi salah satu faktor yang dapat merusak dan mengancam kehidupan biota bawah laut.\n" +
                    "\nMasih banyak orang yang membuang sampah sembarangan. Akibatnya sampah tersebut berakhir di laut. Hal itu tentu saja mengancam kehidupan biota laut yang merupakan kekayaan serta potensi besar bagi pariwisata perairan kita. Penangkapan ikan secara berlebihan seperti menggunakan pukat harimau dan penggunaan bom juga dapat merusak terumbu karang. Padahal terumbu karang Indonesia adalah daya tarik utama bagi para wisatawan mancanegara,” ungkap Pendiri BRORIVAI Center ini.\n" +
                    "\nJika hal itu terus dibiarkan, kata Rivai Ras, maka tidak menutup kemungkinan sektor Pariwisata Bahari kita tidak akan lagi dilirik oleh wisatawan. Otomatis hal itu berdampak pada penurunan pendapatan negara dari sektor Pariwisata.\n" +
                    "\nSolusi konkrit menurut Rivai Ras adalah gerakan edukasi penyadartahuan kepada masyarakat harus lebih digalakkan oleh semua pihak, guna meningkatkan kepedulian masyarakat terhadap perlindungan laut.\n" +
                    "\nHal itu perlu terus dijalankan oleh semua pihak, baik pemerintah maupun aktivis lingkungan agar publik secara luas mengetahui informasi kekayaan laut Indonesia dan ancaman yang sedang dihadapinya,” terang Bro Rivai, sapaan akrab Rivai Ras.\n" +
                    "\nKesadaran bersama untuk ikut menjaga dan melestarikan laut Indonesia akan memastikan bahwa kekayaan hayati laut Nusantara tidak hanya menjadi kebanggaan generasi sekarang, tetapi juga menjadi kekayaan yang dapat terus dinikmati oleh generasi akan datang.\n" +
                    "\nSelamat Hari Kelautan Nasional. Selamatkan kekayaan laut Indonesia,” tutup Bro Rivai.\n" + "\n" + "sorce: https://kumparan.com/abdul-rivai-ras/hari-kelautan-nasional-bro-rivai-selamatkan-kekayaan-laut-indonesia-27431110790536342/full");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 5 Juli: Hari Bank Indonesia")){
            infoBulan.setText("\n" +
                    "\n" +
                    "Nama Bank Indonesia tentu sudah familiar di telinga kamu semua baik melalui surat kabar, berita, ataupun media online. Tapi apakah kamu sudah benar-benar mengenal dengan baik Bank Sentral yang independen ini?\n" +
                    "\n" +
                    "Dalam rangka memperingati Hari Bank Indonesia yang jatuh pada tanggal 5 Juli setiap tahunnya, nggak ada salahnya dong kita mengenal lebih jauh soal sejarah dan juga perkembangan lembaga keuangan yang berusaha menjaga nilai rupiah selalu stabil ini?\n" +
                    "\n" +
                    "Sejarah Bank Indonesia\n" +
                    "\n" +
                    "Bank Indonesia atau lebih dikenal dengan BI ini merupakan Bank Sentral Republik Indonesia dimana saat pemerintahan Hindia Belanda memiliki nama De Javasche Bank. Pada 1828 De Javasche Bank didirikan oleh Pemerintah Hindia Belanda sebagai bank sirkulasi yang bertugas mencetak dan mengedarkan uang.\n" +
                    "\n" +
                    "Pada tahun 1953 Undang-Undang Pokok Bank Indonesia menetapkan Bank Indonesia untuk menggantikan fungsi De Javasche Bank sebagai bank sentral, dengan tiga tugas utama di bidang moneter, perbankan, dan sistem pembayaran.\n" +
                    "\n" +
                    "Di tahun 1968 terbitlah Undang Undang Bank Sentral yang mengatur kedudukan dan tugas Bank Indonesia sebagai bank sentral, terpisah dari bank-bank lain yang melakukan fungsi komersial. Tahun 1999 menjadi sejarah baru bagi Bank Indonesia karena disahkannya UU No. 23/1999 yang berisi bahwa tujuan tunggal Bank Indonesia adalah mencapai dan menjaga kestabilan nilai rupiah.\n" +
                    "\n" +
                    "Setelah itu UU Bank Indonesia mengalami amandemen pada tahun 2004 dan 2008. Tahun 2004 amandemen BI berfokus pada aspek penting yang terkait dengan pelaksanaan tugas dan wewenang Bank Indonesia, termasuk penguatan governance. Sementara pada tahun 2008 Peraturan Pemerintah Pengganti Undang-Undang No. 2 tahun 2008 tentang Bank Indonesia sebagai bagian dari upaya menjaga stabilitas sistem keuangan. Amandemen ini dimaksudkan untuk meningkatkan ketahanan perbankan nasional dalam menghadapi krisis global.\n" +
                    "Status dan Kedudukan Bank Indonesia\n" +
                    "\n" +
                    "Bank Indonesia sendiri memiliki dua kedudukan penting, yaitu sebagai lembaga negara yang independen dan sebagai badan hukum.\n" +
                    "\n" +
                    "Kedudukan Bank Indonesia sebagai Lembaga Negara yang Independen memiliki arti bahwa BI memiliki otonomi penuh dalam merumuskan dan melaksanakan setiap tugas dan wewenangnya sebagaimana yang telah ditentukan dalam undang-undang. Pihak luar tidak diijinkan untuk mencampuri tugas BI dan BI juga berhak menolak interversi dalam bentuk apa pun. Kedudukan ini bertujuan agar Bank Indonesia dapat melaksanakan peran dan fungsinya sebagai otoritas moneter secara efektif dan efisien.\n" +
                    "\n" +
                    "Bank Indonesia sebagai badan hukum publik ataupun perdata juga sudah diatur dalam undang-undang. Yang mana BI memiliki kewenangan untuk menetapkan peraturan-peraturan hukum yang merupakan pelaksanaan dari undang-undang yang mengikat seluruh masyarakat luas sesuai dengan tugas dan wewenangnya.\n" +
                    "Fungsi dan Tujuan Bank Indonesia\n" +
                    "\n" +
                    "Sebagai bank sentral, Bank Indonesia memiliki tujuan tunggal yaitu memelihara kestabilan nilai rupiah.\n" +
                    "\n" +
                    "Kestabilan nilai rupiah ini terdiri dari dua aspek, pertama kestabilan nilai mata uang terhadap barang dan jasa yang tercermin dalam perkembangan laju inflasi. Kedua adalah kestabilan terhadap mata uang negara lain yang tercermin dalam perkembangan nilai tukar rupiah terhadap mata uang asing.\n" +
                    "Untuk mencapai dua tujuan tersebut, Bank Indonesia didukung oleh tiga pilar, yaitu:\n" +
                    "\n" +
                    "    Menetapkan dan menjalankan kebijakan moneter\n" +
                    "    Mengatur dan menjaga kelancaran sistem pembayaran\n" +
                    "    Mengatur dan mengawasi perbankan di Indonesia\n" +
                    "\n" +
                    "Sekarang, sudah nggak kudet lagi kan soal Bank Indonesia? Selamat Hari Bank Indonesia!\n");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 9 Juli: Hari Satelit Palapa")){
            infoBulan.setText("Bobo.id – Mungkin tidak banyak yang tahu, kalau setiap 9 Juli itu diperingati sebagai hari Satelit Palapa.\n" +
                    "\n" +
                    "Apa itu satelit Palapa?\n" +
                    "\n" +
                    "Fungsi Satelit\n" +
                    "\n" +
                    "Sebelum membahas satelit Palapa, mungkin kita perlu tahu sebenarnya apa fungsi satelit itu.\n" +
                    "\n" +
                    "Mungkin sebagian teman-teman bisa menyaksikan program TV luar negeri di Indonesia, bukan?\n" +
                    "\n" +
                    "Nah, ternyata bisa seperti itu berkat adanya satelit, lo.\n" +
                    "\n" +
                    "Satelit bertugas mengirimkan data menuju TV, sehingga kita bisa menikmati tayangan TV yang berasal dari luar negeri.\n" +
                    "\n" +
                    "BACA JUGA : Ini Dia Satelit yang Mengelilingi Bumi, Jumlahnya Ribuan, lo!\n" +
                    "\n" +
                    "Selain mengirimkan data acara TV, satelit ini juga bisa mengirimkan panggilan telepon dari satu benua ke benua lainnya.\n" +
                    "Gunanya, untuk mempermudah kita berkomunikasi dengan penduduk di negara lain.\n" +
                    "\n" +
                    "Satelit juga bisa memperkirakan cuaca dengan mengukur awan, angin, dan suhu atmosfer dari luar angkasa.\n" +
                    "\n" +
                    "Itulah sebabnya kenapa satelit dibuat, untuk mempermudah dalam berkomunikasi, menikmati dunia hiburan, dan mempermudah mengetahui keadaan alam kita.\n" +
                    "\n" +
                    "BACA JUGA : Keren! Pesawat Antariksa Juno Berhasil Memotret Salah Satu Satelit Alami Jupiter yang Dipenuhi Gunung Berapi\n" +
                    "\n" +
                    "Satelit Indonesia Pertama\n" +
                    "\n" +
                    "Pada tanggal 9 Juli 1976, Indonesia pertama kali meluncurkan satelit pertama bernama Palapa A1 dari Kennedy Space Center, Tanjung Canaveral, Amerika Serikat.\n" +
                    "\n" +
                    "Inilah kenapa setiap tanggal 9 Juli diperingati sebagai Hari Satelit Palapa.\n" +
                    "\n" +
                    "Nama satelit ini diambil dari \"Sumpah Palapa\", yang pernah dicetuskan oleh Patih Gajah Mada dari Majapahit pada tahun 1334.\n" +
                    "\n" +
                    "Satelit Palapa A1 yang berbobot 574 kilogram dilepaskan ke angkasa oleh roket Delta 2914.\n" +
                    "\n" +
                    "BACA JUGA : Mengenal Satelit Buatan yang Berada di Ruang Angkasa\n" +
                    "\n" +
                    "Di masa itu, setelah Amerika Serikat dan Kanada, Indonesia merupakan negara ketiga di dunia yang mengoperasikan Sistem Komunikasi Satelit Domestik (SKSD) menggunakan Satelit GSO (Geo Stationer Orbit) .\n" +
                    "\n" +
                    "Setelah itu, sampai saat ini ada banyak satelit baru lainnya, yang fungsinya semakin canggih dan bisa membantu aktivitas kita sehari-hari.\n" +
                    "\n" +
                    "Nah, sekarang sudah tahu, kan, teman-teman?");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 12 Juli: Hari Koperasi")){
            infoBulan.setText("tirto.id - Lembaga ekonomi berbentuk koperasi di Indonesia baru bisa diwujudkan setelah kemerdekaan, tepatnya pada 12 Juli 1947. Sejak itu, setiap tanggal 12 Juli diperingati sebagai Hari Koperasi Indonesia. Sejarah mencatat, ada satu momen penting sebagai awal-mula penetapan hari peringatan itu. Menurut buku Pengetahuan Perkoperasian (1977) yang ditulis Dahlan Djazh, pergerakan koperasi di Indonesia mengadakan kongres nasional yang pertama pada 12 Juli 1947, bertempat di Tasikmalaya, Jawa Barat. Inilah yang menjadi dasar penetapan Hari Koperasi Indonesia. Ditetapkannya tanggal 12 Juli sebagai Hari Koperasi Indonesia terkait dengan penyelenggaraan Kongres Koperasi Pertama juga terungkap dalam buku Garis-garis Besar Rentjana Pembangunan Lima Tahun 1956-1960 (1954) yang diterbitkan Biro Perantjang Negara dan dicetak oleh Percetakan Negara. Selain menetapkan tanggal 12 Juli sebagai Hari Koperasi Indonesia, kongres pertama ini juga menghasilkan beberapa keputusan lain, di antaranya adalah dibentuknya SOKRI (Sentral Organisasi Koperasi Rakyat Indonesia) serta menunjuk para pengurusnya. Kongres Koperasi I dilangsungkan di PKKT (Pusat Koperasi Kabupaten atau Kota Tasikmalaya). Alasan dipilihnya Tasikmalaya adalah karena saat itu Kota Bandung sedang diduduki oleh Belanda yang datang kembali ke Indonesia tak lama setelah kemerdekaan.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Koperasi Indonesia & Alasan Diperingati Setiap 12 Juli\", https://tirto.id/ed9x Dikutip dari buku Koperasi: Sebuah Pengantar (1980) terbitan Departemen Perdagangan dan Koperasi, Kongres Koperasi Nasional kedua baru bisa dilaksanakan pada 15-17 Juli 1953, atau berselang cukup lama setelah kongres yang pertama. Hal itu disebabkan karena situasi setelah kongres pertama belum stabil seiring terjadinya pergolakan kontra Belanda atau masa perang mempertahankan kemerdekaan (1945-1949). Kondisi mulai membaik setelah penyerahan kedaulatan dari Belanda kepada Indonesia pada akhir Desember 1949. Dalam kongres kedua di Bandung itu, perwakilan koperasi dari hampir seluruh wilayah Indonesia hadir. Muslimin Nasution dalam buku Koperasi: Konsepsi, Pemikiran, dan Peluang Membangun Masa Depan Bangsa (1999) mengungkapkan, kongres ini memutuskan perubahan nama SOKRI menjadi Dewan Koperasi Indonesia (DKI). Kongres Koperasi yang kedua juga menetapkan Mohammad Hatta sebagai Bapak Koperasi Indonesia. Wakil Presiden RI pertama ini dianggap sangat berjasa bagi perkembangan perekonomian Indonesia, juga berkat pidatonya dalam peringatan Hari Koperasi Nasional pada 21 Juli 1951.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Koperasi Indonesia & Alasan Diperingati Setiap 12 Juli\", https://tirto.id/ed9x Kedudukan koperasi di Indonesia semakin kuat setelah memperoleh badan hukum menurut Undang-Undang No.12 Tahun 1967. Disebutkan, koperasi adalah organisasi ekonomi rakyat yang berwatak sosial, beranggotakan orang-orang atau badan hukum dengan tata susunan ekonomi sebagai usaha bersama serta berdasarkan asas kekeluargaan. Lembaga koperasi pun berkembang pesat di seluruh wilayah Indonesia, bahkan menjadi menjadi tulang punggung sekaligus salah satu pilar utama ekonomi nasional hingga saat ini. Maka tidak heran jika koperasi disebut sebagai soko guru perekonomian Indonesia.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Koperasi Indonesia & Alasan Diperingati Setiap 12 Juli\", https://tirto.id/ed9x Baca juga artikel terkait KOPERASI atau tulisan menarik lainnya Wisnu Amri Hidayat (tirto.id - Ekonomi) Kontributor: Wisnu Amri Hidayat Penulis: Wisnu Amri Hidayat Editor: Iswara N Raditya\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Koperasi Indonesia & Alasan Diperingati Setiap 12 Juli\", https://tirto.id/ed9x");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 14 Juli: Hari Pajak")){
            infoBulan.setText("\n" +
                    "Hari Pajak Nasional Pertama\n" +
                    "Hari Pajak Nasional Pertama\n" +
                    "\n" +
                    "Oleh: Hepi Cahyadi, Pegawai Direktorat Jenderal Pajak \n" +
                    "\n" +
                    "Sesuai Keputusan Direktur Jenderal Pajak Nomor KEP-313/PJ/2017 tanggal 22 Desember 2017 Tentang Penetapan Hari Pajak. Tanggal 14 Juli 2018 akan kita peringati sebagai Hari Pajak Pertama. Kepdirjan tersebut menetapkan bahwa tanggal 14 Juli 1945 diperingati sebagai hari pajak. Secara garis besar, latar belakang penetapan Hari Pajak mengacu pada kata pajak yang muncul dalam “rancangan UUD kedua” yang disampaikan pada tanggal 14 Juli 1945 pada Bab VII Hal Keuangan, Pada Pasal 23 menyebutkan pada butir kedua, \"Segala pajak untuk keperluan negara berdasarkan Undang-undang.\"\n" +
                    "\n" +
                    "Dalam Kepdirjen tersebut dijelaskan mekanisme peringatan Hari pajak antara lain berupa upacara bendera, kegiatan olah raga, kegiatan seni, kegiatan sosial, dan kegiatan lain yang dapat meningkatkan rasa kebanggaan terhadap tanah air Indonesia serta institusi Direktorat jenderal Pajak (DJP), menguatkan rasa kebersamaan antar pegawai, serta memberikan nilai manfaat bagi para pemangku kepentingan. Sekilas jika ditilik dari batang tubuh Kepdirjan dan penjelasannya, peringatan Hari Pajak tak ubahnya seperti peringatan Hari Oeang, namun secara spesifik yang memperingati hanya di lingkungan DJP.\n" +
                    "\n" +
                    "Titik kritis (critical point) yang bisa dibahas tentang Hari Pajak adalah tentang manfaat peringatan Hari Pajak itu sendiri. Jika yang memperingati hanya di lingkungan DJP maka nama hari peringatan tersebut lebih tepat dinamakan Hari Fiskus Nasional. Untuk mendapatkan dampak dan efek yang lebih membahana, Hari Pajak sebaiknya dirayakan dan diperingati secara nasional dan melibatkan seluruh rakyat Indonesia utamanya para pemangku kepentingan. Pesan utama peringatan Hari Pajak adalah membangun kesadaran masyarakat luas tentang arti penting pajak bagi keberlangsungan NKRI. Sistem perpajakan di Indonesia yang menganut self assessment perlu digelorakan tiap tahun sebagai wujud patriotism rakyat kepada tanah air tercinta.\n" +
                    "\n" +
                    "Hari Pendidikan Nasional atau disingkat HARDIKNAS diperingati setiap tanggal 2 Mei (bukan hari libur) ditetapkan pemerintah melalui Keppres No. 316/1959 tanggal 16 Desember 1959. Hari Pendidikan Nasional diperingati bertepatan dengan hari ulang tahun tokoh pendidikan nasional Ki Hajar Dewantoro. Hardiknas mengkampanyekan betapa penting arti pendidikan bagi suatu bangsa. Setiap tahun kita diingatkan bahwa pendidikan adalah prasyarat utama sebuah bangsa yang ingin maju dan bermartabat. Pendidikan adalah sebuah proses kegiatan belajar dan mengajar, sedangkan Guru adalah sebuah profesi dalam dunia pendidikan. Sehingga Pendidikan dan Guru adalah sesuatu hal yang berbeda, seperti halnya Pajak dan Fiskus. Dalam UU No. 14 tahun 2005 tentang Guru dan Dosen menetapkan tanggal 25 November  sebagai Hari Guru nasional yang diperingati bersamaan dengan hari ulang tahun Persatuan Guru Republik Indonesia (PGRI). Sekali lagi Hari Pendidikan dan Hari Guru adalah dua hal yang berbeda.\n" +
                    "\n" +
                    "Dari uraian di atas Keputusan Direktur Jenderal Pajak Nomor KEP-313/PJ/2017 tanggal 22 Desember 2017 Tentang Penetapan Hari Pajak latar belakang penentuan Hari Pajak telah benar, namun penulis berpendapat mekanisme peringatannya masih dalam skup kecil hanya di lingkungan DJP, sehingga lebih pantas disebut Hari Fiskus. Berdasarkan penelusuran Google, di Amerika Serikat sejak 1955 Tax Day atau Hari Pajak biasanya jatuh pada tanggal 15 April bertepatan dengan batas akhir penyampaian SPT Pajak Pribadi (OP). Untuk warga Amerika yang tinggal di luar negeri dan bagian Puerto Rico, Hari Pajaknya jatuh pada tanggal 15 Juni. Jika tanggal 15 April jatuh pada hari Jumat, maka Hari Pajaknya jatuh pada hari senin selanjutnya. Jika 15 April jatuh pada hari sabtu atau minggu maka batas waktu penyampaian SPT adalah hari selasa selanjutnya.\n" +
                    "\n" +
                    "Memang, Indonesia tak harus mengacu pada negara lain tentang peringatan Hari Pajak, namun demikian urgensi peringatan Hari Pajak harus tetap berdampak bagi seluruh rakyat Indonesia. Secara Internal menguatkan rasa kebersamaan antar pegawai, dan secara Eksternal juga berpegaruh meningkatkan kesadaran kewajiban perpajakan, selain itu sebagai peringatan dini tiap tahun dalam rangka efouria bernegara. Sebagai penutup tulisan ini, Hari Pajak seyogyanya dapat ditingkatkan derajatnya melalui ketetapan oleh pemerintah semisal dengan Keppres setara dengan Hardiknas, sehingga nomen klaturnya bisa disingkat menjadi HARPANAS atau HARJAKNAS.\n" +
                    "\n" +
                    "Selamat Merayakan Hari Pajak Pertama.. 14 Juli 2018 (*)\n" +
                    "\n" +
                    "*) Tulisan ini merupakan pendapat pribadi penulis dan bukan cerminan sikap instansi dimana penulis bekerja.\n");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 22 Juli: Hari Kejaksaan")){
            infoBulan.setText("Mr Goenawan menjadi Jaksa Agung terhitung tanggal 31 Desember 1959. Sebelumnya, pada masa kepemimpinan Mr Gatot, ia menjabat sebagai Jaksa Agung Muda. Pada era Mr Goenawan, dalam tubuh Departemen Kejaksaan terbentuk Biro Pengawasan Aliran Kepercayaan (Biro Pakem) sebagai kelanjutan dari Badan Pakem yang dibentuk tahun 1958. Pada era ini pula, tugas kejaksaan meluas, tidak hanya pada bidang represif saja, melainkan juga ke bidang preventif dan bahkan pemerintahan dan keamanan, seperti dalam persoalan orang asing serta pelaksanaan pembinaan pers nasional.\n" +
                    "\n" +
                    "Saat ini pula terwujud Rancangan Undang-undang Pokok Kejaksaan serta UU Pokok Kepolisian yang menetapkan tugas-tugas Jaksa dalam hubungannya dengan batas-batas tugas-tugas hakim dan polisi. Pada tanggal 22 Juli 1960, kabinet dalam rapatnya memutuskan bahwa kejaksaan menjadi departemen dan keputusan tersebut dituangkan dalam surat Keputusan Presiden RI tertanggal 1 Agustus 1960 No.204/1960 yang berlaku sejak 22 Juli 1960. RUU ini kemudian disahkan pemerintah cq Presiden pada tanggal 30 Juni 1961 dan dinamai UU Nomor 15 tahun 1961. UU ini memuat Ketentuan-ketentuan Pokok Kejaksaan atau Undang-undang Pokok Kejaksaan (UUPK). Hal itulah yang melatarbelakangi penetapan 22 Juli sebagai hari Kejaksaan dengan surat Keputusan Menteri/JA No. Org/A-51/1 tanggal 2 Januari 1961.\n" +
                    "\n" +
                    "Gagasan Lambang Kejaksaan dan penggunaan pakaian seragam jaksa terwujud pada masa ini. Hal-hal baru lainnya yang ditegaskan dalam UU ini di antaranya landasan hokum bagi pegawasan aliran kepercayaan yang dapat membahayakan  masyarakat dan negara (Pasal 2 (4)), landasan hukum pembentukan Kejaksaan tinggi, Kedudukan Kejaksaan sebagai Departemen dan Jaksa Agung sebagai menteri (Pasal 3 dan 5), surat tuduhan tidak lagi dibuat oleh hakim, tapi oleh Jaksa (pasal 12 (1).\n" +
                    "\n" +
                    "Selain dari itu, Jaksa Agung Mr. Goenawan juga berperan dalam mewujudkan pemasukan kembali Irian Jaya ke dalam Negara Kesatuan Republik Indonesia.  ");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 23 Juli: Hari Anak Nasional")){
            infoBulan.setText("tirto.id - Hari Anak Nasional (HAN) diperingati setiap tanggal 23 Juli. Ada sejarah dan alasan yang mendasari hal ini. Bermula pencetusan Hari Kanak-Kanak Indonesia di era Presiden Sukarno (Orde Lama) yang berproses cukup rumit, hingga nantinya diganti oleh Presiden RI ke-2 Soeharto pada 1984. Menurut Kementerian Pemberdayaan dan Perlindungan Anak Indonesia (KPPAI), peringatan Hari Anak Nasional dimaknai sebagai kepedulian seluruh bangsa terhadap perlindungan anak Indonesia agar tumbuh dan berkembang secara optimal. Caranya adalah dengan mendorong keluarga menjadi lembaga pertama dan utama dalam memberikan perlindungan kepada anak, sehingga akan menghasilkan generasi penerus bangsa yang sehat, cerdas, ceria, berakhlak mulia, dan cinta tanah air. Hingga saat ini, peringatan HAN dirayakan dengan berbagai kegiatan. Bahkan, KPPAI telah menyediakan pedoman penyelenggarakan peringatan HAN dengan dukungan penuh dari pemerintah. Baca juga: Hari Anak Nasional: Gembiralah Anak-Anak Indonesia Dalam laman resminya, KPPAI menyampaikan bahwa masyarakat dari tingkat daerah hingga provinsi bebas mengadakan kegiatan seperti seminar, menonton film bersama, bakti sosial, jalan sehat gembira, berbagai jenis perlombaan, dan lain-lain, dengan dana dari Anggaran Pendapatan dan Belanda Negara (APBN). HAN juga dijadikan sebagai pengingat bagi rakyat Indonesia untuk menggencarkan gerakan Internasional World Fit for Children. Gerakan ini direalisasikan dengan Kota Layak Anak di sejumlah kota di Indonesia. Tujuan akhir dari gerakan ini tentu saja mewujudkan Indonesia Layak Anak. Sejarah Hari Anak Nasional Peringatan hari anak di tanah air merupakan gagasan Kongres Wanita Indonesia (Kowani). Kowani adalah organisasi kaum perempuan Indonesia yang embrionya tercetus sejak Kongres Perempuan Indonesia I pada 22 Desember 1928, atau beberapa pekan setelah Sumpah Pemuda. Kowani, yang diresmikan tahun 1946, dalam sidangnya pada 1951 memutuskan beberapa kesepakatan. Salah satunya, menurut artikel dalam Majalah Rona (1988), adalah mengupayakan penetapan Hari Kanak-Kanak Nasional. Baca juga: Sejarah Hari Ibu di Indonesia Upaya tersebut ditindaklanjuti dengan digelarnya Pekan Kanak-Kanak pada 1952. Dalam kegiatan ini, anak-anak berpawai di Istana Merdeka dan disambut langsung oleh Presiden Sukarno. Dalam Sidang Kowani di Bandung yang dihelat pada 1953, Pekan Kanak-kanak Indonesia dirumuskan lebih serius lagi. Kegiatan itu akan rutin dilaksanakan setiap pekan kedua bulan Juli, atau saat liburan kenaikan kelas. Rekomendasi ini disetujui oleh pemerintah. Namun, penetapan itu dinilai tidak memiliki makna dan nilai historisnya karena tidak merujuk kepada tanggal atau momen tertentu. Maka, dalam Sidang Kowani di Jakarta pada 24-28 Juli 1964, muncul berbagai usulan mengenai kapan tepatnya peringatan untuk hari anak-anak di Indonesia. Pada 1959, dikutip dari artikel “Mencari Jejak Hari Anal” tulisan Budi Setiyono dalam Historia.id (22 Juli 2018), pemerintah akhirnya menetapkan tanggal 1-3 Juni untuk memperingati hari anak di Indonesia, bersamaan dengan rangkaian peringatan Hari Anak Internasional pada 1 Juni. Presiden Sukarno seringkali hadir dalam perayaan hari anak ini. Maka, atas usulan Kowani, tanggal 6 Juni ditetapkan sebagai Hari Kanak-Kanak Indonesia. Alasannya, selain bertepatan dengan hari lahir Bung Karno (1 Juni 1901), tanggal ini juga berdekatan dengan perayaan Hari Anak Internasional. Persoalan timbul lagi setelah runtuhnya Orde Lama dan usainya kekuasaan Sukarno. Orde Baru di bawah pimpinan Soeharto berusaha menghapus semua kebijakan yang lekat dengan rezim sebelumnya, termasuk mengenai peringatan Hari Kanak-Kanak Indonesia yang memang bertepatan dengan hari lahir Sukarno. Baca juga: Orde Baru Membunuh Sukarno Pelan-Pelan Dalam prosesnya, tanggal peringatan hari anak di Indonesia sempat beberapa kali mengalami perubahan. Hingga akhirnya, Soeharto mengeluarkan Keputusan Presiden (Keppres) No. 44/1984 yang memutuskan bahwa Hari Anak Nasional diperingati setiap tanggal 23 Juli. Mengapa 23 Juli? Pemilihan tanggal ini diselaraskan dengan pengesahan Undang-Undang tentang Kesejahteraan Anak pada 23 Juli 1979. Peringatan HAN diselenggarakan dari tingkat pusat hingga daerah untuk mewujudkan Indonesia sebagai negara yang ramah anak Baca juga artikel terkait HARI ANAK NASIONAL atau tulisan menarik lainnya Yonada Nancy & Iswara N Raditya (tirto.id - Sosial Budaya) Kontributor: Yonada Nancy Penulis: Yonada Nancy & Iswara N Raditya Editor: Iswara N Raditya\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Sejarah Hari Anak Nasional & Alasan Diperingati Setiap 23 Juli\", https://tirto.id/eeSs");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 23 Juli: Hari Komite Nasional Pemuda Indonesia (KNPI)")){
            infoBulan.setText("Sudah jadi pekerjaan Mayor Jenderal Ali Moertopo untuk menjalin persatuan dan kesatuan semua golongan, tentu saja demi stabilitas daripada kepresidenan Soeharto. Pentolan organ intel legendaris bernama Operasi Khusus (Opsus) ini juga tak ragu mendekatkan diri kepada pemuda-pemuda terpilih.\n" +
                    "\n" +
                    "Para pemuda yang dekat dengan Ali antara lain berasal dari Himpunan Mahasiswa Islam (HMI), Perhimpunan Mahasiswa Katolik Republik Indonesia (PMKRI), Gerakan Mahasiswa Nasional Indonesia (GMNI), Gerakan Mahasiswa Kristen Indonesia (GMKI), dan Pergerakan Mahasiswa Islam Indonesia (PMII). Mereka suka diskusi dan Ali suka mereka.\n" +
                    "\n" +
                    "Menurut M Ali Akbar, dalam Biografi Politikus dan Budayawan Ridwan Saidi (2018:5), diskusi-diskusi itu berlangsung di Cipayung, Bogor.\n" +
                    "\n" +
                    "\"Sehingga kelompok ini disebut kelompok Cipayung,\" tulis Ali Akbar.\n" +
                    "\n" +
                    "Cipayung sendiri bukan tempat asing bagi orang intelijen. Seperti dicatat Ken Conboy dalam Intel: Menguak Tabir Intelejen Indonesia (2007:64), ada sebuah tempat liburan Dewi Sukarno (istri Presiden Sukarno) di Cipayung yang dijadikan tempat latihan intel Indonesia. Seorang intel Israel bahkan pernah melatih intel Indonesia di sana. Tentu dulu tak banyak yang tahu kalau Cipayung sering dipakai sebagai tempat latihan intel. Namun pemuda melek politik dari masa lalu, tentu tahu kelompok Cipayung dan apa saja kegiatan yang sering dilakukan di sana.\n" +
                    "\n" +
                    "Baca juga: Sejarah Karier Ali Moertopo, Raja Intel Zaman Soeharto\n" +
                    "\n" +
                    "Karena banyaknya organ pemuda dari berbagai latar belakang, muncul ide untuk membuat induk dari kelompok-kelompok ini. Ali Moertopo beruntung punya kolega bernama Midian Sirait. Pada 1973, mantan pejabat kampus Institut Teknologi Bandung (ITB) ini adalah anggota Dewan Perwakilan Rakyat Gotongroyong (DPRGR). Bekas tentara pelajar di Sumatra Utara ini yang kemudian punya usul pembentukan induk dari semua organiasi pemuda.\n" +
                    "\n" +
                    "“Yang kami inginkan adalah suatu organisasi yang menampung kader-kader dari masing-masing partai atau masing-masing organiasi pemuda dan mahasiswa yang ada,\" tulis Midian dalam autobiografinya yang disusun Ramadhan KH dkk, Demi Bangsa: Liku-Liku Pengabdian Prof. Dr. Midian Sirait: Dari Guru SR Porsea sampai Guru Besar ITB (1999:198)\n" +
                    "\n" +
                    "Ali Moertopo suka dengan ide Midian itu. Menurut Ali Akbar (2018:22), sebagai Wakil Kepala Badan Koordinasi Intelejen Negara (BAKIN) merangkap kepala Opsus, Moertopo punya kehendak organisasi yang dimaksud haruslah menjadi “wadah tunggal” bagi organisasi kepemudaan.\n" +
                    "\n" +
                    "Akhirnya para tokoh pemuda seperti Akbar Tandjung, David Napitupulu, dan lainnnya berkumpul. Maka, pada 23 Juli 1973 terbentuklah Komite Nasional Pemuda Indonesia (KNPI). Ketua pertamanya adalah David Napitupulu.\n" +
                    "\n" +
                    "“Ali Moertopo dapat disebut sebagai 'bidan' lahirnya KNPI. Dia menungguinya ketika KNPI lahir dan selalu memberi pengarahan yang dibutuhkan,” tulis Krissantono dalam buku Di Atas Panggung Sejarah: Dari Sultan ke Ali Moertopo (1991:154).\n" +
                    "\n" +
                    "KNPI bukan satu-satunya contoh \"obsesi\" Ali Moertopo soal wadah tunggal. Di luar kelompok pemuda, ada Federasi Buruh Seluruh Indonesia (FBSI) di dunia kaum buruh, di dunia usaha ada Kamar Dagang dan Industri (Kadin), di dunia pertanian ada Himpunan Kerukunan Tani Indonesia (HKTI), dan di wilayah gerakan perempuan ada Kongres Wanita Indonesia (Kowani). Menurut Cosmas Batubara, dalam Panjangnya Jalan Politik, Ali Moertopo adalah inspirasi dari wadah tunggal.\n" +
                    "\n" +
                    "Di hari Sumpah Pemuda, 28 Oktober 1974, KNPI menyelenggarakan kongres pertama mereka. Di momen itu pula, AD/ART mereka tersusun. “Sejak itu KNPI menjadi wadah tunggal organisasi pemuda, dan ormas mahasiswa terserap di dalamnya,” tulis Didik Supriyanto dalam Perlawanan Pers Mahasiswa: Protes Sepanjang NKK/BKK (1998:37). Jadi semua organisasi “baik-baik” zaman itu haruslah ikut dalam KNPI.\n" +
                    "\n" +
                    "Sebagai anak kandung dari orde baru, KNPI jelas dekat dengan pemerintah daripada Presiden Soeharto. Ketika muncul isu pemberian gelar kepada Jenderal Soeharto sebagai Bapak Pembangunan pada 1981, KNPI ada. Kala itu Ketua KNPI adalah Akbar Tanjung dan Ali Moertopo bukan lagi kepala Opsus—karena Opsus bubar—melainkan sebagai Menteri Penerangan.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Baca juga: Keluarga Akbar Tanjung, Om Liem Sioe Liong dan Indomilk\n" +
                    "\n" +
                    "Akbar Tanjung yang jadi orang penting di KNPI punya nasib baik sama seperti David Napitupulu. Mereka jadi orang penting di Golkar, lalu pemerintahan. David pernah menjadi ketua sayap pemuda Golkar, Angkatan Muda Pembaharuan Indonesia (AMPI), lalu Duta Besar Meksiko. Sementara Akbar Tanjung yang pernah jadi Wakil Sekjen Golkar, pernah menjadi Menteri Negara Perumahan Rakyat.\n" +
                    "\n" +
                    "Tokoh KNPI terkenal lainnya adalah: Cosmas Batubara dan Abdul Gafur. Cosmas pernah jadi anggota DPR dan jadi Menteri Negara Perumahan Rakyat. Selain itu ada juga mantan dokter Angkatan Udara bernama Abdul Gafur, yang pernah jadi Menteri Pemuda dan Olahraga zaman Soeharto.\n" +
                    "\n" +
                    "Jajaran pemimpin KNPI memang kebanyakan berasal dari Angkatan 1966 yang sukses mendongkel Sukarno dari kursi presiden. Mereka bukan sekadar jadi parlemen jalanan, melainkan pemimpin organisasi mahasiswa. Di era 1980-an banyak pemuda Angkatan 1966 yang naik taraf hidupnya. Setelah jadi orang partai atau ormas mereka jadi pejabat negara, seperti halnya bidan KNPI sendiri, Ali Moertopo.\n" +
                    "\n" +
                    "Ketika Ali Moertopo tutup usia pada 15 Mei 1984, KNPI tidak lantas bubar. KNPI terus jaya sepanjang Orde Baru. Bahkan ketika Soeharto tumbang dan menandai berakhirnya era Orde Baru, KNPI masih tetap berdiri. Sekarang, usia KNPI tentu tak bisa dibilang muda lagi.\n" +
                    "\n" +
                    "“Sebagai organisasi tua, KNPI menganggap diri sebagai bagian penerus Generasi Sumpah Pemuda,” tulis Hafriadi Hamid dalam Manajemen Merah Putih: Kumpulan Esai yang Mulanya Berserakan (2018:96).\n" +
                    "\n" +
                    "KNPI telah membuktikan diri sebagai organ penting dalam sejarah sebagai wadah tunggal organisasi pemuda era Orde Baru.\n" +
                    "\n" +
                    "Baca juga artikel terkait SEJARAH INDONESIA atau tulisan menarik lainnya Petrik Matanasi\n" +
                    "(tirto.id - Politik)\n" +
                    "\n" +
                    "Penulis: Petrik Matanasi\n" +
                    "Editor: Nuran Wibisono");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 29 Juli: Hari Bhakti TNI Angkatan Udara")){
            infoBulan.setText("\n" +
                    "\n" +
                    "Harianjogja.com, BIAK--Peringatan Hari Bhakti TNI Angkatan Udara pada 29 Juli memiliki makna yang sarat dengan nilai kejuangan bagi prajurit untuk menjadi kompas moral bagi pengabdian terbaik kepada TNI AU.\n" +
                    "\n" +
                    "\"Pada tanggal tersebut, tepatnya 29 Juli 1947, ada dua peristiwa penting yang terjadi dalam sejarah perjuangan bangsa Indonesia, khususnya TNI Angkatan Udara,\" ungkap Danlanud Manuhua Marsma TNI Daan Sulfi membacakan amanat KSAU Marsekal TNI Yuyu Sutisna pada peringatan Hari Bhakti TNI ke-72 dipusatkan di Skadron 27 Biak, Senin (29/7/2019).\n" +
                    "\n" +
                    "Marsekal Yuyu Sutisna dalam sambutan tertulisnya mengakui, peristiwa heroik tanggal 29 Juli hendaknya tidak sekedar menjadi nostalgia sejarah semata, namun terus menjadi kompas moral bagi generasi penerus untuk memberikan pengabdian yang terbaik kepada TNI Angkatan Udara.\n" +
                    "\n" +
                    "\"Spirit Hari Bhakti Angkatan Udara harus dimanifestasikan dalam proses pembangunan postur kekuatan dan kemampuan TNI Angkatan Udara yang profesional dan modern,\" katanya.\n" +
                    "\n" +
                    "Ia mengatakan, momentum Hari Bhakti ini adalah saat tepat untuk membangun komitmen bahwa TNI AU mampu mencetak kader-kader prajurit yang berkarakter sama hebatnya dengan para aktor sejarah Hari Bhakti TNI Angkatan Udara.\n" +
                    "\n" +
                    "Ada dua peristiwa peringatan Hari Bhakti TNI AU itu, yang pertama adalah keberhasilan Angkatan Udara Republik Indonesia dalam melakukan serangan udara terhadap kedudukan militer Belanda di Semarang, Ambarawa dan Salatiga.\n" +
                    "\n" +
                    "Serangan udara ini merupakan serangan udara yang pertama kali dilakukan oleh Angkatan Udara Republik Indonesia. Sedangkan peristiwa kedua, lanjut KSAU, yang terjadi pada tanggal tersebut adalah tertembaknya pesawat Dakota VT-CLA yang mengakibatkan gugurnya para perintis Angkatan Udara Republik Indonesia (AURI), yaitu Komodor Muda Udara Abdulrachman Saleh, Komodor Muda Udara A. Adisutjipto dan Opsir Muda Udara Adi Soemarmo Wirjokusumo.\n" +
                    "\n" +
                    "Dakota VT-CLA ditembak jatuh oleh P-40 Kittyhawk Belanda pada 29 Juli 1947 di Dusun Ngoto, Bantul, dekat Yogyakarta dalam perjalanan pulang dari Singapura membawa bantuan obat-obatan dari Palang Merah Malaya menuju Pangkalan Udara Maguwo.\n" +
                    "\n" +
                    "\"Untuk mengenang dan mengabadikan peristiwa gugurnya para tokoh dan perintis Angkatan Udara tersebut, sejak tanggal 29 Juli 1955 diperingati sebagai 'Hari Berkabung' AURI. Mulai 29 Juli 1962 diubah menjadi Hari Bhakti TNI AU,\" katanya.");
        }else if(tanggal.equalsIgnoreCase(" Tanggal 31 Juli: Hari Lahir Korps Pelajar Islam Indonesia (PII) Wati")){
            infoBulan.setText("HARI Korps Pelajar Islam Indonesia diperingati pada 31 Juli setiap tahunnya. Pelajar Islam Indonesia merupakan organisasi Islam eksternal sekolah untuk para Pelajar hingga mahasiswa. Pelajar Islam Indonesia (PII) adalah organisasi yang berasaskan Islam dan berdiri Independent serta bergerak dibidang pendidikan.\n" +
                    "\n" +
                    "PII didirikan sebagai usaha untuk kaderisasi muslim cendikia, dan pemimpin yang bergerak dalam bidang pendidikan dan kebudayaan yang sesuai dengan ajaran Islam. Pada awalnya gagasan Korps PII Wati lahir di Training Centre (TC) Keputerian PII se-Indonesia yang dilaksanakan pada tanggal 20-28 Juli 1963 di Surabaya. Dalam TC berkembang kesadaran kuat untuk meningkatkan peranan dan kualitas kader dan kepemimpinan PII Wati serta menghapus citra negatif peran PII Wati hanya sebagai pengelola konsumsi.\n" +
                    "\n" +
                    "Fakta bahwa kesempatan bagi pelajar puteri untuk mengembangkan diri di PII relatif lebih terbatas dan pendek dibandingkan pelajar putra. Selanjutnya dalam sidang keputerian Muktamar PII X Juli 1964 di Malang, Koprs PII Wati Yogyakarta Besar diwakili St. Wardanah AR, Masyitoh Sjafei dan Hafsah Said mengajukan usulan pembentukan Koprs PII Wati. Sementara Sri Sjamsiar dari PB PII juga mengajukan usul serupa. Kedua usulan itu diterima dalam Muktamar tersebut. Akhirnya pada tanggal 31 Juli ditetapkan sebagai Hari lahir PII Wati.\n" +
                    "Tujuan PII ini untuk menyempurnakan pendidikan dan kebudayaan yang sesuai dengan Islam bagi segenap Bangsa Indonesia dan umat manusia.| Sumber : piijepara.blogspot.co.id\n" +
                    "Tags: Fakultas Teknik, Ragam, UKM Rohima Universitas Malahayati, Universitas Malahayati");
        }
    }
}
