package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilJuni extends AppCompatActivity {
    String JUNI;
    TextView infoBulan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_juni);
        // ambil textview info di acivity
        infoBulan=(TextView) findViewById(R.id.info_juni);

        // ambil parameter
        Intent intent = getIntent();
        JUNI = intent.getStringExtra("juni");

        // panggil
        setJUNI(JUNI);
    }

    private void setJUNI(String tanggal) {
        if(tanggal.equalsIgnoreCase("Tanggal 1 Juni: Hari Lahir Pancasila")){
            infoBulan.setText("RIBUNJOGJA.COM - Jumat, 1 Juni 2018, merupakan hari libur nasional untuk memperingati hari lahir Pancasila.\n" +
                    "\n" +
                    "Sudah dua tahun ini atau tepatnya dimulai tahun 2017 lalu, setiap tanggal 1 Juni yang merupakan hari lahir Pancasila, ditetapkan sebagai hari libur secara nasional.\n" +
                    "\n" +
                    "Penetapan ini berdasarkan Keputusan Presiden Nomor 24 Tahun 2016, yang disampaikan Presiden Joko Widodo (Jokowi) saat menyampaikan pidato pada peringatan Pidato Bung Karno 1 Juni 1945, di Gedung Merdeka, Bandung, pada 1 Juni 2016.\n" +
                    "\n" +
                    "Baca: Pancasila sebagai Sumber Etika dalam Era Revolusi Industri\n" +
                    "\n" +
                    "Libur hari lahir Pancasila baru terealisasi di era Jokowi.\n" +
                    "\n" +
                    "Putri Soekarno, Megawati Soekarno Putri, sebenarnya sudah mengusulkan agar 1 Juni ditetapkan sebagai hari lahir Pancasila dan menjadi hari besar nasional, sejak pemerintahan Susilo Bambang Yudhoyono (SBY).\n" +
                    "\n" +
                    "Namun, hal itu tak kunjung terealisasi.\n" +
                    "\n" +
                    "Oleh karena itu, ia sangat mengapresiasi pemerintahan Jokowi yang berani mengambil keputusan itu.\n" +
                    "\n" +
                    "Sebelum keputusan hari libur nasional untuk memperingati hari lahir Pancasila ini diketok, Jokowi pernah mengungkapkan harapannya agar Pancasila tak hanya sekadar diperingati saja.\n" +
                    "\n" +
                    "Namun, ia berharap agar Pancasila diamalkan dalam kehidupan sehari-hari.\n" +
                    "\n" +
                    "Baca: Slank Akan Ramaikan Konser Indonesia Damai #PancasilaRumahKita di Grha Sabha Pramana UGM\n" +
                    "\n" +
                    "\"Tanpa perjuangan, pesan dalam Pancasila tak akan menjelma jadi realitas. Presiden Jokowi mengajak rakyat bersatu padu dan bergotong royong mewujudkan cita-cita itu,\" kata Sekretaris Kabinet Pramono Anung mengutip pidato Presiden Jokowi saat peringatan Hari Lahir Pancasila di Alun-alun Kota Blitar, Jawa Timur, 1 Juni 2015.\n" +
                    "\n" +
                    "Rumusan Soekarno\n" +
                    "\n" +
                    "Dihimpun dari berbagai sumber, Lahirnya Pancasila bermula dari sidang Badan Penyelidik Usaha-usaha Persiapan Kemerdekaan Indonesia (BPUPKI) pada 29 Mei hingga 1 Juni 1945.\n" +
                    "\n" +
                    "Setelah Muh Yamin dan Dr Soepomo menyampaikan gagasan mereka, Soekarno juga menyampaikan rumusannya pada 1 Juni 1945.\n" +
                    "\n" +
                    "Ada tiga rumusan dasar negara yang diajukan Soekarno, yakni Pancasila, Trisila dan Ekasila.\n" +
                    "\n" +
                    "Namun, yang disetujui oleh anggota BPUPKI adalah Pancasila, yakni kebangsaan Indonesia atau nasionalisme, internasionalisme atau peri-kemanusiaan, mufakat atau demokrasi, kesejahteraan sosial, dan Ketuhanan.\n" +
                    "\n" +
                    "Pidato Soekarno inilah yang kemudian diperingati sebagai hari lahir Pancasila\n" +
                    "\n" +
                    "Rumusan Pancasila dari Soekarno itu selanjutnya masih dimusyawarahkan dengan berbagai tokoh nasional, hingga teksnya seperti yang kita kenal sekarang. (*)\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di Tribunjogja.com dengan judul Tanggal 1 Juni Hari Lahir Pancasila, Ini yang Perlu Diketahui tentang Hari Lahir Pancasila, https://jogja.tribunnews.com/2018/05/31/tanggal-1-juni-hari-lahir-pancasila-ini-yang-perlu-diketahui-tentang-hari-lahir-pancasila?page=all.\n" +
                    "Penulis: say\n" +
                    "Editor: Gaya Lufityanti ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 1 Juni: Hari Perlindungan Anak-anak Sedunia[21]")){
            infoBulan.setText("Hari anak yang merupakan event tahunan diselenggarakan pada tanggal yang berbeda-beda di berbagai negara.\n" +
                    "\n" +
                    "Jika Hari Anak Nasional di Indonesia diperingati setiap 23 Juli, Hari Anak Internasional diperingati setiap 1 Juni.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 1 Juni: Hari Susu Nusantara[22]")){
            infoBulan.setText("\n" +
                    "\n" +
                    "Peringatan Hari Susu, Momentum Tingkatkan Konsumsi Susu Masyarakat Indonesia\n" +
                    "\n" +
                    "Saat ini di tengah pandemi Covid-19  asupan makanan dan minuman yang bergizi tinggi sangat diperlukan untuk memperkuat daya tahan tubuh, salah satunya melalui konsumsi susu. Mengingat banyaknya manfaat yang diperoleh melalui susu,Organisasi Pangan dan Pertanian Dunia (FAO) sejak tahun 2001 menetapkan  tanggal 1 Juni diperingati sebagai Hari Susu Dunia (World Milk Day).\n" +
                    "\n" +
                    "Peringatan ini dimaknai untuk meningkatkan kesadaran tentang pentingnya mengonsumsi susu setiap hari. Kegiatan ini menjadi acara tahunan di banyak negara di dunia. Indonesia pun turut serta merayakan Hari Susu Dunia sejak tanggal 1 Juni 2009 melalui Keputusan Menteri Pertanian Nomor: 2182/KPTS/PD.420/5/2009, dengan tajuk Hari Susu Nusantara. \n" +
                    "\n" +
                    "Direktur Jenderal Peternakan dan Kesehatan Hewan, I Ketut Diarmita menyampaikan momentum Hari Susu Nusantara ini tentang pentingnya masyarakat untuk terus mengonsumsi susu namun berdasarkan data Badan Pusat Statistik (BPS), tingkat konsumsi susu masyarakat Indonesia tahun 2019 masih berkisar 16,23 kg/kapita/tahun.\n" +
                    "\n" +
                    "\"Konsumsi susu di Negara kita masih tergolong rendah jika dibandingkan dengan negara-negara lain,\"katanya saat diwawancarai pada Senin (1/06/20).\n" +
                    "\n" +
                    "Ia juga mengatakan secara umum susu banyak memiliki manfaat untuk pertumbuhan yaitu untuk regenerasi sel, menguatkan tulang dan gigi, menyokong pertumbuhan fisik, meningkatkan kecerdasan, mampu mencegah stunting pada anak-anak serta meningkatkan imunitas tubuh sehingga meminimalisir potensi terinfeksi agen penyakit.\n" +
                    "\n" +
                    "\"Di masa pandemi Virus Covid-19 saat ini, konsumsi susu menjadi penting untuk peningkatan imunitas tubuh yang merupakan salah satu cara untuk meminimalisir potensi terinfeksi agen penyakit,\"ucap Ketut.\n" +
                    "\n" +
                    "Selain Itu, Ketut juga menyoroti pentingnya peningkatan populasi sapi perah untuk meningkatkan produksi susu dan memenuhi kebutuhan susu nasional. Populasi sapi perah Nasional pada tahun 2019 sebanyak 561.061 ekor dengan produksi susu sebanyak 996.442 ton (Data Statistik Peternakan dan Kesehatan Hewan tahun 2019). \n" +
                    "\n" +
                    "\"Pertumbuhan populasi sapi perah dan pertumbuhan produksinya belum mampu mengimbangi pertumbuhan konsumsi, sehingga ketersediaan sebagian besar produk susu dan turunannya adalah melalui importasi yang semakin lama semakin meningkat,\"terangnya.\n" +
                    "\n" +
                    "Dengan jumlah kebutuhan susu nasional tahun 2019 mencapai 4.332,88 ribu ton, produksi Susu Segar Dalam Negeri (SSDN) diatas, hanya mampu memenuhi 22% dari kebutuhan nasional, sehingga 78%nya berasal dari impor (BPS 2020). Selain itu, produksi susu saat ini masih didominasi oleh susu sapi, padahal kita memiliki potensi ternak lain seperti kambing perah (Kambing Peranakan Ettawa, Kambing Saanen) dan kerbau perah yang pemanfaatannya belum optimal.\n" +
                    "\n" +
                    "\"Berbagai permasalahan dan tantangan dalam pengembangan industri susu nasional harus didorong bersama melalui peran aktif dari semua pihak, tidak hanya pemerintah namun juga akademisi, swasta, industri dan tentu saja para peternak itu sendiri,\" sambungnya.\n" +
                    "\n" +
                    "Kementerian Pertanian (Kementan) sebagai instansi teknis yang menangani peternakan, terus berupaya keras dalam mengembangkan persusuan nasional untuk mencapai target pemenuhan kebutuhan susu  nasion tahun 2025 sebanyak 60% sesuai dengan Cetak Biru Persusuan 2013-2025 yang dikeluarkan oleh Kemenko Perekonomian.\n" +
                    "\n" +
                    " Pemerintah menyusun dan menetapkan berbagai program dan kegiatan untuk pengembangan persusuan, baik melalui APBN, APBD, maupun melalui kemitraan dengan industri dan lembaga pembiayaan\", ungkapnya lebih lanjut.\n" +
                    "\n" +
                    "Selanjutnya, Ia mengungkapkan terkait upaya pemerintah untuk meningkatkan populasi sapi perah yang dilakukan melalui berbagai cara, diantaranya: program SIKOMANDAN (Sapi Kerbau Komoditas Andalan Negeri), pemasukan bibit sapi perah untuk replacement induk dan dikembangkan di Balai Ternak Unggul Baturaden.\n" +
                    "\n" +
                    "Pengembangan rearing unit di Unit Pelaksana Teknis (UPT)/Unit Pelaksana Teknis Daerah (UPTD) dan melalui kemitraan dengan Industri Pengolahan Susu (IPS), penetapan kawasan pengembangan sapi perah nasional, perbaikan mutu genetik melalui pejantan unggul hasil Uji zuriat atau progeny test dan produksi semen beku sexing, kemudahan dalam pengajuan rekomendasi pemasukan/pengeluaran ternak, produk ternak.\n" +
                    "\n" +
                    "\"Dapat melalui aplikasi Sistem Rekomendasi (SIMREK PKH) serta fasilitasi/kemudahan akses pembiayaan (Kredit Usaha Rakyat-KUR/Program Kemitraan Bina Lingkungan-PKBL) untuk peternak sapi perah,\"\n" +
                    "\n" +
                    "Selain itu, Kementan juga berupaya untuk mengembangkan ternak perah lain seperti kambing perah dan kerbau perah serta mendorong pihak swasta untuk melakukan diversifikasi genetik sapi perah melalui pengembangan sapi perah non Frisian Holstein/FH (sapi perah jersey). Pengembangan sapi perah non FH saat ini masih bersifat closed breeding untuk mengetahui kemampuan adaptasi dan produksi ternak di Indonesia.\n" +
                    "\n" +
                    "\"Dalam rangka meningkatkan mutu dan kualitas susu peternak, pemerintah terus berupaya meningkatkan kapasitas SDM peternak melalui bimbingan teknis dan pelatihan, serta melakukan pendampingan kepada peternak seperti untuk penerapan Good Farming Practices (GFP),\"ucapnya.\n" +
                    " \n" +
                    "Kementan juga berupaya meningkatkan nilai tambah dan daya saing produk peternak melalui diversifikasi produk, fasilitasi sarana prasarana pengolahan susu, pengurusan ijin edar produk susu serta fasilitasi/pendampingan sertifikasi organik untuk kelompok peternak, serta fasilitasi pemasaran melalui akses market online bekerjasama dengan marketplace. \n" +
                    "\n" +
                    "\"Untuk peningkatan konsumsi susu, pemerintah terus berupaya mendorong meningkatkan kesadaran masyarakat untuk mengkonsumsi susu melalui sosialisasi dan promosi, baik melalui media sosial maupun sarana promosi,\"ucap Ketut.\n" +
                    "\n" +
                    "Dalam mendorong pengembangan usaha peternak/pelaku usaha melalui pengurangan pajak penghasilan atau tax allowance, akses pembiayaan/kredit (Kredit Usaha Rakyat (KUR), Program Kemitraan dan Bina Lingkungan (PKBL) dan Badan Usaha Milik Negara/BUMN), asuransi peternak (misal: Asuransi Usaha Ternak Sapi/Kerbau/AUTS) serta mendorong kemitraan dengan industri. \n" +
                    "\n" +
                    "Berbagai kebijakan dan program yang telah lakukan tentu saja tidak akan berhasil tanpa dukungan dari semua stake holder dan masyarakat Indonesia. Oleh karena itu, melalui momentum Peringatan Hari Susu Nusantara ini kami berharap peran serta semua stakeholder.\n" +
                    "\n" +
                    "\"Baik Kementerian/Lembaga, pemerintah daerah, akademisi, industri, koperasi dan seluruh peternak sapi perah di Indonesia untuk terus bersama-sama bergandengan tangan menuju agroindustri persusuan yang tangguh dan mandiri untuk meningkatkan kualitas Sumber Daya Manusia Indonesia seutuhnya, ” tutup Ketut.\n" +
                    "\n" +
                    " \n" +
                    "\n" +
                    "Narahubung:\n" +
                    "Ir. Fini Murfiani, M.Si\n" +
                    "Direktur Pengolahan dan Pemasaran Hasil Peternakan\n" +
                    "Ditjen PKH, Kementan RI\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 3 Juni: Hari Pasar Modal Indonesia")){
            infoBulan.setText("-");
        }else if(tanggal.equalsIgnoreCase("Tanggal 5 Juni: Hari Lingkungan Hidup Sedunia")){
            infoBulan.setText("KOMPAS.com - Hari Lingkungan Hidup Sedunia atau World Environmental Day diperingati pada hari ini, Jumat (5/6/2020). Setiap tahunnya, Hari Lingkungan Hidup Sedunia selalu diperingati pada 5 Juni, sejak pertama kali Majelis Umum PBB menetapkannya pada 1974. Melansir India Today, Kamis (4/6/2020), peringatan Hari Lingkungan Hidup Sedunia berawal dari konferensi besar pertama tentang isu-isu lingkungan yang diadakan pada 5-16 Juni 1972 di Stockholm, Swedia. Akhirnya, pada 15 Desember 1972, Majelis Umum PBB membuat resolusi yang menetapkan 5 Juni sebagai Hari Lingkungan Hidup Sedunia. Sejak 1974, Hari Lingkungan Hidup Sedunia dirayakan setiap tahun dengan melibatkan pemerintah, pebisnis, selebriti, dan masyarakat.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"5 Juni Hari Lingkungan Hidup Sedunia, Mari Memahami Pentingnya Keanekaragaman Hayati...\", https://www.kompas.com/tren/read/2020/06/05/124358465/5-juni-hari-lingkungan-hidup-sedunia-mari-memahami-pentingnya.\n" +
                    "Penulis : Nur Fitriatus Shalihah\n" +
                    "Editor : Inggried Dwi Wedhaswary");
        }else if(tanggal.equalsIgnoreCase("Tanggal 8 Juni: Hari Laut Sedunia")){
            infoBulan.setText("Liputan6.com, Jakarta - Tahukah Anda, lautan menggerakkan sistem global yang membuat Bumi layak huni bagi umat manusia. Mulai dari suhu, zat kimia yang terkandung di dalamnya, arus laut, dan kehidupan di dalam serta sekitarnya.\n" +
                    "\n" +
                    "Air hujan, air minum, iklim, cuaca, garis pantai, dan sebagian besar makanan kita hingga oksigen yang dihirup oleh manusia berasal dari laut. Tak hanya itu, sepanjang sejarah, lautan dan laut juga menjadi tempat penting bagi manusia melakukan pedagangan dan transportasi. \n" +
                    "\n" +
                    "Baca Juga\n" +
                    "\n" +
                    "    China Janji Akan Jadikan Vaksin COVID-19 Buatannya Sebagai Barang Publik\n" +
                    "\n" +
                    "Manajemen yang cermat terhadap sumber daya global yang penting ini adalah fitur kunci dari masa depan yang berkelanjutan. Kendati demikian, saat ini masih banyak pesisir pantai yang tercemar akibat polusi dan pengasaman laut, sehingga memberikan dampak buruk pada ekosistem dan keanekaragaman hayati.\n" +
                    "\n" +
                    "Oleh sebab itu, kawasan lindung laut perlu dikelola secara efektif dan memiliki sumber daya yang baik serta perlu ada peraturan untuk mengurangi penangkapan ikan yang berlebihan, pencemaran, dan pengasaman laut.\n" +
                    "\n" +
                    "Melalui resolusi 63/111 tertanggal 5 Desember 2008, Majelis Umum PBB menetapkan 8 Juni sebagai World Oceans Day atau Hari Laut Sedunia. Seperti dikutip dari situs UN, Senin (8/6/2020).\n" +
                    "\n" +
                    "Peringatannya dimulai setahun setelahnya pada 8 Juni 2009.\n" +
                    "\n" +
                    "Berawal pada 1992\n" +
                    "\n" +
                    "Konsep Hari Laut Sedunia ini pertama kali diajukan pada tahun 1992, dalam sebuah forum global pada event paralel United Nations Conference on Environment and Development (UNCED) atau KTT Bumi, di Rio de Janeiro. Sejak itu, sejumlah negara mulai memperingatinya, namun PBB baru meresmikannya pada 8 Juni 2008 untuk diperingati secara sah setahun setelahnya. \n" +
                    "\n" +
                    "Peringatan ini sejatinya digagas untuk meningkatkan kesadaran global akan manfaat yang diperoleh manusia dari lautan dan tugas individu serta kolektif untuk menggunakan sumber dayanya secara berkelanjutan. Sebab generasi mendatang juga akan bergantung pada lautan untuk mata pencaharian mereka.\n" +
                    "\n" +
                    "Divisi PBB untuk Urusan Kelautan dan Hukum Laut pun secara aktif mengoordinasikan berbagai kegiatan untuk Hari Laut Sedunia.\n" +
                    "\n" +
                    "Intergovernmental Oceanographic Commission (IOC) atau Komisi Oseanografi Antar Pemerintah UNESCO mensponsori World Ocean Network, yang sejak 2002 berperan penting dalam membangun dukungan untuk acara-acara kesadaran laut pada 8 Juni.\n" +
                    "\n" +
                    "Bersama dengan UNESCO, badan-badan PBB lainnya mereka bekerja untuk melindungi ekosistem laut dan pesisir untuk menghindari dampak negatif yang signifikan.\n" +
                    "\n" +
                    "United Nations Environment Programme (UNEP) (Program Lingkungan Perserikatan Bangsa-Bangsa)  secara khusus menangani masalah alam secara global. Food and Agriculture Organization (FAO), memperkuat kapasitas manajerial dan teknis anggota untuk meningkatkan konservasi dan pemanfaatan sumber daya air.\n" +
                    "\n" +
                    "Sementara United Nations Development Programme (UNDP) mengelola keanekaragaman hayati dan pengembangan manusia. Lalu International Maritime Organization (Organisasi Maritim Internasional) bertanggung jawab atas keselamatan dan keamanan pengiriman dan pencegahan polusi laut dan atmosfer oleh kapal.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 10 Juni: Hari Media Sosial")){
            infoBulan.setText("GenPI.co - Hari ini, Rabu bertepatan dengan Hari Media Sosial. \n" +
                    "\n" +
                    "Dilansir dari laman harimediasosial, dikemukakan Hari Media Sosial adalah hari berbagi hal-hal positif, pesan-pesan kebaikan dan inspirasi bersama teman-teman, keluarga dan pelanggan.\n" +
                    "\n" +
                    "Setiap tanggal 10 Juni, agar dapat menyampaikan berbagai inspirasi dan hal positif di media sosial yang telah memberikan perubahan pada kehidupan mereka.\n" +
                    "\n" +
                    "BACA JUGA: Bursa 10 Juni 2020: Saham AALI dan UNVR Direkomendasi\n" +
                    "\n" +
                    "Diketahui Media sosial kini menjadi kebutuhan, sejalan dengan kemajuan teknologi dan Internet.\n" +
                    "ADVERTISEMENT\n" +
                    "\n" +
                    "Adapun Hari Media Sosial yang digagas oleh marketer Handi Irawan D dirayakan seriap tanggal 10 Juni. Diperingati sejak 10 Juni 2015. Sementara itu, Hari Media Sosial Internasional diperingati pada 30 Juni.\n" +
                    "\n" +
                    "Handi Irawan D adalah pakar pemasaran di bawah payung Frontier Consulting Group. \n" +
                    "\n" +
                    "Dicetuskannya Hari Media Sosial,  agar masyarakat Indonesia mengkatkan kesadaran dalam beretika saat menggunakan media sosial (medsos). Hari Media Sosial diperingati setiap 10 Juni (foto: Pixabay)\n" +
                    "\n" +
                    "Dengan begitu,  diharapkan positif bagi banyak pihak, termasuk kalangan pebisnis.\n" +
                    "\n" +
                    "BACA JUGA: Mau Buat Sarapan Bubur Ayam Kuah Kuning? Bunda Coba Resep Ini Ya\n" +
                    "\n" +
                    "Untuk mengingatkan tujuan tersebut, di Hari Media Sosial ini kamu bisa mengunggah kata-kata bijak sekaligus melakukan update status media sosial, berikut pilihannya.\n" +
                    "\n" +
                    "1. Setiap ungkapan yang kita bagikan dapat menjadi berkat melalui apa yang kita share.Selamat Hari Media Sosial.\n" +
                    "\n" +
                    "2. Selamat Hari Media Sosial! Yuk, berikan manfaat positif dalam menggunakan media sosial.\n" +
                    "ADVERTISEMENT\n" +
                    "\n" +
                    "3. Mari meningkatkan kesadaran dan etika dalam menggunakan media sosial. Selamat Hari Media Sosial\n" +
                    "\n" +
                    "4. Jangan lupa gunakan media sosial kamu dengan bijak. Selamat Hari Media Sosial. (*) ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 15 Juni: Hari Demam Berdarah Dengue ASEAN[23]")){
            infoBulan.setText("\n" +
                    "\n" +
                    "ASEAN merupakan organisasi yang menjadi pelopor ditetapkannya Hari Demam Berdarah Dengue. Hari Deman Berdarah Dengue ASEAN resmi diperingati sejak tanggal 15 Juni 2010. Di ASEAN, Indonesia merupakan negara dengan jumlah penderita demam berdarah terbanyak.\n" +
                    "\n" +
                    "Adanya Hari Demam Berdarah Dengue ASEAN memiliki tujuan untuk meningkatkan kesadaran masyarakat akan bahaya dari penyakit demam berdarah dengue secara berkelanjutan. Tahun ini, Hari Demam Berdarah Dengue ASEAN dirayakan di Kamboja dan mengusung tema “United Fight against Dengue”.\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 17 Juni: Hari Dermaga")){
            infoBulan.setText("-");
        }else if(tanggal.equalsIgnoreCase("Tanggal 21 Juni: Hari Krida Pertanian")){
            infoBulan.setText("-");
        }else if(tanggal.equalsIgnoreCase("Tanggal 22 Juni: Hari Ulang Tahun Kota Jakarta (sejak tahun 1527)")){
            infoBulan.setText("-");
        }else if(tanggal.equalsIgnoreCase("Tanggal 24 Juni: Hari Bidan Nasional")){
            infoBulan.setText("-");
        }
    }
}
