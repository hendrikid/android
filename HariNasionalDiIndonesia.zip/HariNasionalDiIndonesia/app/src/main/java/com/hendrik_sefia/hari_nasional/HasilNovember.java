package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilNovember extends AppCompatActivity {
    String NOVEMBER;
    TextView infoBulan;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_november);
        // ambil textview info di acivity
        infoBulan=(TextView) findViewById(R.id.info_november);

        // ambil parameter
        Intent intent = getIntent();
        NOVEMBER = intent.getStringExtra("november");

        // panggil
        setNOVEMBER(NOVEMBER);
    }
    private void setNOVEMBER(String tanggal) {
        if(tanggal.equalsIgnoreCase("Tanggal 1 November: Hari Inovasi Indonesia")){
            infoBulan.setText("Dilansir dari hari-inovasi.com, Sebuah hari yang mengingatkan individu, pelaku bisnis dan perusahaan di Indonesia untuk menciptakan budaya inovatif, untuk terciptanya produk dan layanan inovatif untuk kehidupan yang lebih baik bagi masyarakat Indonesia.\n" +
                    "\n" +
                    "Budaya inovatif inilah yang perlu ditumbuhkan oleh para leader dan pelaku bisnis. Ini sebuah pekerjaan yang membutuhkan komitmen yang tinggi. Para leader perlu mendorong setiap individu untuk memproduksi gagasan dan ide yanginovatif dan memberikan arah bagaimana gagasan dan ide yang inovatif bisa diimplementasikan.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 5 November: Hari Cinta Puspa dan Satwa Nasional[41]")){
            infoBulan.setText("Diperingati mulai tahun 1993, Hari Cinta Puspa dan Satwa Nasional mempunyai tujuan untuk meningkatkan kepedulian serta perlindungan, pelestarian puspa dan satwa Indonesia.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 10 November: Hari Ganefo")){
            infoBulan.setText("Hari Ganefo\n" +
                    "\n" +
                    "Hallo Sobat100,\n" +
                    "\n" +
                    "Tanggal 10 November 2018 diperingati sebagai Hari GANEFO.\n" +
                    "Sobat100 pasti merasa asing dengan kata GANEFO, GANEFO merupakan sebuah singkatan dari Games of the New Emerging Forces atau Pesta Olahraga Negara-Negara Berkembang.\n" +
                    "\n" +
                    "Bagaimana awal mulanya terbentuknya GANEFO? Mengapa sekarang GANEFO sudah tidak dilaksanakan? Kenapa GANEFO dibubarkan? Berikut sejarah GANEFO untuk sobat100..\n" +
                    "Asal Mula Dibentuk GANEFO\n" +
                    "\n" +
                    "Presiden pertama Republik Indonesia, Soekarno, punya mimpi besar untuk meninggikan martabat Merah Putih di kancah internasional melalui olahraga. Maka tercetuslah sebuah ide brilian dengan menjadi tuan rumah pesta akbar olahraga se-Asia atau lebih dikenal Asian Games. Sayang, kemegahan arena olahraga Istora Senayan saat menggelar Asian Games IV pada 1962, sedikit tercoreng. Penolakkan Indonesia untuk mengundang Israel dan Taiwan ternyata berbuntut panjang.\n" +
                    "\n" +
                    "Saat itu, Indonesia yang menganut politik Nasakom (Nasionalisme, Agama, dan Komunisme), turut berpengaruh dalam kebijakan politik luar negeri. Terhadap Israel, Indonesia menolak kolonialisme di tanah Palestina, sedangkan Taiwan, Soekarno memiliki hubungan dekat dengan China yang berhaluan komunis.\n" +
                    "Akibatnya, setelah Israel dan Taiwan ditolak keikutsertaannya dalam Asian Games 1962. Komite Olimpiade Internasional (IOC) mengambil langkah tegas karena dalam hal ini IOC menegaskan bahwa olahraga harus dipisahkan dari politik.[1]\n" +
                    "\n" +
                    "Indonesia pun dihukum. Akhirnya IOC menangguhkan keanggotaan Indonesia, dan Indonesia diskors untuk mengikuti Olimpiade 1964 di Tokyo. Namun, Indonesia adalah bangsa besar dengan pemimpin yang luar biasa pada saat itu. Tanpa rasa takut serta otak brilian, Soekarno memutuskan Indonesia keluar dari IOC, karena menurutnya IOC adalah perpanjangan tangan dari kepentingan neo-kolonialisme dan imperialisme. Tidak tinggal diam, setelah itu Indonesia pun mengajak 12 negara sahabat untuk merumuskan pembentukan Pesta Olahraga Negara-Negara Berkembang atau Games of the New Emerging Forces (GANEFO).[2]");
        }else if(tanggal.equalsIgnoreCase("Tanggal 10 November: Hari Pahlawan (Indonesia)")){
            infoBulan.setText("Pertempuran Surabaya merupakan peristiwa sejarah perang antara pihak tentara Indonesia dan pasukan Britania Raya. Peristiwa besar ini terjadi pada tanggal 10 November 1945 di Kota Surabaya, Jawa Timur.\n" +
                    "\n" +
                    "Pertempuran ini adalah perang pertama pasukan Indonesia dengan pasukan asing setelah Proklamasi Kemerdekaan Indonesia dan satu pertempuran terbesar dan terberat dalam sejarah Revolusi Nasional Indonesia yang menjadi simbol nasional atas perlawanan Indonesia terhadap kolonialisme.\n" +
                    "\n" +
                    "Sehingga di hari tersebut diperingati sebagai Hari Pahlawan.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 11 November: Hari Bangunan Indonesia[42]")){
            infoBulan.setText("Dikutip Kompas.com, Pemilihan 11 November sebagai Hari Bangunan Indonesia lantaran memiliki angka satu laiknya pilar-pilar penopang kokohnya sebuah bangunan. Selain itu, peringatan tersebut juga bisa dijadikan sebagai momentum evaluasi pembangunan di Indonesia karena berada di akhir tahun.\n" +
                    "\n" +
                    "Hari bangunan mulai diperingati mulai 11 Nopember 2014.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 November: Hari Ayah Nasional")){
            infoBulan.setText("Hari Ayah adalah hari untuk menghormati ayah.\n" +
                    "\n" +
                    "Di Indonesia sendiri Hari Ayah dirayakan pada tanggal 12 November.\n" +
                    "\n" +
                    "Hari Ayah pertama kali dideklarasikan di Solo pada tahun 2006, di masa pemerintahan Susilo Bambang Yudhoyono.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 November: Hari Kesehatan Nasional")){
            infoBulan.setText("Perayaan Hari Kesehatan Nasional pada 12 November pertama kali diperingati di tahun 1959. Saat itu dilakukan penyemprotan nyamuk Malaria secara simbolis oleh Presiden Soekarno.\n" +
                    "\n" +
                    "Usai penyemprotan secara simbolis dilakukan, penyuluhan pun diberikan dengan tujuan memberikan pemahaman kepada masyarakat akan bahaya penyakit Malaria dan agar mereka lebih waspada terhadapnya. Di tahun-tahun berikutnya, Hari Kesehatan Nasional (HKN) terus diperingati dengan tujuan memberikan pendidikan dan penyuluhan kesehatan untuk masyarakat Indonesia.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 14 November: Hari Brigade Mobil (BRIMOB)")){
            infoBulan.setText("Brimob terbentuk dengan nama Tokubetsu Keisatsutai atau Pasukan Polisi Istimewa.\n" +
                    "\n" +
                    "Kesatuan ini pada mulanya diberikan tugas untuk melucuti senjata tentara Jepang, melindungi kepala negara, dan mempertahankan ibukota.\n" +
                    "\n" +
                    "Brimob turut berjuang dalam pertempuran 10 November 1945 di Surabaya.\n" +
                    "\n" +
                    "Pada 14 November 1946 membentuk Mobile Brigade (Mobrig) atau Brigade Mobil (Brimob) sebagai ganti Pasukan Polisi Istimewa.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 14 November: Hari Diabetes internasional")){
            infoBulan.setText("Hari Diabetes Sedunia adalah sebuah kampanye kesadaran diabetes terbesar di dunia yang menjangkau khalayak global .\n" +
                    "\n" +
                    "Bahkan lebih dari 1 miliar orang di lebih dari 160 negara. Pada tahun 1991, IDF dan Organisasi Kesehatan Dunia menciptakan hari diabetes sedunia sebagai tanggapan atas meningkatnya kekhawatiran tentang meningkatnya ancaman kesehatan yang ditimbulkan oleh diabetes.\n" +
                    "\n" +
                    "Hari diabetes sedunia menjadi hari Perserikatan Bangsa-Bangsa yang diresmikan di tahun 2006 dengan berlakunya United Nation Resolution 61/225.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 16 November: Hari Toleransi Internasional")){
            infoBulan.setText("KOMPAS.com - Hari ini, Sabtu (16/11/2019), merupakan peringatan Hari Toleransi Internasional. Hari Toleransi Internasional diperingati setiap tahun pada 16 November. Peringatan ini dilakukan satu tahun sekali dan dideklarasikan pertama kali oleh The United Nations Educational, Scientific and Cultural Organization (UNESCO). Melansir laman United Nations, Hari Toleransi Internasional diperingati untuk meningkatkan kesadaran tentang prinsip-prinsip toleransi. Selain itu, untuk menghormati budaya, kepercayaan-kepercayaan, tradisi-tradisi, dan memahami risiko-risiko yang disebabkan oleh intoleransi.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"16 November Hari Toleransi Internasional, Bagaimana Sejarahnya?\", https://www.kompas.com/tren/read/2019/11/16/144348365/16-november-hari-toleransi-internasional-bagaimana-sejarahnya.\n" +
                    "Penulis : Vina Fadhrotul Mukaromah\n" +
                    "Editor : Inggried Dwi Wedhaswary");
        }else if(tanggal.equalsIgnoreCase("Tanggal 19 November: Hari Pria/Laki-laki Internasional")){
            infoBulan.setText("Hari Pria Internasional adalah peristiwa tahunan yang dirayakan setiap 19 November. Diresmikan pada 1999 di Trinidad dan Tobago, hari dan kegiatan tersebut mendapatkan dukungan dari berbagai kalangan di Australia, Karibia, Amerika Utara, Asia, Eropa dan Afrika.[1][2]\n" +
                    "\n" +
                    "Berbicara atas nama UNESCO, Direktur Perempuan dan Budaya Perdamaian Ingeborg Breines berkata, \"Ini adalah ide yang sangat baik dan akan memberikan beberapa kesetaraan jender.\" Dia menambahkan bahwa UNESCO menantikan untuk bekerja sama dengan penyelenggara.[1][2]\n" +
                    "\n" +
                    "Tujuan merayakan Hari Pria Internasional adalah untuk meningkatkan kesadaran akan pentingnya kesehatan pemuda dan pria, mengembangkan hubungan antarjender, men's and boys' health, improving gender relations, mendorong kesetaraan jender, dan menyoroti teladan lelaki.[2][3][4][5] It is an occasion to highlight discrimination against men and boys and to celebrate their achievements and contributions, in particular for their contributions to community, family, marriage, and child care.[3][6][7] The broader and ultimate aim of the event is to promote basic humanitarian values.[8][9]\n" +
                    "\n" +
                    "Hari Pria Internasional dirayakan di lebih dari 60 negara,[10] yaitu Trinidad dan Tobago, Jamaika, Australia, Argentina, India, Republik Rakyat Tiongkok, Amerika Serikat, Rumania, Singapura, Malta, Britania Raya, Afrika Selatan, Tanzania, Zimbabwe, Botswana, Seychelles, Burundi, Hungaria, Irlandia, Isle of Man, Ghana, Canada, Denmark, Norwegia, Austria, Bosnia dan Herzegovina, Ukraina, Prancis, Italia, Pakistan, Grenada, Kuba, Antigua dan Barbuda, St. Lucia, St. Kitts dan Nevis dan Kepulauan Cayman, pada 19 November, dan mendapatkan dukungan secara luas.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 21 November: Hari Pohon")){
            infoBulan.setText("Hari Pohon Sedunia diperingati pada tanggal 21 November.\n" +
                    "\n" +
                    "Mengapa Tanggal 21 November? Karena dipilih untuk menghormati jasa-jasa dari J. Sterling Morton pada 1872, ia merupakan seorang pecinta alam yang berasal dari Amerika. Ia juga gigih dalam mengkampanyekan gerakan menanam pohon.\n" +
                    "\n" +
                    "Tujuan hari pohon yaitu untuk meningkatkan manusia akan pentingnya pohon bagi kehidupan makhluk hidup lainnya, untuk mengurangi pemanasan global, mencegah banjir, tanah longsor, tempat hidup fauna dan membuat iklim mikro yang baik.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 22 November: Hari Perhubungan Darat")){
            infoBulan.setText("-");
        }else if(tanggal.equalsIgnoreCase("Tanggal 25 November: Hari Guru[44]")){
            infoBulan.setText("Hari Guru Nasional diperingati bersamaan dengan perayaan ulang tahun Persatuan Guru Republik Indonesia (PGRI). Ini bermula dengan perjuangan para guru Tanah Air melalui Persatuan Guru Hindia Belanda (PGHB) pada 1912.\n" +
                    "\n" +
                    "Semangat proklamasi 17 Agustus 1945 penyelenggaraan Kongres Guru Indonesia pada tanggal 24-25 November 1945 di Surakarta.\n" +
                    "\n" +
                    "Di dalam kongres ini, 25 November 1945, seratus hari setelah proklamasi kemerdekaan Republik Indonesia, Persatuan Guru Republik Indonesia (PGRI) didirikan.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 November: Hari Menanam Pohon Indonesia[45]")){
            infoBulan.setText("Pada tanggal 28 November ditetapkan sebagai Hari Menanam Pohon Indonesia sesuai dengan keputusan Presiden RI Nomor 24 Tahun 2008.\n" +
                    "\n" +
                    "Berdasarkan hasil atau prestasi yang telah dicapai oleh masyarakat Indonesia dalam menanam pohon melalui Aksi Penanaman Serentak dan Gerakan Perempuan Tanam Pohon sejak tahun 2007 lalu.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 November: Hari Dongeng Nasional")){
            infoBulan.setText(
                    "28 November 2015 Resmi Jadi Hari Dongeng Nasional\n" +
                    "Andreas Gerry TuwoAndreas Gerry Tuwo\n" +
                    "\n" +
                    "28 Nov 2015, 11:27 WIB\n" +
                    "\n" +
                    "117\n" +
                    "28 November 2015 Resmi Jadi Hari Dongeng Nasional\n" +
                    "Tanggal ini dipilih sebagai Hari Dongeng karena merupakan hari kelahiran Drs Suyadi atau yang lebih dikenal dengan nama Pak Raden.\n" +
                    "\n" +
                    "Liputan6.com, Jakarta - Sejumlah pendongeng dan perwakilan Kementerian Pendidikan dan Kebudayaan (Kemendikbud) mendeklarasikan 28 November 2015 sebagai Hari Dongeng Nasional.\n" +
                    "\n" +
                    "Tanggal ini dipilih karena merupakan hari kelahiran Drs Suyadi atau yang lebih dikenal dengan nama Pak Raden.\n" +
                    "\n" +
                    "Pria yang wafat pada 30 Oktober 2015 itu merupakan salah satu pendongeng paling tersohor di Tanah Air.\n" +
                    "\n" +
                    "Deklarasi Hari Dongeng Nasional dilakukan pada Sabtu (28/11/2015) di lantai 2 perpustakaan Kementerian Pendidikan dan Kebudayaan.\n" +
                    "\n" +
                    "Baca Juga\n" +
                    "\n" +
                    "    Datangi Kantor Jokowi, Siapakah Capres Pilihan Pak Raden?\n" +
                    "    Bantu Pengobatan, Prabowo Beli Lukisan Pak Raden Rp 50 Juta\n" +
                    "\n" +
                    "Tidak cuma di Jakarta, deklarasi ini juga dilakukan di Indonesia. Beberapa kota lain itu seperti Bogor, Lampung, Ponorogo, NTB, Bandung, Makasar, Saparua, Banjarmasin, Pinrang, dan Surabaya.\n" +
                    "\n" +
                    "Deklarasi tersebut dibacakan oleh beberapa pendongeng Indonesia secara serempak pada pukul 10.00 di seluruh Tanah Air.\n" +
                    "\n" +
                    "Berikut teks deklarasi Hari Dongeng Nasional yang dibacakan para pendongeng Indonesia:\n" +
                    "\n" +
                    "Deklarasi Forum Dongeng Nasional\n" +
                    "Dengan menyebut nama Allah Tuhan yang Maha Esa\n" +
                    "\n" +
                    "Kami para pencita dongeng Indonesia\n" +
                    "Kami para pendidik, pustawakan, dan pemerhati anak, pada hari ini Sabtu 28 November 2015 pukul 10.00 WIB menyatakan perihal utama,\n" +
                    "\n" +
                    "Demi kepentingan anak Indonesia dan keguyuban para pecinta dongeng, bahwa setiap tanggal 28 November dalam setiap tahun secara bersama di Indonesia merupakan sukacita cerita\n" +
                    "\n" +
                    "Kami para pencinta dongeng Indonesia menjadikan tanggal 28 November sebagai Hari Dongeng Nasional.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 29 November: Hari Korps Pegawai Republik Indonesia (KORPRI)")){
            infoBulan.setText("Korps Pegawai Republik Indonesia (KORPRI) adalah organisasi di Indonesia yang anggotanya terdiri dari Pegawai Negeri Sipil (PNS), pegawai Badan Usaha Mandiri Negara (BUMN), Badan Usaha Mandiri Daerah (BUMD) serta anak perusahaan dan perangkat Pemerintah Desa. Korpri didirikan pada tanggal 29 November 1971 berdasarkan Keputusan Presiden Nomor 82 tahun 1971, yang merupakan wadah untuk menghimpun seluruh pegawai Republik Indonesia.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunpontianak.co.id dengan judul Hari-Hari Penting di Bulan November Yang Banyak Orang Belum Tau, https://pontianak.tribunnews.com/2017/11/01/hari-hari-penting-di-bulan-november-yang-banyak-orang-belum-tau?page=all.\n" +
                    "Penulis: Galih Nofrio Nanda\n" +
                    "Editor: Galih Nofrio Nanda ");
        }
    }
}
