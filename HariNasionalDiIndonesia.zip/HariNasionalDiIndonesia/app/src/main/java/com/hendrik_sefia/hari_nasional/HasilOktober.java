package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilOktober extends AppCompatActivity {
    String OKTOBER;
    TextView infoBulan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_oktober);
        // ambil textview info di acivity
        infoBulan=(TextView) findViewById(R.id.info_oktober);

        // ambil parameter
        Intent intent = getIntent();
        OKTOBER = intent.getStringExtra("oktober");

        // panggil
        setOKTOBER(OKTOBER);
    }
    private void setOKTOBER(String tanggal) {
        if(tanggal.equalsIgnoreCase("Tanggal (Setiap Hari Senin Pertama Oktober): Hari Habitat")){
            infoBulan.setText("\n" +
                    "hari_habitat\n" +
                    "#Maritim #Kemaritiman #PorosMaritimDunia #SahabatMaritim \n" +
                    "Facebook\n" +
                    "Twitter\n" +
                    "WhatsApp\n" +
                    "Telegram\n" +
                    "Sambung\n" +
                    "Perserikatan Bangsa-Bangsa menetapkan hari Senin pertama bulan Oktober setiap tahun sebagai Hari Habitat Dunia. Peringatan Hari Habitat Dunia bertujuan untuk merefleksikan keadaan kota-kota dan pemenuhan hak dasar untuk tempat tinggal yang layak. Peringatan ini menjadi refleksi bagi kita semua bahwa kita memiliki kemampuan dan tanggung jawab bersama atas masa depan kota dan tempat tinggal kita.\n" +
                    "Salah satu masalah utama perkotaan adalah masalah sampah. Jumlah limbah yang dihasilkan oleh individu bertambah setiap hari dan sering kali membebani pemerintah terkait regulasi, anggaran pengelolaan hingga keharusan untuk melakukan edukasi pada masyarakat agar tidak membuang sampah sembarangan. Diketahui, pengumpulan dan pembuangan limbah padat yang buruk dapat menyebabkan polusi udara dan air  serta masalah kesehatan yang serius .\n" +
                    "Pengelolaan limbah padat dan masalah sampah kota telah menjadi perhatian dunia. Terkait masalah sampah laut, ternyata riset menyatakan bahwa 80% sampah laut (marine debris) berasal dari darat. Maka perbaikan infrastruktur pengelolaan sampah darat baik dari sektor domestik maupun industri  menjadi keharusan.\n" +
                    "Masalah sampah juga tercantum dalam SDGs. Diketahui, Tujuan Pembangunan Berkelanjutan (Sustainable Development Goals/ SDGs) dan Persetujuan Paris COP 21 juga membahas salah satu masalah utama perkotaan, yakni: pengelolaan limbah padat. Sebagaimana disebutkan dalam Target dari SDG11.6  : mengurangi dampak lingkungan per kapita yang merugikan kota, termasuk dengan memberi perhatian khusus pada kualitas udara dan manajemen limbah kota dan pada butir SDG 12 tentang pengelolaan limbah yang ramah lingkungan serta manajemen limbah melalui pencegahan, pengurangan, daur ulang, penggunaan kembali/guna ulang dan pengurangan limbah makanan dengan dikonversi menjadi pupuk/kompos.\n" +
                    "Gerakan Indonesia Bersih\n" +
                    "Tema Hari Habitat Dunia tahun ini adalah Pengelolaan Limbah Padat  (Solid waste management). Kalau Kenya, Afrika terpilih sebagai lokasi puncak peringatan global Hari Habitat Dunia. Sementara ibukota Sulawesi Tengah, kota Palu terpilih menjadi lokasi puncak peringatan Hari Habitat Dunia untuk Indonesia dengan rangkaian kegiatan bertema; Gerakan Indonesia Bersih dengan Kementerian Koordinator Bidang Kemaritiman sebagai koordinator nasional serta didukung oleh Kementerian Pekerjaan Umum dan Perumahan Rakyat (KemenPUPR), Pemerintah Provinsi Sulawesi Tengah dan Pemerintah Kota Palu serta berbagai kementerian dan lembaga terkait.\n" +
                    "Gerakan Indonesia Bersih mengajak berbagai unsur masyarakat melakukan aksi bersih serentak di 34 propinsi pada tanggal 28 September hingga 03 Oktober 2018. Aksi Bersih meliputi pembersihan jalan, pasar, terminal, perkantoran, sekolah, perumahan hingga fasilitas umum, serta pembersihan pantai, juga sungai dan bantarannya.\n" +
                    "Sementara kota Palu yang didapuk sebagai lokasi puncak peringatan Hari Habitat Dunia di Indonesia juga menjadi percontohan penerapan pengelolaan tempat pembuangan akhir dan tempat pembuangan sementara untuk daerah perkotaan.\n" +
                    "Rapat persiapan peringatan Hari Habitat dan Gerakan Indonesia Bersih telah berlangsung di Kota Palu, Sabtu (15 September 2018). Rapat dipimpin oleh Wakil Walikota Palu Sigit Purnomo Said dengan dihadiri oleh perwakilan Kemenko Kemaritiman, KemenPUPR, Kementerian Pariwisata, Kementerian ESDM dan Satuan Kerja Perangkat Daerah (SKPD).\n" +
                    "Sesditjen Cipta Karya Rina Agustin menekankan bahwa semua aksi bersih harus dikoordinasikan dengan angkutan sampah dan lokasi TPA agar tidak terjadi penumpukan sampah pada lokasi-lokasi penampungan sementara. “Karena kita menginginkan aksi bersih ini sebagai rangkaian pengelolaan sampah terpadu. Dari angkutan sampahnya sampai tempat pembuangan akhirnya harus terkoneksi. Manajemen dan infrastruktur TPA harus sesuai dengan kebutuhan dan berkelanjutan”. Sesditjen Rina mengapresiasi pemerintah kota Palu yang telah melakukan penutupan sampah, “Sampah di TPA harus ditutup sebelum 5 hari agar lalat tidak sempat menetaskan larva. Dengan penutupan ini lalat dan bau tidak akan ada. Penutupan sampahnya bisa dengan tanah atau dengan geomembrane. Gas methane yang dihasilkan bisa dikelola menjadi energi yang dapat dimanfaatkan untuk TPA tersebut” imbuhnya.\n" +
                    "Asisten Deputi Bidang Pendidikan Maritim Kemenko Maritim Tb.Haeru Rahayu dalam paparannya mengatakan bahwa membersihkan kota dan sungai bukanlah hal yang mustahil. Meskipun kelihatannya berat pada awalnya, bila dikerjakan dengan komitmen penuh, konsistensi dan bersama-sama, masalah sampah dapat diatasi. Asdep Tb.Haeru mencontohkan kegiatan aksi bersih Cilincing dan aksi bersih Citarum yang bersinergi dengan TNI, pemerintah daerah, kementerian/lembaga , mahasiswa dan berbagai komunitas telah memperlihatkan banyak perbaikan dalam waktu yang relatif singkat. Sementara Sekretaris Direktorat Jenderal Cipta Karya Kementerian Pekerjaan Umum dan Perumahan Rakyat Rina Agustin dalam rapat ini memaparkan rencana aksi Gerakan Indonesia Bersih yang meliputi gerakan bersih di Kawasan pemukiman, gerakan bersih di sarana dan prasarana publik, gerakan bersih di Kawasan pantai dan sungai, gerakan bersih di TPA, peremajaan angkutan sampah, pekan 3R (Reduce,Reuse,Recycle) dan produksi pupuk. Sementara, pelaksanaannya meliputi aksi serentak diseluruh Indonesia yang dikoordinasikan secara nasional oleh Kementerian Koordinator Bidang Kemaritiman didukung oleh kementerian/lembaga, TNI/Polri, BUMN, Pemda, pegiat lingkungan, komunitas dan masyarakat. Kegiatan berlangsung dimulai pada hari krida (Jumat 28 September 2018) dan acara puncak di Kota Palu pada tanggal 1 Oktober 2018 yang diharapkan dapat dihadiri oleh Presiden Joko Widodo.\n" +
                    "Kemenko Maritim juga memberikan dukungan dengan menyumbangkan incinerator buatan anak bangsa yang akan tiba di Palu pada tanggal 28 September mendatang. “Incinerator ini buatan anak bangsa. Buatan Cirebon, tepatnya” jelas Asdep TB.Haeru,”Produksi lokal yang dirancang agar dapat membakar sampah pada suhu tertentu, tanpa menimbulkan polusi udara. Kalau tidak salah sekitar 600°C. Nanti tim kami bersama teknisi akan datang lagi untuk membantu proses instalasinya”.\n" +
                    "Usai memimpin rapat,Wakil Walikota Palu Sigit Purnomo Said menyampaikan apresiasinya atas dipilihnya kota Palu sebagi lokasi puncak peringatan Hari Habitat, “Masalah sampah bukan cuma masalah kota Palu, melainkan masalah Indonesia serta masalah dunia. Dan salah satu cara untuk mengatasinya adalah kerja bersama. Baik dari pemerintah dan masyarakat juga dari regulasi, fasilitasi hingga edukasi warga. Kami berterimakasih, kota kami, dipilih sebagai lokasi peringatan Hari Habitat”, pungkasnya. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 1 Oktober: Hari Kesaktian Pancasila")){
            infoBulan.setText("Jakarta - Peringatan hari kesaktian Pancasila pada 1 Oktober tahun ini akan mengambil tema, \"Pancasila sebagai Dasar Penguatan Karakter Bangsa Menuju Indonesia Maju dan Bahagia\". Rangkaian kegiatan peringatan sudah dimulai hari ini Senin, 30 September 2019 dan akan berlangsung hingga esok.\n" +
                    "\n" +
                    "Penasaran seperti apa sih Hari Kesaktian Pancasila yang jatuh pada tanggal 1 Oktober? Yuk simak berikut ini beberapa fakta menarik mengenai Hari Kesaktian Pancasila.\n" +
                    "\n" +
                    "Baca juga:\n" +
                    "Seputar G30S/PKI, Peristiwa Penting dalam Sejarah Indonesia\n" +
                    "\n" +
                    "1. Sejarah Singkat Lahir dan Rumusan Pancasila\n" +
                    "\n" +
                    "Sejak tanggal 1 Maret 1945, pembentukan Badan Penyelidik Usaha Persiapan Kemerdekaan Indonesia sudah mengajukan pertanyaan penting tentang dasar Negara Indonesia. Hal tersebut memicu upaya untuk merumuskan Pancasila sebagai dasar negara resmi.\n" +
                    "\n" +
                    "Dimulai pada pidato tentang 'lima dasar' oleh Muhammad Yamin hingga pidato pada tanggal 1 Juni 1945 yang berisi tentang 'Lahirnya Pancasila yang dilakukan oleh Sukarno. Pada 22 Juni 1945 Pancasila kemudian disusun sehingga menjadi Piagam Jakarta pada 22 Juni 1945.\n" +
                    "\n" +
                    "2. Penghapusan 7 kata Piagam Jakarta\n" +
                    "\n" +
                    "Pada 18 Agustus 1945, sehari setelah kemerdekaan Indonesia diproklamasikan oleh Sukarno dan Hatta, Piagam Jakarta disahkan sebagai Pembukaan UUD 1945. Para pendiri bangsa kala itu menghapus 7 kata sila pertama dalam piagam Jakarta yakni: '... dengan kewajiban menjalankan syari'at Islam bagi pemeluk-pemeluknya'. Ketujuh kata itu mengikuti kata 'Ketuhanan'.\n" +
                    "\n" +
                    "3. Gerakan 30 September (G30S) PKI\n" +
                    "\n" +
                    "Hari Kesaktian Pancasila 1 Oktober 1965 faktanya erat berkaitan dengan peristiwa Gerakan 30 September 1965(G30S). Tragedi ini merupakan sebuah gerakan yang bertujuan untuk menggulingkan pemerintahan Presiden Sukarno dan mengubah Indonesia dari negara berdasarkan Pancasila menjadi negara komunis.\n" +
                    "\n" +
                    "Enam perwira tinggi dan satu perwira menengah TNI Angkatan Darat menjadi korban dalam Gerakan 30 September. Mereka adalah:\n" +
                    "\n" +
                    "- Letnan Jendral Anumerta Ahmad Yani\n" +
                    "\n" +
                    "- Mayor Jendral Raden Soeprapto\n" +
                    "\n" +
                    "- Mayor Jendral Mas Tirtodarmo Haryono\n" +
                    "\n" +
                    "- Mayor Jendral Siswondo Parman\n" +
                    "\n" +
                    "- Brigadir Jendral Donald Isaac Panjaitan\n" +
                    "\n" +
                    "- Brigadir Jendral Sutoyo Siswodiharjo\n" +
                    "\n" +
                    "- Lettu Pierre Andreas Tendean\n" +
                    "\n" +
                    "Pemerintah Orde Baru kemudian menetapkan 1 Oktober sebagai Hari Kesaktian Pancasila\n" +
                    "\n" +
                    "\n" +
                    "4. Penyelenggaraan upacara di berbagai Institusi Negara\n" +
                    "\n" +
                    "Penyelenggaraan upacara untuk memperingati Hari Kesaktian Pancasila 1 Oktober 2019 akan dilakukan di berbagai institusi negara, seperti\n" +
                    "\n" +
                    "-Kementerian-kementerian\n" +
                    "\n" +
                    "-Lembaga Tinggi Negara\n" +
                    "\n" +
                    "-Kejaksaan Agung\n" +
                    "\n" +
                    "-Lembaga Pemerintah Non Kementrian\n" +
                    "\n" +
                    "-Perwakilan Republik Indonesia di Luar Negeri\n" +
                    "\n" +
                    "-Kampus dan Sekolah (Negeri atau Swasta)\n" +
                    "\n" +
                    "\n" +
                    "5. Pengibaran Bendera\n" +
                    "\n" +
                    "Sebelum upacara resmi berlangsung, pada tanggal 30 September 2019 bendera berkibar setengah tiang. Hal tersebut dilakukan untuk mengenang gugurnya tujuh Pahlawan Revolusi.Sedangkan, tanggal 1 Oktober 2019 pukul 06.00 maka bendera berkibar satu tiang penuh.\n" +
                    "\n" +
                    "6. Makna 1 Oktober\n" +
                    "\n" +
                    "Hari Kesaktian Pancasila memiliki makna sebagai hari perkabungan nasional karena adanya tragedi penculikan dan pembunuhan tersebut. Tak hanya itu pasca tragedi itu, terjadi pembersihan semua unsur pemerintahan dari pengaruh PKI mulai dari angota organisasi hingga simpatisan.\n" +
                    "\n" +
                    "Pada akhir 1965, diperkirakan sekitar 500 ribu hingga 1 juta anggota atau pendukung PKI diduga menjadi korban pembunuhan.\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 2 Oktober: Hari Batik Nasional[31]")){
            infoBulan.setText("KOMPAS.com - Setiap tanggal 2 Oktober, Indonesia memperingati Hari Batik Nasional. Peringatan ini terjadi ketika batik memperoleh pengakuan dunia pada tahun 2009 dari United Nations Educational, Scientific, and Cultural Organization ( UNESCO). Organisasi ini menetapkan batik sebagai warisan budaya dunia tak benda atau intangible cultural heritage. Arsip pemberitaan Harian Kompas, 13 September 2009 menyebutkan, Batik Indonesia didaftarkan untuk mendapat status ICH melalui kantor UNESCO di Jakarta oleh kantor Menko Kesejahteraan Rakyat mewakili pemerintah dan komunitas batik Indonesia, pada 4 September 2008. Harian Kompas, 3 Oktober 2009 menyebutkan, dari 76 seni dan budaya warisan dunia yang diakui UNESCO saat itu, Indonesia hanya menyumbangkan satu. Adapun China ketika itu menyumbangkan 21 dan Jepang menyumbangkan 13 warisan. Menurut UNESCO, batik dinilai sebagai ikon budaya yang memiliki keunikan dan filosofi mendalam, serta mencakup siklus kehidupan manusia. Saat itu, setelah UNESCO resmi menetapkan batik sebagai warisan budaya dunia tak benda. Baca juga: Indahnya Batik yang Dibuat dari Daur Ulang Limbah Presiden SBY meminta seluruh masyarakat Indonesia pada tanggal 2 Oktober 2009 mengenakan batik. Sebelum batik, UNESCO telah menyatakan wayang dan keris sebagai warisan budaya dunia dari Indonesia. Sekilas tentang Batik Batik telah berkembang di berbagai daerah di Indonesia. Namun menurut maestro batik Iwan Tirta dalam bukunya A Play of Light and Shades, batik boleh jadi berkembang secara bersamaan di beberapa tempat di dunia. Di Indonesia sendiri, Iwan menyebut pada akhir abad ke-19 seorang akademisi bernama Rouffer melaporkan adanya motif batik sehalus gringsing diproduksi di Kediri pada abad ke-12. Corak batik tersebut menggambarkan sisik ikan. Ini artinya, kemungkinan besar, motif batik tersebut dibuat menggunakan canting. Artikel ini telah tayang di Kompas.com dengan judul \"Kisah di Balik Hari Batik Nasional\", https://www.kompas.com/tren/read/2019/10/02/053000865/kisah-di-balik-hari-batik-nasional. Penulis : Rosiana Haryanti Editor : Resa Eka Ayu Sartika\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Kisah di Balik Hari Batik Nasional\", https://www.kompas.com/tren/read/2019/10/02/053000865/kisah-di-balik-hari-batik-nasional.\n" +
                    "Penulis : Rosiana Haryanti\n" +
                    "Editor : Resa Eka Ayu SartikaKemudian dalam perkembangannya, batik berkaitan erat dengan kesenian lain yakni wayang, tarian, dan lagu. Oleh karenanya, batik memiliki ciri yang terkait dengan komunitas pembuatnya. Bahkan, sebagian cirinya menggambarkan suasana zaman dan alam sekitarnya. Batik pada perjalanannya kemudian diproduksi untuk keperluan komersial, meski sebagian lain ada juga yang menggunakan batik untuk melengkapi kebutuhan adat serta tradisi. Tetapi, ia berpendapat, batik Jawa menjadi sangat halus karena coraknya yang berkembang luas. Selain itu, batik Jawa juga memiliki keistimewaan lain yakni metode pewarnaannya yang maju, serta ada penyempurnaan dalam tekniknya. Iwan menyebut, cikal bakal batik bentuknya lebih sederhana. Adapun kain simbut dari Banten merupakan salah satu contoh batik paling awal yang pernah ada. Kain ini dibuat dengan menggunakan bubur nasi sebagai perintang warna\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Kisah di Balik Hari Batik Nasional\", https://www.kompas.com/tren/read/2019/10/02/053000865/kisah-di-balik-hari-batik-nasional?page=2.\n" +
                    "Penulis : Rosiana Haryanti\n" +
                    "Editor : Resa Eka Ayu Sartika");
        }else if(tanggal.equalsIgnoreCase("Tanggal 4 Oktober: Hari Hewan Sedunia [1]")){
            infoBulan.setText("Hari Binatang Sedunia diperingati setiap tanggal 4 Oktober. Peringatan ini dimulai di Florence, Italia tahun 1931 pada konvensi para ahli ekologi. Pada tanggal ini, kehidupan binatang di segala jenis bentuk dihargai, dan event khusus direncanakan di berbagai lokasi di seluruh dunia. Tanggal 4 Oktober pada awalnya dipilih sebagai Hari Binatang Sedunia karena pada tanggal itu diadakan pesta perjamuan Francis of Assisi, seorang pecinta alam dan pelindung binatang dan lingkungan. Dan beberapa gereja ketika itu melakukan pemberkatan terhadap binatang pada hari Minggu yang berdekatan dengan tanggal 4 Oktober. Ketika itu, hari perayaan yang berkaitan dengan binatang seperti itu adalah perayaan khusus agama kristen.\n" +
                    "\n" +
                    "Saat ini, perayaan Hari Binatang Sedunia dirayakan oleh seluruh penyayang binatang dari seluruh agama dan kepercayaan, kebangsaan, dan latar belakang, namun pemberkatan terhadap binatang tetap dilakukan di berbagai gereja. Tim penyelamat binatang dan berbagai organisasi satwa liar melakukan kegiatan pengumpulan dana, bazaar, dan sebagainya di berbagai sekolah dan tempat kerja. Pada hari itu, mereka juga memberikan penghargaan terhadap individu, sekelompok orang, atau lembaga yang dianggap telah memberikan kontribusi terbaik pada dunia binatang. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 5 Oktober: Hari Tentara Nasional Indonesia (TNI)")){
            infoBulan.setText("Tentara Nasional Indonesia (disingkat menjadi TNI) adalah nama untuk angkatan bersenjata dari negara Indonesia. Pada awal dibentuk, lembaga ini bernama Tentara Keamanan Rakyat (TKR) kemudian berganti nama menjadi Tentara Republik Indonesia (TRI) sebelum diubah lagi namanya menjadi Tentara Nasional Indonesia (TNI) hingga saat ini.\n" +
                    "\n" +
                    "TNI terdiri dari tiga angkatan bersenjata, yaitu TNI Angkatan Darat, TNI Angkatan Laut, dan TNI Angkatan Udara. TNI dipimpin oleh seorang Panglima TNI, sedangkan masing-masing angkatan dipimpin oleh seorang Kepala Staf Angkatan. Panglima TNI yang saat ini menjabat adalah Marsekal TNI Hadi Tjahjanto.\n" +
                    "\n" +
                    "Pada masa Demokrasi Terpimpin hingga masa Orde Baru, TNI pernah digabungkan dengan POLRI. Penggabungan ini dikenal secara kolektif dengan singkatan ABRI (Angkatan Bersenjata Republik Indonesia). Sesuai Ketetapan MPR nomor VI/MPR/2000 tentang pemisahan TNI dan POLRI serta Ketetapan MPR nomor VII/MPR/2000 tentang peran TNI dan POLRI, maka pada tanggal 30 September 2004 RUU TNI disahkan oleh Dewan Perwakilan Rakyat yang selanjutnya ditandatangani oleh Presiden Megawati Soekarnoputri pada tanggal 19 Oktober 2004. Negara Indonesia pada awal berdirinya sama sekali tidak mempunyai kesatuan tentara. Badan Keamanan Rakyat yang dibentuk dalam sidang PPKI tanggal 22 Agustus 1945 dan diumumkan oleh Presiden pada tanggal 23 Agustus 1945 bukanlah tentara sebagai suatu organisasi kemiliteran yang resmi.\n" +
                    "\n" +
                    "BKR baik di pusat maupun di daerah berada di bawah wewenang Komite Nasional Indonesia Pusat (KNIP) dan KNI Daerah dan tidak berada di bawah perintah presiden sebagai panglima tertinggi angkatan perang. BKR juga tidak berada di bawah koordinasi Menteri Pertahanan. BKR hanya disiapkan untuk memelihara keamanan setempat agar tidak menimbulkan kesan bahwa Indonesia menyiapkan diri untuk memulai peperangan menghadapi Sekutu.\n" +
                    "\n" +
                    "Akhirnya, melalui Maklumat Pemerintah tanggal 5 Oktober 1945, BKR diubah menjadi Tentara Keamanan Rakyat (TKR). Pada tanggal 7 Januari 1946, Tentara Keamanan Rakyat berganti nama menjadi Tentara Keselamatan Rakyat. Kemudian pada 26 Januari 1946, diubah lagi menjadi Tentara Republik Indonesia (TRI).\n" +
                    "\n" +
                    "Sejak 1959, tanggal 5 Oktober ditetapkan sebagai Hari Angkatan Perang, yang saat ini disebut sebagai Hari Tentara Nasional Indonesia, yaitu hari nasional yang bukan hari libur yang ditetapkan oleh pemerintah Indonesia melalui Keppres No. 316 Tahun 1959 tanggal 16 Desember 1959 untuk memperingati peristiwa kelahiran angkatan bersenjata Indonesia.[6]\n" +
                    "\n" +
                    "Karena saat itu di Indonesia terdapat barisan-barisan bersenjata lainnya di samping Tentara Republik Indonesia, maka pada tanggal 15 Mei 1947, Presiden Soekarno mengeluarkan keputusan untuk mempersatukan Tentara Republik Indonesia dengan barisan-barisan bersenjata tersebut menjadi Tentara Nasional Indonesia (TNI). Penyatuan itu terjadi dan diresmikan pada tanggal 3 Juni 1947. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal (Setiap Hari Kamis Kedua Oktober): Hari Mata Sedunia[32]")){
            infoBulan.setText("Jaga Mata Sehat, Begini Sejarah Hari Penglihatan Sedunia\n" +
                    "\n" +
                    "Mata menjadi salah satu panca indera yang begitu penting. Tanpanya, kita tidak dapat melihat indahnya dunia yang dapat kita nikmati setiap hari. Oleh karena berharganya organ penglihatan ini, diperingatilah satu hari yang didedikasikan untuk mata. Yaitu hari penglihatan sedunia.\n" +
                    "\n" +
                    "Tidak seperti peringatan lain yang tepat ditunjuk suatu tanggal, misalnya hari kemerdekaan yang selalu jatuh setiap 17 Agustus. Hari Penglihatan Sedunia diperingati pada hari Kamis minggu kedua bulan Oktober. Dimana dikenal dengan nama World Sight Day, dan sudah dilakukan sejak tahun 1988 oleh Lions Club International. Kemudian berintegrasi menjadi VISION 2020 di bawah naungan World Health Organization (WHO) dan International Agency for the Prevention of Blindness (IAPB).\n" +
                    "Jaga Mata Sehat untuk Investasi Bangsa\n" +
                    "\n" +
                    "Mata sehat adalah dambaan setiap manusia. Bahkan, tema Hari Penglihatan Dunia di Indonesia pada tahun 2017 lalu bertajuk “Mata Sehat, Investasi Bangsa”. Mencerminkan betapa pentingnya kesehatan mata.\n" +
                    "\n" +
                    "Mirisnya saat ini, kesehatan mata justru menurun. Banyak anak yang masih di bawah umur yang mengalami masalah penglihatan, seperti minus. Hal ini diakibatkan karena penggunaan gadget yang berlebihan pada anak. Alhasil, banyak anak usia SD yang sudah menggunakan kacamata minus.\n" +
                    "\n" +
                    "Lain halnya dengan masalah kesehatan mata pada orang dewasa. Dimana usia 45 tahun sudah mulai terserang katarak. Katarak dapat menyebabkan kebutaan, dimana sekitar 1,5 juta kebutaan di Indonesia disebabkan karena katarak.\n" +
                    "Tips Menjaga Kesehatan Mata\n" +
                    "hari penglihatan seduniahttps://unsplash.com\n" +
                    "\n" +
                    "Mata sehat sangatlah penting, baik bagi anak-anak maupun bagi orang dewasa. Oleh karena itu, setiap orang perlu menerapkan tips untuk menjaga kesehatan mata. Diantaranya adalah mengkonsumsi makanan sehat untuk mata. Kelompok ikan tuna, hering, dan sarden kaya omega 3 yang baik untuk mata. Konsumsi sayur dan buah khususnya jeruk mandarin, jeruk clementine, wortel, bayam, dan brokoli, sangat baik untuk mencegah katarak.\n" +
                    "\n" +
                    "Selain konsumsi makanan, kesehatan mata juga dapat dijaga dengan menyelingi penglihatan ke luar ruangan. Tidak hanya terfokus pada gadget atau layar komputer. Berjalan-jalan di luar ruangan atau sekedar melihat lingkungan sekitar dapat memberi kesempatan mata untuk dapat fokus pada sesuatu yang jauh.\n" +
                    "\n" +
                    "Sobat Sehat juga dapat mengkonsumsi suplemen kesehatan mata untuk jaga mata agar dapat selalu ternutrisi meski sering menatap layar komputer.\n" +
                    "\n" +
                    "Yuk, jaga mata agar tetap sehat dengan tips-tips diatas. Selamat Hari Penglihatan Sedunia!\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 Oktober: Hari Museum Nasional")){
            infoBulan.setText("GenPI.co - Setiap tanggal 12 Oktober negeri ini merayakan Hari Museum Indonesia. Hari tersebut ditetapkan berdasarkan penyelengaraan musyawarah museum se-Indonesia pertama yang digelar pada 12 hingga 14 Oktober 1962 di Yogyakarta.\n" +
                    "\n" +
                    "Pertemuan tersebut menghasilkan sejumlah resolusi yang memiliki nilai penting untuk memajukan museum Indonesia. Kemudian, Hari Museum Indonesia ditetapkan pada 12 Oktober sejak tahun 2015. Pendeklarasian Hari Museum Indonesia dilakukan di Malang, 26 Mei 2015, bertepatan dengan kegiatan tahunan Pertemuan Nasional Museum.\n" +
                    "\n" +
                    "BACA JUGA: Johnnie Sugiarto: Masuk Museum di Indonesia Bikin Sebal\n" +
                    "\n" +
                    "Berdasarkan data dari Direktorat Pelestarian Cagar Budaya dan Permuseuman, hingga saat ini Indonesia memiliki 435 museum yang tersebar di berbagai daerah. Namun, museum masih belum begitu digemari sebagaimana destinasi wisata lainnya. Itu karena  museum dianggap tidak menarik, membosankan, dan kuno.\n" +
                    "\n" +
                    "Setiap tahunnya, Hari Museum Indonesia dirayakan melalui berbagai kegiatan dan tema yang berbeda. Pada 2019 ini, perayaan Hari Museum Indonesia mengambil tema ‘Museum Menyatukan Keberagaman’.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 12 Oktober: Hari Radang Sendi (Artritis) Sedunia[33]")){
            infoBulan.setText("tirto.id - Hari Radang Sendi Sedunia atau arthritis diperingati setiap tanggal 12 Oktober, bertepatan dengan Sabtu besok, 12 Oktober 2019. Hari Radang Sendi Sedunia pertama kali diperingati oleh Arthritis Rheumatism Internasional (ARI) pada 12 Oktober 1996, demikian berdasarkan studi yang diwartakan NCBI. Kegiatan ini diperingati dengan tujuan mengajak masyarakat agar peduli dan mau memperhatikan secara serius orang dengan penyakit arthritis. Kemudian dengan dilakukan peringatan Hari Radang Sendi Sedunia setiap tahunnya, dapat memengaruhi kebijakan pemerintah untuk ramah terhadap penderita arthritis radang sendi. Serta memberikan semangat terhadap penderita radang sendi atau arthritis agar tetap dapat menjalankan hidup seperti orang lain pada umumnya dan bermanfaat bagi masyarakat. Ada 100 macam penyakit yang memengaruhi daerah sekitar sendi di antaranya Osteoarthritis (OA), Arthritis Gout (pirai), Arthritis Rheumatoid (AR), dan fibromialgia. Osteoarthritis adalah jenis arthritis yang paling umum terjadi. Kondisi ini menyebabkan sendi-sendi terasa sakit dan kaku. Kelebihan berat badan (obesitas) juga bisa menyebabkan osteoarthritis. Kaum perempuan biasanya lebih rentan terserang osteoarthritis ketimbang laki-laki. Penyebab lain yang membuat orang terkena osteoarthritis karena trauma fisik, genetik, kurang nutrisi hingga hormonal, dan faktor usia. \"Pencegahan yang paling mudah, yakni dengan gaya hidup sehat, mengontrol berat badan, olahraga ringan yang dilakukan secara terus menerus, dan mencegah kegiatan yang banyak menggunakan kinerja sendi serta rutin melakukan pemeriksaan,\" kata Ahli Ilmu Penyakit Dalam Fakultas Kedokteran Universitas Brawijaya (UB) Malang dr Bagus Putu Putra Suryana seperti dikutip Antara. Sayangnya, banyak orang menganggap sepele penyakit sendi. Jangankan melakukan pencegahan, ketika mengalami gejala radang sendi, tak sedikit yang acuh. Kesadaran orang Indonesia termasuk yang rendah terhadap penanganan penyakit ini. Berdasarkan riset yang dilakukan MARS untuk sebuah studi Indonesia Consumer Health Profile 2015, sebanyak 98 persen masyarakat Indonesia mengaku tidak membeli obat sendi dalam 3 bulan terakhir, hanya 2 persen yang mengaku membeli obat sendi. “Terlihat dari data tersebut, penyakit sendi belum menjadi perhatian dari masyarakat,” jelas laporan riset MARS. Days Of The Year menyebutkan, jutaan orang yang terkena arthritis di seluruh dunia membuat hidupnya jadi berubah karena penyakit nyeri sendi yang meradang. Hari Radang Sendi Sedunia adalah hari untuk mengingat dan meningkatkan kesadaran akan kondisi ini. Yayasan ARI yang mendeklarasikan peringatan Hari Radang Sendi Sedunia berharap apa yang dilakukan tiap tahun ini bisa membantu menurunkan beban para penderita arthritis di seluruh dunia. Arthritis sendiri sebenarnya berasal dari kata Yunani arthro, yang berarti gabungan, dan itis, yang berarti peradangan. Seperti namanya, ini adalah kondisi yang melibatkan peradangan sendi, tetapi tidak seperti konsepsi umum bahwa itu adalah penyakit yang dimiliki, hanya merupakan gejala dari penderitaan lain. Gout, Osteoartritis, artritis reumatoid, serta Lupus hanyalah beberapa penyebab yang lebih umum dari kondisi yang menyakitkan dan seringkali melumpuhkan ini. Sebuah penelitian menyebutkan, penyakit radang sendi telah hadir sejak 4.500 SM, dan telah terbukti menjadi salah satu hal yang menyengsarakan bagi masyarakat prasejarah. Hal ini pertama kali diteliti dan diklasifikasikan dalam karya William Musgraves, De Arthritide symptomatica, yang ditulis pada tahun 1715. Untuk kondisi seperti rheumatoid arthritis dan osteoarthritis, tidak ada obatnya, walaupun seringkali ada perawatan yang bisa dilakukan. Sementara sebagian kasus radang sendi lainnya bisa dilakukan dengan kontrol ke dokter, termasuk rutin berolahraga dan bekerja untuk mengurangi berat badan seseorang. Terapi fisik sering dianggap efektif dalam membantu, tetapi kondisi tersebut sering menghambat pelaksanaan terapinya. Dengan diperingatinya Hari Radang Sendi Sedunia, maka ini adalah waktu yang tepat bagi masyarakat untuk memberikan bantuan kepada orang-orang yang menderita kondisi ini. Jika memiliki keluarga yang menderita penyakit ini, sebaiknya luangkan waktu sehari untuk mengunjungi dan membantu hal-hal yang menyulitkan kondisinya agar para penderita juga merasa bisa menjalankan hidup seperti orang umum lainnya.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"12 Oktober Hari Radang Sendi Sedunia untuk Para Penderita Arthritis\", https://tirto.id/ejzs");
        }else if(tanggal.equalsIgnoreCase("Tanggal 15 Oktober: Hari Hak Asasi Binatang")){
            infoBulan.setText("tirto.id - Hari Hewan Sedunia diperingati setiap 4 Oktober 2019. Sebagai salah satu makhluk yang hidup di Bumi berdampingan dengan manusia, hewan juga memiliki hak untuk hidup tanpa rasa sakit dan menderita. Hanya karena manusia berada di puncak rantai makanan, bukan berarti manusia satu-satunya yang memiliki hak untuk hidup. Manusia memiliki tanggung jawab untuk memastikan semua makhluk hidup dilindungi, terutama hewan. Seperti manusia, hewan juga memiliki kemampuan untuk merasakan sakit, senang, takut, dan frustasi. Manusia, entah secara sadar atau tidak, sering melakukan sesuatu yang mengganggu kebutuhan hewan. Untuk itulah secara moral manusia perlu membuat hak asasi hewan yang mana bisa menjamin hak hidup dan kesejahteraan hewan. Richard Ryder dalam bukunya Peninism: A Modern Morality (2001) mengatakan, rasa sakit adalah indikator untuk mengukur moralitas di era ini. Jika manusia enggan dilukai dan merasa sakit, maka binatang juga demikian, sebab keduanya adalah makhluk hidup yang dapat merasakan kesakitan. Di Indonesia hak asasi hewan di dukung dalam Kitab Undang-Undang Hukum Pidana (KUHP) pasal 302 dan Undang-undang Nomor 18 tahun 2009 tentang Peternakan dan Kesehatan Hewan. Dilansir Antara News, menurut advokat profauna Irma Hermawati mengatakan hak asasi hewan terdiri atas lima kebebasan. Kebebasan pertama yakni bebas dari rasa haus dan lapar, kedua kebebasan dari rasa tidak nyaman, yang ketiga kebebasan mengekspresikan tingkah laku alami mereka, yang keempat bebas dari rasa stres dan takut, serta yang kelima bebas dari sakit maupun dilukai. Hak asasi hewan ini tidak hanya memberi manfaat bagi hewan saja, tetapi juga bagi manusia yang hidup dalam satu ekosistem. Irma mengatakan ada hubungannya antara pelalaian hak asasi hewan dengan penularan penyakit dari hewan atau zoonisis. \"Zoonisis terjadi saat hewan stres atau terluka. Hewan yang stres dan terluka menunjukkan adanya kelalaian dalam pemenuhan haknya bebas dari stres dan sakit,\" kata Irma. Tentu ada hukuman yang berlaku bagi siapa pun yang melakukan pelanggaran terhadap hak-hak hewan yang diatur dalam undang-undang. Dalam KUHP Pasal 302 mengatakan pelaku penganiayaan ringan terhadap hewan dapat dipidana penjara paling lama tiga bulan atau pidana denda paling banyak Rp4.500. Penganiayaan yang dimaksud tertuang pada nomor 1 dan 2 yakni melukai, menyakiti, merugikan kesehatan tanpa alasan yang jelas, serta sengaja tidak memberi makan hewan peliharaan. Jika perbuatan penganiayaan mengakibatkan luka berat,yang dalam KUHP dicirikan sebagai sakit lebih dari seminggu, cacat, menderita luka-luka berat, atau mati, maka pelaku dapat dipidana penjara paling lama sembilan bulan atau denda paling banyak tiga ratus rupiah. Indonesia hanya satu dari ratusan negara di dunia yang menyadari hewan memiliki hak-hak yang harus dipenuhi. Masyarakat internasional yang peduli dan sadar atas kasus hak asasi hewan memperingatinya setiap tanggal 15 Oktober sebagai hari hak asasi binatang.\n" +
                    "\n" +
                    "Baca selengkapnya di artikel \"Hari Hewan Sedunia: Lima Hak Asasi Binatang di Indonesia\", https://tirto.id/ei8c");
        }else if(tanggal.equalsIgnoreCase("Tanggal 16 Oktober: Hari Parlemen Indonesia[34]")){
            infoBulan.setText("\n" +
                    "Kenapa Sih Ada Hari Parlemen Indonesia?\n" +
                    "Oktober 16, 2019 oleh : superadmin-ip\t\n" +
                    "\n" +
                    "Sejarah Hari Parlemen Indonesia yang diperingati setiap tanggal 16 Oktober memiliki nilai historis yang sangat penting untuk diketahui mahasiswa Ilmu Pemerintahan (IP) Universitas Muhammadiyah Yogyakarta (UMY).\n" +
                    "\n" +
                    "Pada saat Indonesia masih berstatus sebagai negara baru merdeka, Mohammad Hatta (Wakil Presiden pertama Indonesia) dan Sutan Sjahir (Perdana Menteri pertama Indonesia) menyadari bahwa Indonesia memerlukan suatu badan atau lembaga yang dapat mewakili aspirasi rakyat. Dengan ide tersebut, dibentuklah Komite Nasional Indonesia Pusat (KNIP) pada 29 Agustus 1945.\n" +
                    "\n" +
                    "Atas pertimbangan politik agar Indonesia diakui sebagai negara yang demokratis yang memiliki aparatur lengkap, Hatta mengeluarkan Maklumat Wakil Presiden Nomor X tanggal 16 Oktober 1945 yang memutuskan bahwa tugas KNIP berubah, dari pembantu presiden menjadi setara dengan presiden yaitu menyusun Undang-Undang dan ikut menetapkan Garis-Garis Besar Haluan Negara.\n" +
                    "\n" +
                    "Dengan Dikeluarkannya maklumat tersebut maka dianggap menjadi awal lahirnya parlemen di Indonesia, sekaligus menjadi alasan diperingatinya Hari Parlemen Indonesia setiap tanggal 16 Oktober.\n" +
                    "\n" +
                    "Peringatan Hari Parlemen Indonesia ini diharapkan dapat menjadi refleksi bagi anggota legislatif untuk memperbaiki serta meningkatkan kinerjanya sebagai wakil rakyat. Karena jika kita melihat survei yang dilakukan Lembaga Survei Indonesia (LSI) pada 4-5 Oktober 2019, Dewan Perwakilan Rakyat (DPR) kita saat ini mendapatkan tingkat kepercayaan publik paling rendah yaitu hanya 40% (Presiden Joko Widodo: 71% dan Komisi Pemberantasan Korupsi: 72%). (Bhk)");
        }else if(tanggal.equalsIgnoreCase("Tanggal 16 Oktober: Hari Pangan Sedunia")){
            infoBulan.setText("\n" +
                    "\n" +
                    "HAI-Online.com – Setiap tanggal 16 Oktober, hari pangan sedunia diperingati. Yuk perhatikan makanan sehari-hari kita, salah satunya nasi yang dipanaskan berulang kali!\n" +
                    "\n" +
                    "Pada saat sedang malas menghabiskan waktu untuk memasak di dapur, kita seringkali memilih memanaskan kembali beberapa sisa makanan yang kita miliki di dapur.\n" +
                    "\n" +
                    "Namun, banyak pendapat beredar memanaskan nasi atau makanan berbahan nasi bisa membahanyakan kesehatan lho.\n" +
                    "\n" +
                    "Baca Juga : 10 Makanan Aneh Tapi Dianggap Lezat oleh Berbagai Negara di Dunia\n" +
                    "\n" +
                    "Nasi yang dipanaskan secara berulang setelah disimpan dalam udara ruangan dipercaya dapat menyebabkan keracunan makanan. Lalu, apa kata para ahli mengenai hal ini?\n" +
                    "\n" +
                    "Menurut NHS, dilansir HAI dari Intisari, nasi dapat dipanaskan kembali setelah dimasak, tetapi tidak dalam jangka waktu yang lama.\n" +
                    "\n" +
                    "Nasi memang sebaiknya segera dimakan setelah dimasak. Namun, jika kita tak langsung memakannya, pastikan tidak menyimpannya terlalu lama.\n" +
                    "\n" +
                    "Jangan simpan nasi lebih dari satu hari sebelum memanaskannya kembali.\n" +
                    "\n" +
                    "Pakar gizi, Jansen Ongko, MSc, RD, mengatakan bahwa tidak ada efek signifikan mengenai jangka waktu pemanasan nasi di dalam magic jar dengan kesehatan.\n" +
                    "\n" +
                    "\"Selama tidak terkontaminasi dan disimpan dengan baik, nasi aman untuk dikonsumi,\" ucap Jansen lebih lanjut.\n" +
                    "\n" +
                    "Mengenai kadar gula dalam nasi, seorang peneliti dari Wageningen University, Prof. Edith Feskens, mengatakan bahwa nasi yang lengket atau dimasak lama, memang memiliki indeks glikemik (IG) yang lebih tinggi bila dibandingkan dengan nasi yang kering.\n" +
                    "\n" +
                    "Sementara itu, Jansen mengatakan bahwa indeks glikemik hanya berbahaya bagi pasien diabetes.\n" +
                    "\n" +
                    "Memasak nasi tidak selalu membunuh bakteri. Jadi, ketika nasi dibiarkan dingin pada suhu kamar, bakteri Bacillus cereus dapat berkembang biak dan berbahaya jika dikonsumsi.\n" +
                    "\n" +
                    "Jika kita mengalami keracunan makanan setelah mengonsumsi nasi yang dipanaskan, kemungkinan besar ini disebabkan oleh adanya bakteri Bacillus Cereus.\n" +
                    "\n" +
                    "Bakteri ini penyebab gejala mual, muntah dan diare. (*)");
        }else if(tanggal.equalsIgnoreCase("Tanggal 22 Oktober: Hari Santri Nasional[35]")){
            infoBulan.setText("Hari Santri Nasional (HSN) jatuh pada tanggal 22 Oktober setiap tahunnya. Peringatan ini, ditetapkan oleh Presiden Joko Widodo pada tanggal 22 Oktober 2015 di Masjid Istiqlal Jakarta. Penetapan Hari Santri Nasional dimaksudkan untuk mengingat dan meneladani semangat jihad para santri merebut serta mempertahankan kemerdekaan Indonesia yang digelorakan para ulama. Tanggal 22 Oktober merujuk pada satu peristiwa bersejarah yakni seruan yang dibacakan oleh Pahlawan Nasional KH Hasjim Asy'ari pada 22 Oktober 1945. Seruan ini berisikan perintah kepada umat Islam untuk berperang (jihad) melawan tentara Sekutu yang ingin menjajah kembali wilayah Republik Indonesia pasca-Proklamasi Kemerdekaan. Sekutu ini maksudnya adalah Inggris sebagai pemenang Perang Dunia II untuk mengambil alih tanah jajahan Jepang. Di belakang tentaran Inggris, rupanya ada pasukan Belanda yang ikut membonceng.\n" +
                    "\n" +
                    "Aspek lain yang melatarbelakangi penetapan HSN ini adntah Republik Indonesia atas peran besar umat Islam dalam berjuang merebut dan mempertahankan kemerdekaan serta menjaga NKRI. Ini sekaligus merevisi beberapa catatan sejarah nasional, terutama yang ditulis pada masa Orde Baru, yang hampir tidak pernah menyebut peran ulama dan kaum santri.[1][2][3] ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 24 Oktober: Hari Dokter Nasional [36]")){
            infoBulan.setText("Jakarta - Setiap 24 Oktober, diperingati sebagai salah satu hari bersejarah terutama untuk Ikatan Dokter Indonesia (IDI). IDI menetapkan hari tersebut menjadi Hari Dokter Nasional. Peringatan hari penting ini ternyata telah berlangsung lama di Indonesia.\n" +
                    "\n" +
                    "Sejarahnya dimulai saat IDI pertama kali lahir di tanah air. Dikutip dari laman resmi Kementerian Kesehatan RI, IDI sudah ada sejak tahun 1911, dengan nama Vereniging van Indische Artsen. Tetapi, pada tahun 1926, nama itu berubah menjadi Vereniging Van Indonesische Genesjkundigen (VIG).\n" +
                    "\n" +
                    "Seiring berjalannya waktu, perjalanan karir dokter di Indonesia semakin pesat. Hingga pada tahun 1940 di Solo, VIG mengadakan sebuah kongres. Pada kongres tersebut, Prof Bahder Djohan ditugaskan untuk membina dan memikirkan istilah baru dalam dunia kedokteran.\n" +
                    "\n" +
                    "Baca juga: 4 Fakta Stunting, Salah Satu PR Utama Menkes Baru dr Terawan\n" +
                    "\n" +
                    "\n" +
                    "Namun, tiga tahun kemudian saat masa pendudukan Jepang, VIG dibubarkan dan berganti nama menjadi Jawa IZI Hooko-Kai. Selanjutnya, pada 30 Juli 1950, atas usulan dr Seni Sastromidjojo, Persatuan Tabib Indonesia (PB Perthabin) dan Perkumpulan Dokter Indonesia (DP-PDI) mengadakan pertemuan. Dari pertemuan tersebut, menghasilkan \"Muktamar Dokter Warganegara Indonesia (PMDWNI)\" yang diketuai oleh dr Bahder Djohan.\n" +
                    "\n" +
                    "Puncaknya pada 22-25 September 1950 Muktamar I Ikatan Dokter Indonesia (MIDI) digelar di Deca Park, kemudian diresmikan pada bulan Oktober. Dalam Muktamar IDI tersebut, terpilihlah dr Sarwono Prawirohaedjo sebagai ketua umum pertama di IDI.\n" +
                    "\n" +
                    "Pada tanggal 24 Oktober di tahun yang sama, dr Soeharto menghadap notaris guna memperoleh dasar hukum berdirinya perkumpulan dokter. Perkumpulan tersebut dinamakan 'Ikatan Dokter Indonesia'. Sejak saat itu, 24 Oktober 1950 dijadikan sebagai Hari Dokter Nasional, yang bertepatan dengan terbentuknya IDI di Indonesia.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 24 Oktober: Hari Perserikatan Bangsa-Bangsa (PBB)")){
            infoBulan.setText("Hari Perserikatan Bangsa-Bangsa diperingati setiap tanggal 24 Oktober untuk memperingati Piagam Perserikatan Bangsa-Bangsa. Peringatan ini dideklarasikan pada tahun 1947 oleh Majelis Umum Perserikatan Bangsa-Bangsa. Hari PBB dirayakan untuk memberitahukan kepada masyarakat mengenai tujuan dan pencapaian Perserikatan Bangsa-Bangsa.\n" +
                    "\n" +
                    "Perserikatan Bangsa-Bangsa secara tradisional dirayakan di seluruh dunia dengan berbagai pertemuan, diskusi, dan eksibisi mengenai pencapaian dan tujuan dari PBB. Pada tahun 1971, Majelis Umum merekomendasikan negara-negara anggota untuk menjadikan hari ini sebagai hari libur.\n" +
                    "\n" +
                    "Beberapa sekolah internasional di seluruh dunia juga merayakan diversitas murid-muridnya dengan Hari PBB. Perayaan sering kali melibatkan pertunjukan budaya di malam hari dan food fair yang menyediakan makanan dari seluruh dunia. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 24 Oktober: Hari Polio Sedunia[37]")){
            infoBulan.setText("TRIBUNKALTIM.CO - Hari Polio Sedunia 24 Oktober, Kenali Gejala & Penyebabnya yang Bisa Menyerang Anak di Bawah 5 Tahun\n" +
                    "\n" +
                    "Tanggal 24 Oktober selalu diperingati sebagai Hari Polio Sedunia.\n" +
                    "\n" +
                    "Mengapa Hari Polio Sedunia jatuh pada tanggal 24 Oktober?\n" +
                    "\n" +
                    "Ternyata tanggal 24 Oktober diperingati sebagai Hari Polio Sedunia untuk mengenang Jonas Salk.\n" +
                    "\n" +
                    "Sosok Jonas Salk merupakan orang yang kali pertama memimpin tim pembuatan vaksin melawan penyakit polio\n" +
                    "\n" +
                    "Polio merupakan penyakit infeksi berat yang bisa menimbulkan kelumpuhan.\n" +
                    "\n" +
                    "Tidak hanya itu, polio bahkan menyebabkan anak rentan akan kematian.\n" +
                    "\n" +
                    "Saat ini, memang belum ada obat untuk mengobati polio.\n" +
                    "\n" +
                    "Namun, penyakit itu dapat dicegah dengan menggunakan vaksin\n" +
                    "\n" +
                    "Indonesia sendiri bisa dibilang cukup berhasil dalam mengatasi penyakit polio.\n" +
                    "\n" +
                    "• Per Agustus, 10.205 Anak Asmat Sudah Vaksin Campak, Rubella dan Polio (MRP)\n" +
                    "\n" +
                    "• Kutim Raih Penghargaan PIN untuk Vaksin Polio\n" +
                    "\n" +
                    "Melansir Kompas.com, setidaknya, pada 2014 Indonesia masuk dalam kategori negara bebas polio dari organisasi kesehatan dunia, WHO.\n" +
                    "\n" +
                    "Infografik tentang penyakit polio:\n" +
                    "Tentang penyakit polio\n" +
                    "Tentang penyakit polio (Infografik Kompas.com)\n" +
                    "\n" +
                    "Dalam memperingati Hari Polio Sedunia, kenali penyebab, gejala dan pencegahan penyakit polio.\n" +
                    "\n" +
                    "Dilansir dari alodokter, simak penyebab, gela dan pencegahan polio berikut ini:\n" +
                    "\n" +
                    "Penyebab Polio\n" +
                    "\n" +
                    "Penyakit polio disebabkan oleh virus polio.\n" +
                    "\n" +
                    "Virus tersebut masuk melalui rongga mulut atau hidung, kemudian menyebar di dalam tubuh melalui aliran darah.\n" +
                    "\n" +
                    "Penyebaran virus polio dapat terjadi melalui kontak langsung dengan tinja penderita polio, atau melalui konsumsi makanan dan minuman yang telah terkontaminasi virus polio.\n" +
                    "\n" +
                    "Virus ini juga dapat menyebar melalui percikan air liur ketika penderita batuk atau bersin, namun lebih jarang terjadi.\n" +
                    "\n" +
                    "Virus polio sangat mudah menyerang orang-orang yang belum mendapatkan vaksin polio, terlebih pada kondisi berikut ini:\n" +
                    "\n" +
                    "- Tinggal di daerah dengan sanitasi buruk atau akses air bersih yang terbatas.\n" +
                    "\n" +
                    "- Sedang hamil.\n" +
                    "\n" +
                    "- Memiliki sistem kekebalan tubuh lemah, misalnya penderita AIDS.\n" +
                    "\n" +
                    "- Merawat anggota keluarga yang terinfeksi virus polio.\n" +
                    "\n" +
                    "- Pernah menjalani pengangkatan amandel.\n" +
                    "\n" +
                    "- Menjalani aktivitas berat atau mengalami stres setelah terpapar virus polio.\n" +
                    "\n" +
                    "- Bekerja sebagai petugas kesehatan yang menangani pasien polio.\n" +
                    "\n" +
                    "- Melakukan perjalanan ke daerah yang pernah mengalami wabah polio.\n" +
                    "\n" +
                    "Gejala Polio\n" +
                    "\n" +
                    "Sebagian besar penderita polio tidak menyadari bahwa diri mereka telah terinfeksi polio, sebab virus polio pada awalnya hanya menimbulkan sedikit gejala atau bahkan tidak menimbulkan gejala sama sekali.\n" +
                    "\n" +
                    "Meskipun demikian, penderita polio tetap dapat menyebarkan virus dan menyebabkan infeksi pada orang lain.\n" +
                    "\n" +
                    "Berdasarkan gejala yang muncul, polio dapat dibagi menjadi dua jenis, yaitu polio yang tidak menyebabkan kelumpuhan (nonparalisis) dan polio yang menyebabkan kelumpuhan (paralisis).\n" +
                    "\n" +
                    "Berikut adalah gejala kedua jenis polio tersebut:\n" +
                    "\n" +
                    "1. Polio nonparalisis\n" +
                    "\n" +
                    "Polio nonparalisis adalah jenis polio yang tidak menyebabkan kelumpuhan.\n" +
                    "\n" +
                    "Gejala polio ini muncul 6-20 hari sejak terpapar virus dan bersifat ringan.\n" +
                    "\n" +
                    "Gejala berlangsung selama 1-10 hari, dan akan menghilang dengan sendirinya.\n" +
                    "\n" +
                    "Gejala tersebut meliputi:\n" +
                    "\n" +
                    "- Demam\n" +
                    "- Sakit kepala\n" +
                    "- Radang tenggorokan\n" +
                    "- Muntah\n" +
                    "- Otot terasa lemah\n" +
                    "- Kaku di bagian leher dan punggung\n" +
                    "- Nyeri dan mati rasa di bagian lengan atau tungkai\n" +
                    "\n" +
                    "2. Polio paralisis\n" +
                    "\n" +
                    "Polio paralisis adalah jenis polio yang berbahaya karena dapat menyebabkan kelumpuhan saraf tulang belakang dan otak secara permanen.\n" +
                    "\n" +
                    "Gejala awal polio paralisis serupa dengan polio nonparalisis.\n" +
                    "\n" +
                    "Namun dalam waktu 1 minggu, akan muncul gejala berupa:\n" +
                    "\n" +
                    "- Hilangnya refleks tubuh\n" +
                    "- Ketegangan otot yang terasa nyeri\n" +
                    "- Tungkai atau lengan terasa lemah\n" +
                    "\n" +
                    "• AHY dan Ahok, Alasan Ruhut Sitompul Hengkang dari Demokrat ke PDIP, Partai Megawati, Ini Ulasannya\n" +
                    "\n" +
                    "• Pesona Cantik Istri-istri Menteri Jokowi 2019-2024: Nadiem Makarim, Wishnutama hingga Edhy Prabowo\n" +
                    "\n" +
                    "• Respon Tak Terduga Polisi Polsek Sampai Mabes ke Calon Kapolri Baru Idham Aziz Ganti Tito Karnavian\n" +
                    "\n" +
                    "Pencegahan Polio\n" +
                    "\n" +
                    "Pencegahan polio dapat dilakukan dengan melakukan imunisasi polio.\n" +
                    "\n" +
                    "Vaksin polio mampu memberikan kekebalan terhadap penyakit polio dan aman diberikan kepada orang dengan sistem kekebalan tubuh yang lemah.\n" +
                    "\n" +
                    "Ada dua bentuk vaksin polio, yaitu suntik (IPV) dan obat tetes mulut (OPV).\n" +
                    "\n" +
                    "Polio dalam bentuk obat tetes mulut (OPV-0) diberikan kepada bayi sesaat setelah lahir.\n" +
                    "\n" +
                    "Selanjutnya, vaksin polio akan diberikan sebanyak empat dosis, baik dalam bentuk suntik (IPV) atau obat tetes mulut (OPV).\n" +
                    "\n" +
                    "Berikut adalah jadwal pemberian keempat dosis vaksin polio tersebut:\n" +
                    "\n" +
                    "- Dosis pertama (polio-1) diberikan saat usia 2 bulan.\n" +
                    "- Dosis kedua (polio-2) diberikan saat usia 3 bulan.\n" +
                    "- Dosis ketiga (polio-3) diberikan saat usia 4 bulan.\n" +
                    "- Dosis terakhir diberikan saat usia 18 bulan, sebagai dosis penguat.\n" +
                    "\n" +
                    "Dalam tiga dosis pertama (polio-1 hingga polio-3), seorang bayi setidaknya harus mendapat satu dosis vaksin polio dalam bentuk suntik (IPV).\n" +
                    "\n" +
                    "Untuk meningkatkan kesadaran masyarakat mengenai pentingnya imunisasi polio, pemerintah menyelenggarakan Pekan Imunisasi Nasional (PIN) Polio di seluruh wilayah Indonesia.\n" +
                    "\n" +
                    "Melalui kegiatan ini, semua bayi dan anak balita (usia 0-59 bulan) akan diberikan vaksinasi polio tambahan tanpa mempertimbangkan apakah imunisasinya sudah lengkap atau belum.\n" +
                    "\n" +
                    "Vaksin polio untuk dewasa\n" +
                    "\n" +
                    "Vaksin polio juga diberikan kepada orang dewasa yang belum pernah melakukan vaksinasi polio.\n" +
                    "\n" +
                    "Vaksin polio untuk dewasa diberikan dalam bentuk suntik (IPV) yang terbagi menjadi tiga dosis.\n" +
                    "\n" +
                    "Berikut adalah pembagian dosisnya:\n" +
                    "\n" +
                    "- Dosis pertama dapat diberikan kapan saja.\n" +
                    "- Dosis kedua diberikan dengan jeda waktu 1-2 bulan.\n" +
                    "- Dosis ketiga diberikan dengan jeda waktu 6-12 bulan setelah dosis kedua.\n" +
                    "\n" +
                    "Orang dewasa yang akan bepergian ke negara dengan kasus polio aktif juga dianjurkan untuk melakukan vaksinasi polio.\n" +
                    "\n" +
                    "Hal ini dilakukan sebagai bentuk pencegahan ketika berinteraksi dengan penderita atau orang yang diduga menderita polio.\n" +
                    "\n" +
                    "Efek samping yang dapat terjadi setelah pemberian suntikan polio adalah rasa nyeri dan kemerahan pada area suntikan.\n" +
                    "\n" +
                    "Beberapa orang mungkin mengalami alergi setelah vaksinasi, dengan gejala berupa:\n" +
                    "\n" +
                    "- Demam\n" +
                    "- Pusing\n" +
                    "- Tubuh terasa lemas\n" +
                    "- Muncul ruam\n" +
                    "- Jantung berdebar\n" +
                    "- Sesak napas\n" +
                    "\n" +
                    "Segera hubungi dokter jika Anda mengalami gejala alergi tersebut.\n" +
                    "\n" +
                    "(*)\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di tribunkaltim.co dengan judul Hari Polio Sedunia 24 Oktober, Kenali Gejala & Penyebabnya yang Bisa Menyerang Anak di Bawah 5 Tahun, https://kaltim.tribunnews.com/2019/10/24/hari-polio-sedunia-24-oktober-kenali-gejala-penyebabnya-yang-bisa-menyerang-anak-di-bawah-5-tahun?page=all.\n" +
                    "\n" +
                    "Editor: Alfiah Noor Ramadhany ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 27 Oktober: Hari Listrik Nasional[38]")){
            infoBulan.setText("JAKARTA – Sejarah ketenagalistrikan di Indonesia mengalami pasang surut sejalan dengan pasang surutnya perjuangan bangsa. Pada 27 Oktober 1945, atau bertepatan dengan hari ini, dikenal sebagai Hari Listrik dan Gas.\n" +
                    "\n" +
                    "Hari tersebut diperingati untuk pertama kali pada 27 Oktober 1946, bertempat di Gedung Badan Pekerja Komite Nasional Indonesia Pusat (BPKNIP) Yogyakarta. Demikian dilansir dari laman PLN Jatim.\n" +
                    "\n" +
                    " Razia Listrik Ilegal\n" +
                    "\n" +
                    "Penetapan secara resmi 27 Oktober 1945 sebagai Hari Listrik dan Gas berdasarkan keputusan Menteri Pekerjaan Umum dan Tenaga Nomor 20 tahun 1960, namun kemudian berdasarkan Keputusan Menteri Pekerjaan Umum dan Tenaga Listrik Nomor 235 /KPTS / 1975 tanggal 30 September 1975 peringatan Hari Listrik dan Gas yang digabung dengan Hari Kebaktian Pekerjaan Umum dan Tenaga Listrik yang jatuh pada tanggal 3 Desember.\n" +
                    "\n" +
                    "Mengingat pentingnya semangat dan nilai-nilai hari listrik, maka berdasarkan keputusan Menteri Pertambangan Dan Energi Nomor 1134.k. / 43.pe /1992 tanggal 31 Agustus 1992 ditetapkanlah tanggal 27 Oktober sebagai Hari Listrik Nasional. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 27 Oktober: Hari Penerbangan Nasional")){
            infoBulan.setText("InfoPenerbangan – Hari itu 27 Oktober 1945, sehari menjelang peringatan 17 tahun Sumpah Pemuda, di Pangkalan Maguwo, Yogyakarta terlihat ada kesibukan. Nampak para teknisi sedang berada di sekitar sebuah pesawat Cureng yang bertanda bulat Merah Putih, mempersiapkan segala sesuatunya untuk sebuah penerbangan yang direncanakan. Mereka menginginkan sebuah pesawat Merah Putih terbang hari itu, untuk membangkitkan Sumpah Pemuda. Komodor Udara Agustinus Adisutjipto, yang lebih dikenal dengan sebutan Pak Adi, adalah satu-satunya penerbang Indonesia yang berada di Pangkalan Maguwo. Hari itu, Pak Adi akan terbang bersama Cureng Merah Putih. Upaya itu membawa hasil. Pak Adi membawa terbang Pesawat Cureng Merah Putih tersebut berputar-putar di Angkasa Pangkalan Maguwo disaksikan dengan rasa kagum oleh seluruh anggota pangkalan yang berada dibawah. Itulah awal mula sebuah pesawat Indonesia bertanda Merah Putih terbang di angkasa Indonesia yang merdeka.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 Oktober: Hari Sumpah Pemuda")){
            infoBulan.setText("Sumpah Pemuda adalah satu tonggak utama dalam sejarah pergerakan kemerdekaan Indonesia. Ikrar ini dianggap sebagai kristalisasi semangat untuk menegaskan cita-cita berdirinya negara Indonesia.\n" +
                    "\n" +
                    "Yang dimaksud dengan \"Sumpah Pemuda\" adalah keputusan Kongres Pemuda Kedua[1] yang diselenggarakan dua hari, 27-28 Oktober 1928 di Batavia (Jakarta). Keputusan ini menegaskan cita-cita akan ada \"tanah air Indonesia\", \"bangsa Indonesia\", dan \"bahasa Indonesia\". Keputusan ini juga diharapkan menjadi asas bagi setiap \"perkumpulan kebangsaan Indonesia\" dan agar \"disiarkan dalam berbagai surat kabar dan dibacakan di muka rapat perkumpulan-perkumpulan\".\n" +
                    "\n" +
                    "Istilah \"Sumpah Pemuda\" sendiri tidak muncul dalam putusan kongres tersebut, melainkan diberikan setelahnya.[2] Berikut ini adalah bunyi tiga keputusan kongres tersebut sebagaimana tercantum pada prasasti di dinding Museum Sumpah Pemuda[3]. Penulisan menggunakan ejaan van Ophuijsen. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 29 Oktober: Hari Stroke Sedunia[39]")){
            infoBulan.setText("KOMPAS.com - Hari Stroke Sedunia diperingati pada 29 Oktober setiap tahunnya. Peringatan Hari Stroke Sedunia menjadi momentum untuk meningkatkan kesadaran akan stroke dan beban yang disebabkan olehnya terhadap jutaan orang di dunia. Setiap tahun, tema yang diusung berbeda-beda. Pada 2019, peringatan Hari Stroke Sedunia mengusung tema \"Don't Be The One\". Dikutip dari laman resmi World Stroke Campaign (WSC), tema tahun ini dipilih untuk menarik atensi dunia tentang urgensi aksi dalam pencegahan stroke. Laman WSC menyebutkan, satu dari empat orang memiliki risiko stroke di dalam hidupnya. Meski demikian, stroke dapat dicegah dengan melakukan beberapa langkah sederhana. Baca juga: 5 Mitos Keliru Seputar Stroke Untuk mendukung tema tahun ini, WSC memublikasikan beberapa tips untuk menurunkan risiko stroke dalam infografisnya, yaitu Mengontrol tekanan darah tinggi Berolahraga lima kali seminggu Mengonsumsi makanan sehat yang berimbang Menurunkan kolesterol Menjaga berat badan Berhenti merokok dan menghindari lingkungan berasap Menurunkan konsumsi alkohol Mengidentifikasi dan merawat fibrilasi atrial Memerhatikan diabetes Memerhatikan stress dan depresi Melansir dari laman AHA Journal, peringatan ini diinisiasi oleh World Stroke Organization (WSO). WSO adalah sebuah organisasi non pemerintah yang diakui oleh World Health Organisation (WHO) untuk merepresentasikan stroke. WSO memiliki peran penting dalam menginformasikan dan mengoordinasikan aktivitas-aktivitas global untuk menangani masalah stroke, yang tergolong dalam noncommunicable diseases (NCDs).\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Hari Stroke Sedunia 2019: Don't Be The One\", https://www.kompas.com/tren/read/2019/10/29/054800065/hari-stroke-sedunia-2019--don-t-be-the-one.\n" +
                    "Penulis : Vina Fadhrotul Mukaromah\n" +
                    "Editor : Inggried Dwi Wedhaswary Aksi-aksi global untuk menurunkan risiko stroke juga dinilai akan berpengaruh terhadap penyakit penyakit NCDs lainnya yang memiliki faktor-faktor risiko umum seperti penyakit jantung, diabetes melitus, dan demensia. Untuk itu, koordinasi dan kolaborasi antara seluruh pihak yang relevan sangat penting dilakukan. Pihak-pihak itu di antaranya PBB, agensi-agensi di PBB, pemerintah (terutama Kementerian Kesehatan), dan lembaga non pemerintah lainnya yang relevan (WSO, World Heart Federation, World Federation of Neurologiy, NCD Alliance). Dalam upaya merangkul sebanyak mungkin pihak, terutama di negara-negara berkembang (bukan negara maju), WSO mengadakan kampanye bertajuk peringatan tahunan, yakni Hari Stroke Sedunia setiap 29 Oktober. WSO didirikan pertama kali pada 29 Oktober 2006 pada Kongres Regional World Stroke di Cape Town, Afrika Selatan. Organisasi ini merupakan gabungan dari International Stroke Society dan World Stroke Federation. Baca juga: Kenali Stroke, Gejala, Efek, dan Faktor Penyebabnya Jadi, selain mengampanyekan kesadaran akan stroke, digelar pula peringatan terbentuknya organisasi yang memerhatikan stroke tersebut setiap 29 Oktober. Kampanye Hari Stroke Sedunia dilakukan dalam upaya menurunkan jumlah kematian, disabilitas, dan dampak-dampak lain dari stroke. Selain itu, mengedukasi soal serangan iskemik transien melalui pencegahan, perawatan, dan dukungan yang lebih baik. WSO juga memfasilitasi kampanye-kampanye lokal dengan publikasi, coverage media sosial, dan materi-materi yang dapat digunakan untuk para profesional lokal di bidang stroke, aktivis, maupun organisasi pendukung stroke.\n" +
                    "\n" +
                    "Artikel ini telah tayang di Kompas.com dengan judul \"Hari Stroke Sedunia 2019: Don't Be The One\", https://www.kompas.com/tren/read/2019/10/29/054800065/hari-stroke-sedunia-2019--don-t-be-the-one?page=2.\n" +
                    "Penulis : Vina Fadhrotul Mukaromah\n" +
                    "Editor : Inggried Dwi Wedhaswary");
        }else if(tanggal.equalsIgnoreCase("Tanggal 30 Oktober: Hari Keuangan[40]")){
            infoBulan.setText(" BEKASI, DAKTA.COM - Hari Oeang Republik Indonesia (ORI) jatuh pada tanggal 30 oktober dan sudah diperingati sejak tahun 1946 sesuai dengan keputusan wakil presiden pertama RI Mohammad Hatta.\n" +
                    " \n" +
                    "Ketika resmi beredar pada 30 Oktober 1946, ORI tampil dalam bentuk uang kertas bernominal satu sen dengan gambar muka keris terhunus dan gambar belakang teks UUD 1945. \n" +
                    " \n" +
                    "ORI ditandatangani Menteri Keuangan saat itu A.A. Maramis. Pada hari itu juga dinyatakan bahwa uang Jepang dan uang Javasche Bank tidak berlaku lagi. ORI pertama dicetak oleh Percetakan Canisius dengan desain sederhana dengan dua warna dan memakai pengaman serat halus.\n" +
                    " \n" +
                    "Presiden Soekarno menjadi tokoh yang paling sering tampil dalam desain uang kertas ORI dan uang kertas Seri ORI II yang terbit di Yogyakarta pada 1 Januari 1947, Seri ORI III di Yogyakarta pada 26 Juli 1947, Seri ORI Baru di Yogyakarta pada 17 Agustus 1949, dan Seri Republik Indonesia Serikat (RIS) di Jakarta pada 1 Januari 1950.\n" +
                    " \n" +
                    "Meski masa peredaran ORI cukup singkat, tetapi ORI telah diterima di seluruh wilayah Republik Indonesia dan ikut menggelorakan semangat perlawanan terhadap penjajah. \n" +
                    " \n" +
                    "Pada Mei 1946, saat suasana di Jakarta genting, maka Pemerintah RI memutuskan untuk melanjutkan pencetakan ORI di daerah pedalaman, seperti di Yogyakarta, Surakarta, dan Malang.\n" +
                    " \n" +
                    "Namun peredaran ORI tersebut sangat terbatas dan tidak mencakup seluruh wilayah Republik Indonesia. Di Sumatra yang beredar adalah mata uang Jepang. Pada 8 April 1947 Gubernur Provinsi Sumatra mengeluarkan rupiah URIPS-Uang Republik Indonesia Provinsi Sumatra.\n" +
                    " \n" +
                    "Melihat sejarah ORI yang cukup panjang ini, Kantor Wilayah (Kanwil) Direktorat Jendral Pajak (DJP) Jawa Barat II memaknai Hari Oeang Republik Indonesia sebagai alat pemersatu bangsa sekaligus sebagai lambang identitas kemerdekaan dan kedaulatan Indonesia di mata dunia.\n" +
                    " \n" +
                    "\"Makna peringatan Hari Oeang bagi Direktorat Jenderal Pajak, adalah Oeang milik seluruh rakyat Indonesia terlebih bagi insan-insan pengelola uang. Masyarakat masih sedikit salah persepsi yang menganggap tanggal 30 Oktober adalah hari Kementerian Keuangan, padahal yang kita rayakan adalah hari uang. Seluruh masyarakat Indonesia berhak untuk merayakannya,\" jelas Kepala Kanwil DJP Jabar II, Drs. Yoyok Satiotomo, MA saat Talkshow Ngobrol Bareng Pak Yoyok atau NGOPYOK di Radio Dakta, Selasa (29/10).\n" +
                    " \n" +
                    "Yoyok menekankan, memaknai Hari Oeang Republik Indonesia harus benar-benar merasakan bahwa uang itu berasal dari rakyat dan harus dijaga. Pemerintah menjaga uang agar dapat terus menjadi kebanggaan rakyat dan mempunyai kemampuan untuk menjadi daya tukar. \n" +
                    " \n" +
                    "\"Kita pernah mengenal Gerakan Cinta Rupiah, selain itu juga dengan adanya ORI mewujudkan kedaulatan dan alat pemersatu bangsa yang ditandai atas Rahmat Allah berupa Kemerdekaan,\" ucapnya. \n" +
                    " \n" +
                    "Peringatan Hari Oeang tahun 2019 ini merupakan yang ke-73 tahun, bertema \"Maju Bersama Hadapi Tantangan.\" \n" +
                    " \n" +
                    "Menurutnya, tema itu diambil karena dunia saat ini sedang dalam tantangan ekonomi dalam kondisi yang tidak mudah dengan perkembangan geopolitik, pelemahan di emerging market bahkan beberapa telah mengalami krisis dan bisa berimbas ke dalam negeri.\n" +
                    " \n" +
                    "Kepala Bidang Penyuluhan, Pelayanan dan Humas Kanwil DJP Jabar II, Dwi Amiarsih menyampaikan, dalam memperingati Hari Oeang Republik Indonesia, Kanwil DJP Jabar II telah menyelenggarakan beberapa kegiatan, seperti donor darah, bakti sosial, porseni antar unit eselon I di masing-masing wilayah kantor vertikal, serta upacara sebagai puncak rangkaian kegiatan dimana pada saat upacara wajib mengenakan pakaian daerah.\n" +
                    " \n" +
                    "Sementara itu, berkaitan dengan memaknai Hari Oeang Republik Indonesia dengan menumbuhkan rasa cinta kita kepada negara Indonesia, membayar pajak juga merupakan bentuk keterlibatan masyarakat dalam membangun negeri.\n" +
                    " \n" +
                    "\"Untuk itu, Direktorat Jenderal Pajak membuat regulasi kepada wajib pajak dalam hal setoran pajak, maka wajib pajak harus menyetor dalam mata uang rupiah walaupun transaksinya dengan mata uang asing,\" papar Dwi Amiarsih. ");
        }
    }
}