package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.widget.TextView;

public class HasilSeptember extends AppCompatActivity {
    String SEPTEMBER;
    TextView infoBulan;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hasil_september);
        // ambil textview info di acivity_hasil1
        infoBulan=(TextView) findViewById(R.id.info_september);

        // ambil parameter nama_negara dari intent
        Intent intent = getIntent();
        SEPTEMBER = intent.getStringExtra("september");

        // panggil setInfo(String negara) dan tampilkan ibukotanya
        setSEPTEMBER(SEPTEMBER);
    }
    private void setSEPTEMBER(String tanggal) {
        if(tanggal.equalsIgnoreCase("Tanggal 1 September: Hari Buruh")){
            infoBulan.setText("Hari Buruh pada umumnya dirayakan pada tanggal 1 Mei, dan dikenal dengan sebutan May Day.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 1 September: Hari Polisi Wanita (Polwan)")){
            infoBulan.setText("Polisi wanita (disingkat polwan) adalah satuan polisi khusus yang berjenis kelamin wanita. Sejarah kelahiran Polisi Wanita (Polwan) di Indonesia tak jauh berbeda dengan proses kelahiran Polisi Wanita di negara lain, yang bertugas dalam penanganan dan penyidikan terhadap kasus kejahatan yang melibatkan kaum wanita baik korban maupun pelaku kejahatan.\n" +
                    "\n" +
                    "Polwan di Indonesia lahir pada 1 September 1948, berawal dari kota Bukittinggi, Sumatera Barat, tatkala Pemerintahan Darurat Republik Indonesia (PDRI) menghadapi Agresi Militer Belanda II, dimana terjadinya pengungsian besar-besaran pria, wanita, dan anak-anak meninggalkan rumah mereka untuk menjauhi titik-titik peperangan. Untuk mencegah terjadinya penyusupan, para pengungsi harus diperiksa oleh polisi, namun para pengungsi wanita tidak mau diperiksa apalagi digeledah secara fisik oleh polisi pria.[1]\n" +
                    "\n" +
                    "Untuk mengatasi masalah tersebut, Pemerintah Indonesia menunjuk SPN (Sekolah Polisi Negara) Bukittinggi untuk membuka \"Pendidikan Inspektur Polisi\" bagi kaum wanita. Setelah melalui seleksi terpilihlah 6 (enam) orang gadis remaja yang kesemuanya berdarah Minangkabau dan juga berasal dari Ranah Minang,[2] yaitu:\n" +
                    "\n" +
                    "    Mariana Saanin Mufti\n" +
                    "    Nelly Pauna Situmorang\n" +
                    "    Rosmalina Pramono\n" +
                    "    Dahniar Sukotjo\n" +
                    "    Djasmainar Husein\n" +
                    "    Rosnalia Taher\n" +
                    "\n" +
                    "Ke enam gadis remaja tersebut secara resmi tanggal 1 September 1948 mulai mengikuti Pendidikan Inspektur Polisi di SPN Bukittinggi. Sejak saat itu dinyatakan lahirlah Polisi Wanita yang akrab dipanggil Polwan. Keenam Polwan angkatan pertama tersebut juga tercatat sebagai wanita ABRI pertama di tanah air yang kini kesemuanya sudah pensiun dengan rata-rata berpangkat Kolonel Polisi (Kombes).\n" +
                    "\n" +
                    "Tugas Polwan di Indonesia terus berkembang tidak hanya menyangkut masalah kejahatan wanita, anak-anak dan remaja, narkotika dan masalah administrasi bahkan berkembang jauh hampir menyamai berbagai tugas polisi prianya. Bahkan di penghujung tahun 1998, sudah lima orang Polwan dipromosikan menduduki jabatan komando (sebagai Kapolsek). Hingga tahun 1998 sudah 4 orang Polwan dinaikkan pangkatnya menjadi Perwira Tinggi berbintang satu.\n" +
                    "\n" +
                    "Kenakalan anak-anak dan remaja, kasus perkelahian antar pelajar yang terus meningkat dan kasus kejahatan wanita yang memprihatinkan dewasa ini adalah tantangan amat serius Korps Polisi Wanita untuk lebih berperan dan membuktikan eksistensinya di tubuh Polri. Hingga saat ini juga sudah ada Polwan yang memegang jabatan sebagai Kapolres. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 8 September: Hari Aksara")){
            infoBulan.setText("Hari Literasi Internasional (International Literacy Day/ILD) atau Hari Aksara Internasional/Sedunia atau Hari Melek Huruf Internasional, yang diperingati setiap tanggal 8 September, merupakan hari yang diumumkan oleh UNESCO pada 17 November 1965 sebagai peringatan untuk menjaga pentingnya melek huruf bagi setiap manusia, komunitas, dan masyarakat. Setiap tahun, UNESCO mengingatkan komunitas internasional untuk selalu dalam kegiatan belajar. Hari Melek Huruf Internasional ini diperingati oleh seluruh negara di dunia.[1]\n" +
                    "\n" +
                    "Sebanyak 775 juta penduduk dewasa masih buta huruf; dua per tiga di antaranya adalah wanita.[2] Sebanyak 60,7 juta anak-anak masih tidak bersekolah dan sisanya dikeluarkan atau putus di tengah jalan.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 8 September: Hari Pamong Praja")){
            infoBulan.setText("Sendangsari (9/9/2019) – Hari ini, 8 September, adalah hari Pamong Praja. Tidak banyak orang yang mengenal apa itu Pamong Praja. Tapi orang sangat mengenal apa itu SatPol PP, dengan urusan ketertiban dan gusur menggusur rakyat kecil. Terlepas dari kontroversi itu, dewasa ini negara sangat membutuhkan sosok Pamong Praja yang handal dan humanis serta mengerti tugasnya sebagai abdi negara. Dalam bahasa kerennya menjadi eksekutif yang profesional dalam menjalankan tugas negara.\n" +
                    "\n" +
                    "Tahun ini, tepatnya bulan Agustus lalu, Institut Pemerintahan Dalam Negeri (IPDN) baru saja meluluskan 1.921 Pamong Praja Muda. Pengukuhan kelulusan tersebut dilakukan langsung oleh Presiden Joko Widodo di kampus IPDN Jatinangor, Sumedang, Jawa Barat. Dalam acara pengukuhan itu, Presiden meminta agar para Pamong Praja menjadi yang terbaik dalam tugas mereka serta mampu mengimplementasikan Revolusi Mental dalam pengabdiannya, dan menjadi teladan bagi rakyat dalam membangun sikap yang optimis dan inovatif.\n" +
                    "\n" +
                    "Sementara Menteri Dalam Negeri, Tjahjo Kumolo, menjamin bahwa para Pamong Praja lulusan IPDN kali ini telah memenuhi standar kualifikasi. Bahkan, sejak awal telah dilakukan perekrutan melalui sistem online dan bebas dari praktik kolusi. Terlebih, ada tujuh instansi yang dilibatkan dalam proses itu, yakni KPK, Kementerian PAN RB serta BKN, Dinas Kesehatan dan Kesamaptaan TNI, Dinas Psi AD serta Pemerintah Daerah.\n" +
                    "\n" +
                    "Seperti diketahui, pamong praja sudah menjadi bagian dari perjalanan panjang sejarah pemerintahan Indonesia khususnya pemerintahan daerah. Peraturan Presiden Nomor 1 Tahun 2009 memberikan ruang dan peluang untuk eksisnya pamong praja dengan diadakannya Pendidikan Tinggi Kepamongprajaan yang lulusannya dipersiapkan untuk menjadi “pekerja kepamongan” yakni menjadi pamong praja.\n" +
                    "\n" +
                    "Secara historis keberadaan korps pamong praja sudah ada sejak zaman Hindia Belanda sebagai korps binnenlands bestuur, yakni korps pejabat bumiputera yang bertugas menjaga kepentingan kerajaan Belanda di tanah Nusantara. Pada masa awal kemerdekaan, korps ini dinamakan Korps Pangreh Praja, yang kemudian diubah menjadi Korps Pamong Praja.\n" +
                    "\n" +
                    "Berdasarkan UU Nomor 5 Tahun 1974 tentang Pokok-pokok Pemerintahan di Daerah. Korps Pamong Praja diartikan sebagai pejabat pemerintah pusat yang berada di daerah dengan tugas utama menjalankan Tugas Pemerintahan Umum (TPU), yang meliputi koordinasi, pembinaan dan pengawasan serta urusan residual.\n" +
                    "\n" +
                    "Setelah reformasi, dengan terbitnya UU Nomor 22 Tahun 1999 tentang Pemerintahan Daerah, fungsi pamong praja menjadi sangat terbatas karena fungsi dekonsentrasi hanya berada pada tingkat provinsi. Sedangkan UU 22/99 sangat desentralistik menyangkut otonomi daerah.\n" +
                    "\n" +
                    "Setelah keluarnya UU Nomor 32 Tahun 2004, pengertian Tugas Pemerintahan Umum, diganti dengan istilah baru yakni Tugas Umum Pemerintahan (TUP), yang isinya jauh berbeda dengan pengertian Tugas Pemerintahan Umum (TPU) yang selama ini digunakan. Bila merujuk pada peraturan perundang-undangan maka yang masuk kategori Korps Pamong Praja adalah mereka yang dididik secara khusus untuk melayani masyarakat serta konsisten menjaga keutuhan bangsa dan negara. Dalam bentuk jabatan-jabatan, sebutan pamong praja ditujukan antara lain para Lurah, Camat, Polisi Pamong Praja, Asisten Sekda, serta Sekretaris Daerah, ditambah dengan SKPG (Satuan Kerja Perangkat Gubernur) sebagai tindak lanjut dari PP Nomor 19 Tahun 2010.(S-Dw) Sumber : nusantaranews.co");
        }else if(tanggal.equalsIgnoreCase("Tanggal 9 September: Hari Olahraga Nasional[25]")){
            infoBulan.setText("Jakarta - Hari Olahraga Nasional diperingati setiap tanggal 9 September atau hari ini. Nah, apa saja sih fakta menarik dari perayaan Hari Olahraga Nasional? Yuk simak.\n" +
                    "\n" +
                    "Hari Olahraga Nasional 2019 kali ini diperingati dengan perayaan Haornas di Banjarmasin, Kalimantan Selatan. Perayaan ini diinisiasi oleh Kementerian Pemuda dan Olahraga.\n" +
                    "\n" +
                    "Baca juga:\n" +
                    "HUT Ke-52, Perwosi: Perempuan Harus Jadi Motivator untuk Olahraga\n" +
                    "\n" +
                    "\n" +
                    "Berikut fakta-fakta perayaan Hari Olahraga Nasional yang dirangkum detikcom dari berbagai sumber:\n" +
                    "\n" +
                    "1. Perayaan di Banjarmasin\n" +
                    "\n" +
                    "Hari Olahraga Nasional ke-36 ini diperingati dengan perayaan yang digelar di Sungai Siring Menara Pandang, kota Banjarmasin. Perayaan berlangsung ramai dan meriah.\n" +
                    "\n" +
                    "2. Rekor MURI\n" +
                    "\n" +
                    "Untuk menambah meriah perayaan Hari Olahraga Nasional, diadakan juga pemecahan rekor Museum Rekor Indonesia (MURI) peserta terbanyak gerakan karate. Tercatat, ada 5.500 karateka yang mengikuti kegiatan.\n" +
                    "\n" +
                    "3. Disaksikan Ribuan Orang\n" +
                    "\n" +
                    "Perayaan yang mengambil tema 'Ayo Olahraga Di Mana Kapan Saja' ini berlangsung meriah. Bahkan, puncak acara yang berlangsung Minggu (8/0/2019) itu disaksikan hingga ribuan orang.\n" +
                    "\n" +
                    "Baca juga:\n" +
                    "Hari Olahraga Nasional, Anies Ajak Warga Jalan Kaki Manfaatkan Angkutan Umum\n" +
                    "\n" +
                    "\n" +
                    "4. Parade Perayaan Air\n" +
                    "\n" +
                    "Berbagai atraksi olahraga air juga ikut menyemarakkan acara perayaan Hari Olahraga Nasional. Mulai dari jetski, flyboard, hingga perahu jukung memeriahkan acara.\n" +
                    "\n" +
                    "5. Penghargaan\n" +
                    "\n" +
                    "Perayaan Hari Olahraga Nasional juga menjadi kesempatan Kemenpora membagikan penghargaan kepada 91 pelaku olahraga. Pelaku olahraga itu mulai dari cabang tenis, menembak, hingga e-sport. (pay/nwy)\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 11 September: Hari Radio Republik Indonesia (RRI)")){
            infoBulan.setText("Indonesiabaik.id - Setiap tanggal 11 September diperingati sebagai Hari Radio Nasional. Ditanggal yang sama itu juga diperingati sebagai hari kelahiran Radio Republik Indonesia (RRI) yang didirikan pada 11 September 1945, maka tidak heran jika tanggal 11 September juga sering disebut sebagai Hari RRI.\n" +
                    "\n" +
                    "Perkembangan radio di Indonesia diawali oleh Batavia Radio Vereniging (BRV) pada 16 Juni 1925 di Batavia (kini Jakarta). Seiring berjalannya waktu, radio terus berkembang dan bermunculan. Nederlandsch Indische Radio Omroep Masstchapyj (NIROM) mulai berdiri di Jakarta, Bandung dan Medan.\n" +
                    "\n" +
                    "Setelah Jepang mengambil alih Indonesia, radio-radio siaran Jepang mulai berkumandang di Tanah Air. Selain untuk memberikan informasi, siaran radio juga sebagai propaganda Jepang untuk Indonesia. Bom Hiroshima dan Nagasaki menjadi tanda runtuhnya Jepang atas Indonesia. Berkat informasi radio, akhirnya Indonesia bisa segera merealisasikan kemerdekaanya melalui momentum proklamasi. Akhirnya Hoso Kyoku dihentikan siarannya tanggal 19 Agustus 1945.\n" +
                    "\n" +
                    "RRI didirikan sebulan setelah siaran radio Hoso Kyoku dihentikan tanggal 19 Agustus 1945. Saat itu, masyarakat menjadi buta akan informasi dan tidak tahu apa yang harus dilakukan setelah Indonesia merdeka. Menanggapi hal tersebut, orang-orang yang pernah aktif di radio pada masa penjajahan Jepang menyadari radio merupakan alat yang diperlukan oleh pemerintah Republik Indonesia untuk berkomunikasi dan memberi tuntunan kepada rakyat mengenai apa yang harus dilakukan.\n" +
                    "\n" +
                    "Wakil-wakil dari 8 bekas radio Hosu Kyoku mengadakan pertemuan bersama pemerintah di Jakarta.\n" +
                    "Pada 11 September 1945 pukul 17.00, delegasi radio sudah berkumpul di bekas gedung Raad Van Indje Pejambon dan diterima sekretaris negara. Delegasi radio yang saat itu mengikuti pertemuan adalah Abdulrahman Saleh, Adang Kadarusman, Soehardi, Soetarji Hardjolukita, Soemarmadi, Sudomomarto, Harto dan Maladi.\n" +
                    "\n" +
                    "Abdulrahman Saleh yang menjadi ketua delegasi menguraikan garis besar rencana pada pertemuan tersebut. Salah satunya adalah mengimbau pemerintah untuk mendirikan radio sebagai alat komunikasi antara pemerintah. Pada pukul 24.00, delegasi dari 8 stasiun radio di Jawa mengadakan rapat di rumah Adang Kadarusman. Hasil akhir dari rapat itu adalah didirikannya RRI dengan Abdulrachman Saleh sebagai pemimpinnya.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 11 September: Hari Peringatan Serangan 11 September 2001")){
            infoBulan.setText("Serangan 11 September (ing basa Inggris uga diarani September 11, utawa 9/11 (diwaca nine one one, utawa nine eleven)), iku sawijining rerangkèn saka patang seranganbunuh diri marang Amérikah Sarékat ing New York City lan Washington, D.C. ing 11 September 2001. Ing dina iku, 19 téroris saka grup militan Al-Qaeda mbajak patang montor mabur panumpang. Montor mabur loro ditabrakaké World Trade Center ing New York City nganti loro-loroné ambruk. Banjur ana montor mabur siji sing ditabrakaké marang Pentagon. Pentagon rusak nanging ora nganti ambruk total. Banjur ana montor mabur siji (United Airlines Pamaburan 93) sing tiba ing ara-ara tegal ing Shanksville, Pennsylvania. Montor mabur iki sajatiné arep ditabrakaké para téroris ing Washington D.C., nanging para durjana iki gagal amarga dilawan para panumpang. Mèh 3.000 jiwa wong tiwas ing patang serangan iki.\n" +
                    "\n" +
                    "Pamaréntah Amérikah Sarékat banjur agé nudhuh al-Qaéda minangka dhalangé, lan ing taun 2004, Osama bin Laden minangka pamimpiné, pancèn ngaku manawa al-Qaéda sing tanggungjawab. Wiwitané dhèwèké sélak. Osama minangka alesané nyatakaké manawa panyengkuyung A.S. marang Israèl, anané militèr A.S. ing Arab Saudi lan sanksi ékonomi marang Irak sing dadi dhasaré serangan iki.\n" +
                    "\n" +
                    "A.S. nanggepi serangan iki mawa operasi \"Perang Marang Térorisme\" (War on Terror) lan agé nyerang Afghanistan amarga pamaréntahan Taliban ing nagara iki sing ngreksa lan mènèhi pondhokan kanggo al-Qaéda. Akèh nagara banjur nggawé undhang-undhang anti-térorisme dadi sangsaya raket. Osama bin Laden dhéwé pungkasané dipatèni militèr A.S. ing Mèi 2011 ing Pakistan. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 17 September: Hari Palang Merah Indonesia")){
            infoBulan.setText("Palang Merah Indonesia (PMI) adalah sebuah organisasi perhimpunan nasional di Indonesia yang bergerak dalam bidang sosial kemanusiaan.[1]\n" +
                    "\n" +
                    "PMI selalu mempunyai tujuh prinsip dasar Gerakan Internasional Palang Merah dan Bulan sabit merah yaitu kemanusiaan, kesamaan, kesukarelaan, kemandirian, kesatuan, kenetralan, dan kesemestaan. Sampai saat ini PMI telah berada di 34 PMI Daerah (tingkat provinsi) dan sekitar 408 PMI Cabang (tingkat kota/kabupaten) di seluruh Indonesia.[1]\n" +
                    "\n" +
                    "Palang Merah Indonesia tidak memihak golongan politik, ras, suku ataupun agama tertentu. Palang Merah Indonesia dalam pelaksanaannya juga tidak melakukan pembedaan tetapi mengutamakan korban yang paling membutuhkan pertolongan segera untuk keselamatan jiwanya. ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 17 September: Hari Perhubungan Nasional")){
            infoBulan.setText("\n" +
                    "HARI PERHUBUNGAN NASIONAL 2019\n" +
                    "\n" +
                    "Hari Perhubungan Nasional, atau biasa disingkat Harhubnas adalah hari yang diperingati tiap tanggal 17 September setiap tahunnya. Hari perhubungan nasional ini pertama kali ditetapkan pada tahun 1971 melalui keputusan Menteri Perhubungan Nomor SK.274/G/1971. Surat Keputusan yang diterbitkan pada tanggal 26 Agustus 1971 ini mengatur mengenai peringatan hari perhubungan nasional.\n" +
                    "\n" +
                    "Hari perhubungan nasional ini ditetapkan untuk memperingati hari bakti dari setiap BUMN yang bergerak di sektor perhubungan. Sebelum ditetapkannya hari perhubungan nasional, setiap BUMN yang bergerak di sektor perhubungan merayakan hari jadi atau hari bakti mereka masing-masing di tanggal yang berbeda dan berdekatan. Mempertimbangkan waktu dan biaya, perayaan yang berdekatan untuk merayakan hal yang nyaris sama dianggap tidak efisien. Oleh karena itu, pada tahun 1971 ditetapkan peringatan hari perhubungan nasional untuk menyatukan peringatan hari bakti seluruh BUMN yang bergera di bidang transportasi.\n" +
                    "\n" +
                    "Walikota Manado G.S Vicky Lumentut dan Wakil Walikota Mor D Bastiaan, bersama seluruh jajaran pemerintah kota manado mengucapkan selamat Hari Perhubungan Nasional 17 September 2019.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 21 September: Hari Perdamaian Dunia[26]")){
            infoBulan.setText("TRIBUNNEWS.COM - SEJARAH HARI INI, 37 tahun silam diresmikan sebagai Hari Perdamaian Internasional ( International Day of Peace) atau disebut juga Hari Perdamaian Dunia (World Peace Day).\n" +
                    "\n" +
                    "Peringatan Hari Perdamaian Internasional diperingati setiap tahun pada tanggal 21 September.\n" +
                    "\n" +
                    "Hari Perdamaian Internasional atau Hari Perdamaian Dunia didedikasikan demi perdamaian dunia dan secara khusus demi berakhirnya perang dan kekerasan.\n" +
                    "\n" +
                    "Diperingati pertama kali pada tahun 1982, Hari Perdamaian Internasional dipertahankan oleh banyak negara, kelompok politik, militer dan masyarakat.\n" +
                    "\n" +
                    "Tanggal 21 September ini ditetapkan oleh Majelis Umum PBB melalui Resolusi Nomor 55/282 pada tahun 1991.\n" +
                    "\n" +
                    "Pada tahun 2013, untuk pertama kalinya Hari Perdamaian Internasional didedikasikan oleh Sekretaris Jenderal PBB untuk pendidikan perdamaian, sebagai sarana pencegahan yang penting untuk mengurangi peperangan yang berkelanjutan.\n" +
                    "\n" +
                    "Dilansir dari Kompas.com, tujuan awal dari dibentuknya Hari Perdamaian Internasional adalah untuk memperkuat cita-cita perdamaian di antara bangsa-bangsa di seluruh dunia.\n" +
                    "\n" +
                    "Negara-negara anggota PBB berkeyakinan perdamaian tidak akan tercipta jika langkah-langkah untuk mencapai pemerataan pembangunan ekonomi dan sosial tidak dilakukan, dan hak setiap orang tidak mendapat perlindungan.\n" +
                    "\n" +
                    "Hak asasi manusia adalah hak semua orang.\n" +
                    "\n" +
                    "Untuk itu, prinsip-prinsip pembangunan berkelanjutan, yang mencakup isu kemiskinan, kelaparan, pendidikan, perubahan iklim, persamaan gender, persedian air, sanitasi, energi, lingkungan, dan keadilan sosial, perlu diaplikasikan.\n" +
                    "\n" +
                    "Berbagai perayaan digelar di berbagai tempat di dunia untuk memperingati Hari Perdamaian Internasional ini.\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di Tribunnews.com dengan judul SEJARAH HARI INI: 21 September Hari Perdamaian Internasional Digaungkan, Perubahan Iklim Disoroti, https://www.tribunnews.com/nasional/2019/09/21/sejarah-hari-ini-21-september-hari-perdamaian-internasional-digaungkan-perubahan-iklim-disoroti.\n" +
                    "\n" +
                    "Editor: ade mayasanto ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 23 September: Hari Bahasa Isyarat Internasional")){
            infoBulan.setText("TRIBUNNEWS.COM - Sejarah Hari Ini, bertepatan dengan Hari Bahasa Isyarat Internasional yang jatuh setiap 23 September.\n" +
                    "\n" +
                    "Apa itu Hari Bahasa Isyarat Internasional?\n" +
                    "\n" +
                    "Peringatan Hari Bahasa Isyarat Internasional baru saja ditetapkan oleh PBB pada 23 September 2017 lalu.\n" +
                    "\n" +
                    "Hari Bahasa Isyarat Internasional ditetapkan pada tanggal tersebut karena bertepatan dengan kongres pertama tuli dunia yang jatuh pada 23 September tahun 1951 di Italia, dan merupakan hasil diskusi dari World Federation of the Deaf dan PBB.\n" +
                    "\n" +
                    "Peringatan ini bertujuan agar para difabel khusunya orang tuli mendapatkan hak yang sama seperti warga lainnya salah satunya hak mendapatkan informasi.\n" +
                    "\n" +
                    "Di Indonesia, beberapa stasiun televisi telah melengkapi siaran berita dengan bahasa isyarat yang bisa dilihat oleh orang-orang tuli.\n" +
                    "\n" +
                    "Namun, meskipun hari ini diperingati sebagai Hari Bahasa Insyarat Internasional, pada kenyataannya belum ada bahasa isyarat internasional yang sukses diterapkan.\n" +
                    "\n" +
                    "Bahasa isyarat unik dalam jenisnya di setiap negara.\n" +
                    "\n" +
                    "Bahasa isyarat bisa saja berbeda di negara-negara yang berbahasa sama.\n" +
                    "\n" +
                    "Contohnya, Amerika Serikat dan Inggris meskipun memiliki bahasa tertulis yang sama, mereka memiliki bahasa isyarat yang sama sekali berbeda (American Sign Language dan British Sign Language).\n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di Tribunnews.com dengan judul SEJARAH HARI INI: Hari Bahasa Isyarat Internasional 23 September, Yuk Belajar Bahasa Isyarat!, https://www.tribunnews.com/nasional/2019/09/23/sejarah-hari-ini-hari-bahasa-isyarat-internasional-23-september-yuk-belajar-bahasa-isyarat.\n" +
                    "\n" +
                    "Editor: ade mayasanto ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 24 September: Hari Tani")){
            infoBulan.setText("Jakarta - Setiap tanggal 24 September diperingati sebagai Hari Tani Nasional? Ada sejarah penting sebelum disahkan melalui Kepres RI No. 169 tahun 1963.\n" +
                    "\n" +
                    "Hari Tani Nasional merupakan bentuk peringatan dalam mengenang sejarah perjuangan kaum petani serta membebaskannya dari penderitaan. Oleh karena itu ditetapkan Hari Tani ini, yang diambil dari tanggal dikeluarkannya Undang-Undang Pokok Agraria (UUPA) pada tahun 1960.\n" +
                    "\n" +
                    "Kemudian hari tersebut menjadi tonggak sejarah bangsa dalam memandang arti penting petani dan hak kepemilikan atas tanah, serta keberlanjutan masa depan agraria di Indonesia. Kepedulian negara terhadap hidup rakyatnya, terutama kehidupan para petani mulai diwujudkan. Mengingat Indonesia adalah negara agraris dan mayoritas rakyatnya adalah petani.\n" +
                    "\n" +
                    "Berikut sejarah Hari Tani Nasional yang dirangkum detikFinance:\n" +
                    "\n" +
                    "Baca juga: Nasib Petani di Tengah Reforma Agraria Jokowi\n" +
                    "\n" +
                    "\n" +
                    "1. Awal Perjuangan\n" +
                    "\n" +
                    "Sejak lepas dari cengkraman Belanda, pemerintah Indonesia selalu berusaha merumuskan UU Agraria baru untuk mengganti UU Agraria kolonial.\n" +
                    "\n" +
                    "Pada tahun 1948, ketika itu ibu kota Republik Indonesia (RI) berkedudukan di Yogyakarta. Penyelenggara negara membentuk panitia agraria Yogya. Namun, akibat gejolak politik, usaha itupun kandas.\n" +
                    "\n" +
                    "Setelah diadakan Konferensi Meja Bundar (KMB) pada 27 Desember 1949 dan persetujuan antara Republik Indonesia dengan Belanda, atas pengakuan kedaulatan politik Negara Indonesia, maka ibukota RI kembali ke Jakarta.\n" +
                    "\n" +
                    "Kemudian, Panitia Agraria Yogya diteruskan di Jakarta pada tahun 1951, dengan nama Panitia Agraria Jakarta. Dalam perkembangannya, berbagai panitia yang telah terbentuk, gagal dan tersendat-sendat. Panitia Agraria Jakarta yang sempat mandeg diteruskan oleh Panitia Soewahjo (1955), Panitia Negara Urusan Agraria (1956), Rancangan Soenarjo (1958) dan Rancangan Sadjarwo (1960).\n" +
                    "\n" +
                    "2. Membersihkan Sisa-sisa Kolonial\n" +
                    "\n" +
                    "Belanda yang masih tidak rela melepaskan wilayah Irian Barat, terus mengulur penyelesaian. Hal ini kemudian membuat Indonesia memberikan tindakan tegas dengan membatalkan perjanjian KMB secara sepihak pada tahun 1956. Diikuti dengan nasionalisasi perkebunan-perkebunan asing.\n" +
                    "\n" +
                    "Pemerintah RI kemudian mengeluarkan UU No 1 tahun 1958, tentang penghapusan tanah-tanah partikelir. Tanah tersebut oleh penguasa kolonial disewakan atau dijual kepada orang-orang kaya, dengan disertai hak-hak pertuanan (landheerlijke rechten). Hak pertuanan artinya sang tuan tanah berkuasa atas tanah, beserta orang-orang di dalamnya. Misalnya, hak mengangkat dan memberhentikan kepala desa, menuntut rodi atau uang pengganti rodi, dan mengadakan pungutan-pungutan. Hak dipertuanan itu seperti negara dalam negara.\n" +
                    "\n" +
                    "Dengan UU No 1 tahun 1958 itu, hak-hak pertuanan hanya boleh dimiliki oleh negara. Kemudian upaya mengambil alih lahan asing ke tangan rakyat atau petani (https://www.detik.com/tag/petani), dilakukan dengan ganti rugi. Artinya, reforma agraria dikoordinasikan oleh pemerintah dengan cara ganti rugi untuk meminimalisasi adanya konflik.\n" +
                    "\n" +
                    "3. Rancangan Undang-undang Pembaruan Agraria\n" +
                    "\n" +
                    "Tibalah masa penantian selama 12 tahun, melalui prakarsa Menteri Pertanian 1959, Soenaryo. Rancangan Undang-Undang itu digodok Dewan Perwakilan Rakyat Gotong Royong (DPR-GR) yang kala itu dipimpin Zainul Arifin.\n" +
                    "\n" +
                    "Pada sidang DPR-GR tanggal 12 September 1960, Menteri Agraria saat itu, Mr Sardjarwo dalam pidato pengantarnya menyatakan, \"...perjuangan perombakan hukum agraria nasional berjalan erat dengan sejarah perjuangan bangsa Indonesia untuk melepaskan diri dari cengkraman, pengaruh, dan sisa-sisa penjajahan, khususnya perjuangan rakyat tani untuk membebaskan diri dari kekangan-kekangan sistem feodal atas tanah dan pemerasan kaum modal asing.\"\n" +
                    "\n" +
                    "Kemudian, pada pada 24 September 1960, RUU tersebut disetujui DPR sebagai UU No 5 tahun 1960 tentang Peraturan Dasar Pokok-pokok Agraria, atau dikenal dengan Undang-Undang Pembaruan Agraria (UUPA). UU Pokok Agraria menjadi titik awal dari kelahiran hukum pertanahan yang baru mengganti produk hukum agraria kolonial.\n" +
                    "\n" +
                    "Baca juga: Mentan Siap Kerja 24 Jam untuk Tingkatkan Komoditas Tani\n" +
                    "\n" +
                    "\n" +
                    "4. Prinsip UUPA\n" +
                    "\n" +
                    "UUPA 1960 merupakan payung hukum (Lex Generalis) bagi pengelolaan kekayaan agraria nasional. Kekayaan agraria nasional tersebut mengacu kepada Pasal 33 ayat (3) UUD 1945, yang berbunyi \"bumi dan air dan segala kekayaan yang terkandung di dalamnya, dikuasai oleh Negara dan dipergunakan untuk sebesar-besar kemakmuran rakyat\". Undang-undang ini lahir dari semangat perlawanan terhadap kolonialisme, yang telah merampas hak asasi rakyat Indonesia selama ber-abad-abad melalui Agrariche Wet 1870.\n" +
                    "\n" +
                    "Prinsip UUPA adalah menempatkan tanah untuk kesejahteraan rakyat. UUPA mengatur pembatasan penguasaan tanah, kesempatan sama bagi setiap warga negara untuk memperoleh hak atas tanah, pengakuan hukum adat, serta warga negara asing tak punya hak milik.\n" +
                    "\n" +
                    "Tanggal ditetapkannya UUPA, yakni 24 September. Karena itulah kemudian setiap tanggal itu diperingati sebagai Hari Tani Nasional.\n" +
                    "\n" +
                    "5. Kata-kata Untuk Hari Tani Nasional\n" +
                    "\n" +
                    "Tan Malaka pernah berkata dalam bukunya 'Madilog', \"Bila kaum muda yang telah belajar di sekolah dan menganggap dirinya terlalu tinggi dan terlalu pintar untuk melebur dengan masyarakat yang bekerja dengan cangkul, dan hanya memiliki cita-cita sederhana, maka lebih baik pendidikan itu tidak diberikan sama sekali\".\n" +
                    "\n" +
                    "Selamat Hari Tani Nasional!\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 26 September: Hari Statistik")){
            infoBulan.setText("2 dari 3 halaman\n" +
                    "HUT Badan Pusat Statistik 2019\n" +
                    "Big Data\n" +
                    "Ilustrasi Big Data (iStockphoto)\n" +
                    "\n" +
                    "Berdasarkan latar belakang itulah, kelahiran UU yang terkait BPS menjadi titik awal perjalanan BPS dalam mengisi kemerdekaan di bidang statistik yang selama ini diatur berdasarkan sistem perundang-undangan kolonial.\n" +
                    "\n" +
                    "Kemudian, sebagai langkah awal BPS untuk memeriahkan hari jadinya pada 26 September 2019, pihaknya mengadakan ‘gerak jalan’. Setelah acara itu, Kepala BPS Kota Surabaya Suparno menuturkan internalisasi Sensus Penduduk 2020.\n" +
                    "\n" +
                    "“Dari enam kali pelaksanaan sensus penduduk, tiga sensus penduduk yaitu tahun 1990, 2000, 2010, kami ikut berkontribusi. Kami siap Sensus Penduduk 2020,” kata Suparno, Kepala BPS Kota Surabaya.\n" +
                    "\n" +
                    "Badan Pusat Statistik (BPS) Surabaya menunjukan, jumlah penduduk Kota Surabaya pada 2018 mencapai 3.094.732. Angka tersebut terus mengalami kenaikan dari tahun-tahun yang sebelumnya.\n" +
                    "\n" +
                    "(Wiwin Fitriyani, mahasiswi Universitas Tarumanagara)\n" +
                    "3 dari 3 halaman\n" +
                    "Selanjutnya: Saksikan Video Pilihan di Bawah Ini\n" +
                    "\n" +
                    "    Surabaya\n" +
                    "    Info Surabaya\n" +
                    "    Badan Pusat Statistik (BPS)\n" +
                    "    BPS Surabaya\n" +
                    "    HUT BPS 2019\n" +
                    "    Hari Statistik Nasional\n" +
                    "\n" +
                    "    0%suka\n" +
                    "    0%lucu\n" +
                    "    0%kaget\n" +
                    "    0%sedih\n" +
                    "    0%marah\n" +
                    "\n" +
                    "Kredit\n" +
                    "\n" +
                    "    Liputan Enam\n" +
                    "    Agustina Melani\n" +
                    "\n" +
                    "Bagikan\n" +
                    "\n" +
                    "10\n" +
                    "TOPIK POPULER\n" +
                    "\n" +
                    "    #Berita Surabaya\n" +
                    "    #Surabaya\n" +
                    "    #virus corona\n" +
                    "    #COVID-19\n" +
                    "    #Corona\n" +
                    "\n" +
                    "Populer\n" +
                    "Lihat Semua\n" +
                    "\n" +
                    "    Ilustrasi coronavirus, virus corona, koronavirus, Covid-19. Kredit: Fernando Zhiminaicela via Pixabay\n" +
                    "    1Surabaya\n" +
                    "    Penyebab Angka Kematian karena Corona COVID-19 di Jatim Tinggi\n" +
                    "    2Surabaya\n" +
                    "    Anak Usaha BUMN Pelindo III Buka Lowongan Kerja bagi Lulusan SMK\n" +
                    "    3Surabaya\n" +
                    "    Update Corona COVID-19 di Jatim 14 Juni 2020: Pasien Positif 7.780, Sembuh 2.254 Orang\n" +
                    "    4Surabaya\n" +
                    "    Mengintip Keunikan Masker dari UMKM Tenun Ikat Kediri\n" +
                    "    5Surabaya\n" +
                    "    VIDEO: Seorang Dokter di Puskesmas Pangkur Terpapar COVID-19 dari Klaster Asrama Haji\n" +
                    "    6Surabaya\n" +
                    "    Tes Cepat Hari ke-16 di Surabaya, BIN Temukan 228 Orang Reaktif\n" +
                    "    7Surabaya\n" +
                    "    VIDEO: Pria di Jember Ini Ajak Perangi COVID-19 Melalui Kartun 'Pejuang Santuy'\n" +
                    "    8Surabaya\n" +
                    "    Tambahan Pasien Corona COVID-19 di Jawa Timur Masih Tertinggi pada 14 Juni 2020\n" +
                    "    9Surabaya\n" +
                    "    104 Penumpang Kereta Api di Daop 9 Jember 'Balik Kanan', Mengapa?\n" +
                    "    10Surabaya\n" +
                    "    Total Pasien Sembuh dari Corona COVID-19 di Jatim Tembus 2.192 Orang\n" +
                    "\n" +
                    "\n" +
                    "Berita Terkini\n" +
                    "Lihat Semua\n" +
                    "\n" +
                    "    Suasana sidang perdana kasus penyiraman terhadap penyidik senior KPK Novel Baswedan di Pengadilan Negeri Jakarta Utara, Kamis (19/3/2020). Dua terdakwa, yakni Ronny Bugis dan Rahmat Kadir Mahulete menjalani sidang dengan agenda pembacaan dakwaan oleh Jaksa Penuntut Umum. (merdeka.com/Iqbal Nugroho)\n" +
                    "    Komisi Kejaksaan Monitor Jaksa Kasus Novel Baswedan yang Jadi Sorotan\n" +
                    "    Pemain Mallorca, Takefusa Kubo, menggiring bola saat melawan Barcelona pada laga La Liga di Estadio de Son Moix, Minggu (14/6/2020). Barcelona menang dengan skor 4-0. (AP/Francisco Ubilla)\n" +
                    "    3 Pemain yang Curi Perhatian Saat Barcelona Bantai Mallorca: Salah Satunya dari Jepang\n" +
                    "    Gubernur Jawa Timur Khofifah Indar Parawansa (Foto: Liputan6.com/Dian Kurniawan)\n" +
                    "    Update Corona COVID-19 di Jawa Timur pada 14 Juni 2020\n" +
                    "    Seekor harimau masuk perangkap yang dipasang BKSDA Sumbar di Solok. Kondisi harimau itu sehat dan akan direhabilitasi di PRHS Dharmasraya. (Liputan6.com/ Dok. BKSDA Sumbar)\n" +
                    "    Akhir Nasib Harimau Sumatra yang Keluyuran di Ladang Warga Solok\n" +
                    "    Paramedis Siloam Hospitals menunjukkan hasil tes cepat (rapid test) mandiri COVID-19 secara drive thru di Akses Senayan Park Jalan Gerbang Pemuda, Jakarta, Kamis (23/4/2020). Rapid Tes Covid -19 dibanderol seharga Rp 489.000, periode 17-30 April 2020 pukul 08.00-10.00 WIB. (merdeka.com/Arie Basuki)\n" +
                    "    Bulog Jatim Gelar Tes Cepat Seluruh Karyawan, Ada Apa?\n" +
                    "\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 27 September: Hari Pos Telekomunikasi Telegraf (PTT)")){
            infoBulan.setText("\n" +
                    "\n" +
                    "Tanggal 27 September adalah Hari Pos Telekomunikasi Telegraf (PTT).\n" +
                    "\n" +
                    "Pada saat pemerintahan Jepang di Indonesia, jawatan PTT dikuasai oleh militer Jepang. Angkatan Muda PTT kemudian mengambil alih kekuasaan jawatan PTT tersebut dan kemudian secara resmi berubah menjadi \"Jawatan PTT Republik Indonesia\". Peristiwa tersebut terjadi pada tanggal 27 September 1945 . Hari itupun diperingati sebagai Hari Bakti PTT (Post, Telegraph dan Telephone) yang diperingati hingga saat ini.\n" +
                    "\n" +
                    "Perkembangan pos di Indonesia pun terus terjadi hingga pada Juni 1995 berubah menjadi Perseroan Terbatas dengan nama PT. Pos Indonesia (Persero) seperti yang kita kenal hingga saat ini.\n" +
                    "\n" +
                    "Dengan berjalannya waktu, Pos Indonesia kini telah mampu menunjukkan kreatifitasnya dalam pengembangan pos di Indonesia dengan memanfaatkan insfrastruktur jejaring yang dimilikinya.\n");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 September: Hari Kereta Api")){
            infoBulan.setText("TRIBUNNEWSWIKI.COM – Setiap tanggal 28 Agustus di Indonesia diperingati sebagai Hari Kereta Api Nasional.\n" +
                    "\n" +
                    "Setelah Indonesia menyatakan kemerdekaannya pada 17 Agustus 1945, para pekerja kereta api yang tergabung dalam Serikat Buruh Kereta Api (SBKA) mengambil alih kereta api yang saat itu masih di kuasai Jepang.\n" +
                    "\n" +
                    "Hal tersebut dilatarbelakangi kekahawatiran jika kereta api dimanfaatkan oleh Belanda yang ingin kembali menguasai Indonesia.\n" +
                    "\n" +
                    "Puncaknya terjadi pada 28 September 1945 saat SBKA menduduki Nederlandsch-Indische Spoorweg Maatschappij, Bandung.\n" +
                    "\n" +
                    "Setelah behasil merebut kantor tersebut, para SBKA kemudian meminta persetujuan kepada Abikoesno Tjokrosoejoso, Menteri Perhubungan saat itu untuk mendirikan institusi kereta api milik rakyat Indonesia.\n" +
                    "\n" +
                    "Lalu dibentuklah Djawatan Kereta Api Indonesia Republik Indonesia (DKARI) yang sekarang kita kenal sebagai PT KAI. (1) \n" +
                    "\n" +
                    "\n" +
                    "\n" +
                    "Artikel ini telah tayang di Tribunnews.com dengan judul Hari Ini Dalam Sejarah: 28 September Hari Kereta Api Nasional, https://www.tribunnews.com/nasional/2019/09/28/hari-ini-dalam-sejarah-28-september-hari-kereta-api-nasional.\n" +
                    "\n" +
                    "Editor: Melia Istighfaroh ");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 September: Hari Komunitas Nasional")){
            infoBulan.setText("JAKARTA - Menteri Komunikasi dan Informatika (Menkominfo) Tifatul Sembiring hari ini mendeklarasikan sebagai Hari Komunitas Nasional (HKN). Dengan begitu, HKN akan diperingati setiap tanggal 28 September.  \n" +
                    "\n" +
                    "Deklarasi Hari Komunitas Nasional dibacakan oleh Founder OptimisMe, Gerryl Besouw, salah satu gerakan community development bagi kalangan anak muda.\n" +
                    "\n" +
                    "\"Kami komunitas nasional dengan segala perbedaan, kita teruskan persatuan dengan motivasi yang murni, kita mengabdi bagi negeri. Jayalah kita, jayalah bangsa. Jakarta 28 September 2013,\" demikian dikatakan oleh Gerryl, disaksikan Menkominfo, di Jakarta Convention Center (JCC), Senayan, Jakarta, Sabtu (28/9/2013).\n" +
                    "\n" +
                    "Sementara itu, dalam sambutannya Tifatul menilai di Indonesia sinergi komunikasi masih lemah. Dengan adanya sejumlah komunitas, maka menurut Tifatul bisa disatukan.\n" +
                    "\n" +
                    "\"Setiap komunitas mempunyai kebebasan untuk mengespresikan aspirasinya. Tapi bagaimana kebebasan tersebut tidak mengganggu kebebasan orang lain. Kebebasan tersebut harus ada platform,\" tuturnya.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 September: Hari Rabies Sedunia[27]")){
            infoBulan.setText("Hari Rabies Sedunia (bahasa Inggris: World Rabies Day, sering disingkat WRD) adalah sebuah kampanye global yang diselenggarakan pada tanggal 28 September setiap tahun. Peringatan Hari Rabies Sedunia dilakukan untuk meningkatkan kesadaran masyarakat akan pencegahan dan pengendalian penyakit rabies.[1]\n" +
                    "\n" +
                    "Hari Rabies Sedunia mulai diselenggarakan pada tahun 2007.[2] Secara umum, pelaksanaan WRD dilakukan dengan sosialiasi kepada masyarakat dan vaksinasi rabies terhadap hewan, terutama anjing. Tujuan yang ingin dicapai oleh kampanye ini adalah menjadikan dunia bebas dari penyakit rabies pada tahun 2030.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 28 September: Hari Tunarungu Internasional[28]")){
            infoBulan.setText("-");
        }else if(tanggal.equalsIgnoreCase("Tanggal 29 September: Hari Sarjana Nasional")){
            infoBulan.setText("Pasti banyak dari Anda yang tidak menyangka kalau tanggal 29 September itu ternyata sebuah hari perayaan, bukan? Tanggal 29 September adalah hari peringatan Hari Sarjana Nasional. Apakah Anda pernah mendengarnya? Banyak sekali orang Indonesia sendiri yang tidak mengetahui hari tersebut karena memang tidak ada perayaan khusus ataupun menjadi tanggal merah di kalender sebagai hari libur nasional.\n" +
                    "\n" +
                    "Hari Sarjana Nasional diperingati sebagai sebuah penghargaan bagi para sarjana strata yang telah lulus dan menjadi bagian dalam generasi pembangun bangsa. Sarjana strata adalah gelar yang dicapai oleh orang yang telah berhasil menamatkan pendidikan tingkat akhir pada perguruan tinggi. Dengan adanya hari perayaan ini, diharapkan agar bangsa Indonesia menjadi lebih mengintrospeksi diri lagi pada soal pendidikan akademik dan menjadi suatu motivasi tersendiri bagi masyarakat Indonesia. Apalagi, sekarang sarjana strata 1 (S1) sudah menjadi standar tingkat pendidikan bagi kebanyakan pekerjaan maupun perusahaan.\n" +
                    "\n" +
                    "Namun, hingga saat ini belum ada yang tahu pasti mengenai sejarah bagaimana terciptanya Hari Sarjana Nasional. Tetapi, biarkan itu menjadi suatu hal yang tak terpecahkan, yang penting, dengan adanya Hari Sarjana Nasional, kita menjadi bisa lebih aware lagi dengan pendidikan bangsa ini. Oleh karena itu, mari kita gunakan ilmu pengetahuan kita untuk memberi manfaat yang berguna bagi bangsa kita sendiri, Indonesia.\n" +
                    "\n" +
                    "Sekarang kita sudah tahu kalau hari ini tidak kalah pentingnya dengan hari-hari nasional lainnya, bukan? Jadi, ayo raih impian dan buat negeri kita bangga! Selamat Hari Sarjana Nasional!");
        }else if(tanggal.equalsIgnoreCase("Tanggal 29 September: Hari Jantung Sedunia[29]")){
            infoBulan.setText("Tanggal 29 September, setiap tahunnya, seluruh dunia memperingati World Heart Day (WHD) atau Hari Jantung Sedunia. Tahun ini, WHD diperingati dengan promosi pentingnya cek kardiovaskular secara berkala untuk kesehatan jantung.\n" +
                    "\n" +
                    "Penyakit kardiovaskuler (penyakit jantung dan stroke) adalah penyebab kematian nomor satu di dunia. Penyakit ini telah memakan korban sebanyak 17,3 juta orang setiap tahunnya. Di Indonesia, penyakit ini masih menjadi penyebab kematian tertinggi sehingga seluruh masyarakat perlu mengambil peran dalam mencegah tingginya angka kesakitan dan kematian. Penyakit jantung masih menjadi berita buruk karena merupakan pembunuh nomor satu. Namun, berita baiknya, penyakit jantung sangat mungkin untuk bisa dicegah. Seluruh masyarakat perlu bergerak bersama. Seperti Kementerian Kesehatan dengan profesional kesehatan yang telah membentuk komite nasional untuk membuat program pencegahan penyakit jantung jangka panjang agar bisa menurunkan angka kesakitan dan kematian. Menyambut WHD ini, upaya edukasi ditargetkan untuk membuat masyarakat paham penyakit jantung sampai tahu bagaimana menangani korban agar cepat ditolong.\n" +
                    "\n" +
                    "Sosialisasi dan diseminasi\n" +
                    "\n" +
                    "Tingginya angka kematian penyakit jantung di Indonesia membuat Kementerian Kesehatan Republik Indonesia (Kemenkes RI) terus menggiatkan pencegahan dini penyakit jantung. Awal tahun ini sudah dilakukan beragai langkah konkret antara lain dengan melakukan  sosialisasi dan diseminasi di  berbagai media cetak, elektronik, dan media lainnya serta pemasangan spanduk dan umbul-umbul. Kemenkes juga membuat surat edaran kepada seluruh dinas kesehatan provinsi di Indonesia terkait Hari Jantung Sedunia untuk melakukan promosi kesehatan, deteksi dini, dan kerjasama dengan LSM untuk melakukan kegiatan yang melibatkan masyarakat. Pesan tersebut disampaikan dalam acara Peringatan Hari Jantung Sedunia yang diselenggarakan Kemenkes RI, di Gedung D lantai 4, Direktorat Jenderal Pencegahan dan Pengendalian Penyakit Tidak Menular (P2PL). Dalam acara itu dihadiri berbagai narasumber, yakni dr. Lily S Sulistyowati, MM, Direktur P2PL, Dr, dr, Ismoyo Sunu, SpJP (K), FIHA, FasCC sebagai Ketua Perhimpunan Dokter Spesialis Kardiovaskular Indonesia, dan dr. Oenedo Gumarang, MPHM penderita penyakit jantung.\n" +
                    "\n" +
                    "Rekor Muri Cek Kesehatan Jantung\n" +
                    "\n" +
                    "World Heart Day (WHD) atau Hari Jantung Sedunia pada tanggal 29 September. Tahun ini  Hari Jantung Sedunia diperingati dengan promosi utamanya teliti kardiovaskular dengan cara berkala untuk kesehatan jantung. Ketua Perhimpunan Spesialis Kardiovaskuler Indonesia (PERKI) Dr dr Ismoyo Sunu, SpJP (K), FIHA, FasCC, mengingatkan kalau penyakit jantung masihlah jadi kabar buruk lantaran adalah pembunuh nomer satu. Tetapi, kabar baiknya, penyakit jantung begitu mungkin saja untuk dapat dihindari. \"Semua orang-orang perlu bergerak bersama-sama.\n" +
                    "\n" +
                    "Contohnya  Kementerian Kesehatan dengan profesional kesehatan yang sudah membuat komite nasional untuk bikin program mencegah penyakit jantung periode panjang dengan tujuan dapat menurunkan angka kesakitan serta kematian, demikian disampaikan oleh Dr. dr. Ismouo Sunu, SpJP (K), FIHA, FasCC. Usaha edukasi ditargetkan untuk membuat orang-orang memahami penyakit jantung. Mereka akan tahu tahu bagaimana mengatasi korban supaya cepat ditolong, \" demikian disampaikan dalam acara kampanye Hari Jantung Sedunia di, bilangan Senayan, Jakarta. Yayasan Jantung Indonesia (YI) yang menginisiasi acara kampanye tersebut menyelenggarakan perayaan tersebut secara serentak di 15 kota besar di Indonesia. Pemecahan Rekor Muri untuk pemeriksaan kesehatan gratis dengan peserta terbanyak se-Indonesia pun dibuat untuk mensosialisasikan pentingnya pemeriksaan kesehatan jantung. \"Pemeriksaan secara rutin tekanan darah dan gula darah diharapkan dapat mengingatkan masyarakat betapa pentingnya menjaga kesehatan tekanan darah dan juga gula darah. Selain itu kami masyarakat tetap waspada akan ancaman penyakit kardiovaskular yang dapat menyerang siapa saja tanpa memandang jenis kelamin dan juga usia,\" pesan Ketua Umum Yayasan Jantung Indo (YJI), Ibu Syahlina Zuhal, pada kesempatan yang sama.");
        }else if(tanggal.equalsIgnoreCase("Tanggal 30 September: Hari Peringatan Gerakan 30 September 1965l")){
            infoBulan.setText("Gerakan 30 September (dalam dokumen pemerintah tertulis Gerakan 30 September/PKI, sering disingkat G30S/PKI), Gestapu (Gerakan September Tiga Puluh), atau juga Gestok (Gerakan Satu Oktober) adalah sebuah peristiwa yang terjadi selewat malam pada tanggal 30 September sampai awal bulan selanjutnya (1 Oktober) tahun 1965 ketika tujuh perwira tinggi militer Indonesia beserta beberapa orang yang lain dibunuh dalam suatu usaha kudeta (yang hampir sekaligus).[1] ");
        }
    }
}
