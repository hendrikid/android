package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

import java.util.ArrayList;

public class Januari extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter tampilan_data; //variabel yg akan digunakan untuk mengatur tampilan diuser interface
    private String[] Daftar_Tanggal={
            "Tanggal 1 Januari : Tahun Baru Masehi", "Tanggal 3 Januari : Hari Departemen Agama Republik Indonesia", "Tanggal 5 Januari: Hari Korps Wanita Angkatan Laut", "Tanggal 10 Januari: Hari Gerakan Satu Juta Pohon", "Tanggal 10 Januari: Hari Tritura", "Tanggal 10 Januari: Hari Lingkungan Hidup Indonesia", "Tanggal 15 Januari: Hari Peristiwa Laut dan Samudera atau Hari Dharma Samudera","Tanggal 25 Januari: Hari Gizi Nasional", "Tanggal 25 Januari: Hari Kusta Internasional", "Tanggal 26 Januari: Hari Kepabeanan Internasional"
    };
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_januari);
        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Januari); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), Hasil.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("januari", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
