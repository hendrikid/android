package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Juli extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={" Tanggal 1 Juli: Hari Bhayangkara",
            " Tanggal 1 Juli: Hari Buah",
            " Tanggal 2 Juli: Hari Kelautan Nasional",
            " Tanggal 5 Juli: Hari Bank Indonesia",
            " Tanggal 9 Juli: Hari Satelit Palapa",
            " Tanggal 12 Juli: Hari Koperasi",
            " Tanggal 14 Juli: Hari Pajak",
            " Tanggal 22 Juli: Hari Kejaksaan",
            " Tanggal 23 Juli: Hari Anak Nasional",
            " Tanggal 23 Juli: Hari Komite Nasional Pemuda Indonesia (KNPI)",
            " Tanggal 29 Juli: Hari Bhakti TNI Angkatan Udara",
            " Tanggal 31 Juli: Hari Lahir Korps Pelajar Islam Indonesia (PII) Wati"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juli);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Juli); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilJuli.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("juli", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
