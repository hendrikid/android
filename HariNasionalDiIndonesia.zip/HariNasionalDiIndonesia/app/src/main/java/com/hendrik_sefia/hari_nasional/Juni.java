package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Juni extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 1 Juni: Hari Lahir Pancasila",
            "Tanggal 1 Juni: Hari Perlindungan Anak-anak Sedunia[21]",
            "Tanggal 1 Juni: Hari Susu Nusantara[22]",
            "Tanggal 3 Juni: Hari Pasar Modal Indonesia",
            "Tanggal 5 Juni: Hari Lingkungan Hidup Sedunia",
            "Tanggal 8 Juni: Hari Laut Sedunia",
            "Tanggal 10 Juni: Hari Media Sosial",
            "Tanggal 15 Juni: Hari Demam Berdarah Dengue ASEAN[23]",
            "Tanggal 17 Juni: Hari Dermaga",
            "Tanggal 21 Juni: Hari Krida Pertanian",
            "Tanggal 22 Juni: Hari Ulang Tahun Kota Jakarta (sejak tahun 1527)",
            "Tanggal 24 Juni: Hari Bidan Nasional",
            "Tanggal 26 Juni: Hari Anti Narkoba",
            "Tanggal 29 Juni: Hari Keluarga Berencana"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_juni);
        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Juni); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilJuni.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("juni", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
