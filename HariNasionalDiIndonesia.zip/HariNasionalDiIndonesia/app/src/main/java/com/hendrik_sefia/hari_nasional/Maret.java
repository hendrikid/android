package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Maret extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 1 Maret: Hari Kehakiman Nasional",
            "Tanggal 1 Maret: Hari Peringatan Serangan Umum di Yogyakarta",
            "Tanggal 6 Maret: Hari Komando Strategis Angkatan Darat (Kostrad)",
            "Tanggal 8 Maret: Hari Wanita/Perempuan Internasional",
            "Tanggal 9 Maret: Hari Musik Nasional",
            "Tanggal 10 Maret: Hari Persatuan Artis Film Indonesia (Parfi)",
            "Tanggal 11 Maret: Hari Surat Perintah Sebelas Maret (Supersemar)",
            "Tanggal 21 Maret: Hari Sindrom Down",
            "Tanggal 21 Maret: Hari Teater Boneka",
            "Tanggal 21 Maret: Hari Penghapusan Diskriminasi Rasial Sedunia",
            "Tanggal 22 Maret: Hari Air Sedunia",
            "Tanggal 23 Maret: Hari Meteorologi Sedunia",
            "Tanggal 24 Maret: Hari Peringatan Bandung Lautan Api",
            "Tanggal 27 Maret: Hari Teater Sedunia",
            "Tanggal 27 Maret: Hari Klub Wanita Internasional (bahasa Inggris: Women International Club Day - WIC)",
            "Tanggal 29 Maret: Hari Filateli Indonesia. Hari Lahir Kesatuan Aksi Mahasiswa Muslim Indonesia (KAMMI).",
            "Tanggal 30 Maret: Hari Film Nasional"};

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_maret);
        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Maret); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilMaret.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("maret", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
    ////}
}

