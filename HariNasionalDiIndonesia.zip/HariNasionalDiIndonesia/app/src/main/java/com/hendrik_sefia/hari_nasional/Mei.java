package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Mei extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 1 Mei: Hari Peringatan Pembebasan Irian Barat",
            "Tanggal 1 Mei: Hari Buruh Sedunia",
            "Tanggal 2 Mei: Hari Pendidikan Nasional (Hardiknas)[17]",
            "Tanggal 5 Mei: Hari Lembaga Sosial Desa (LSD)",
            "Tanggal 10 Mei: Hari Lupus Sedunia",
            "Tanggal 11 Mei: Hari POM - TNI (?)",
            "Tanggal 15 Mei: Hari Korps Resimen Mahadjaya/ Jayakarta (Menwa Jayakarta),",
            "Tanggal 16 Mei: Hari Wanadri",
            "Tanggal 17 Mei: Hari Buku Nasional",
            "Tanggal 19 Mei: Hari Korps Cacat Veteran Indonesia",
            "Tanggal 20 Mei: Hari Kebangkitan Nasional[18], Hari Bakti Dokter Indonesia[19]",
            "Tanggal 21 Mei: Hari Peringatan Reformasi",
            "Tanggal 23 Mei: Hari Penyu Sedunia",
            "Tanggal 29 Mei: Hari Keluarga, Hari Lanjut Usia[20]",
            "Tanggal 31 Mei: Hari Tanpa Tembakau Sedunia"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_mei);
        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Mei); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilMei.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("mei", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
