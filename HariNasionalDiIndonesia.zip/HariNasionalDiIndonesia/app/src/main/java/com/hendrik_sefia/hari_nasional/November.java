package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class November extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 1 November: Hari Inovasi Indonesia",

            "Tanggal 5 November: Hari Cinta Puspa dan Satwa Nasional[41]",
            "Tanggal 10 November: Hari Pahlawan (Indonesia)",
            "Tanggal 10 November: Hari Ganefo",
            "Tanggal 11 November: Hari Bangunan Indonesia[42]",
            "Tanggal 12 November: Hari Ayah Nasional",
            "Tanggal 12 November: Hari Kesehatan Nasional",
            "Tanggal 14 November: Hari Brigade Mobil (BRIMOB)",
            "Tanggal 14 November: Hari Diabetes internasional",
            "Tanggal 16 November: Hari Toleransi Internasional",
            "Tanggal 19 November: Hari Pria/Laki-laki Internasional",
            "Tanggal 20 November: Hari Anak-anak Sedunia[43]",
            "Tanggal 21 November: Hari Pohon",
            "Tanggal 22 November: Hari Perhubungan Darat",
            "Tanggal 25 November: Hari Guru[44]",
            "Tanggal 28 November: Hari Menanam Pohon Indonesia[45]",
            "Tanggal 28 November: Hari Dongeng Nasional",
            "Tanggal 29 November: Hari Korps Pegawai Republik Indonesia (KORPRI)"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_november);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_November); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilNovember.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("november", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
