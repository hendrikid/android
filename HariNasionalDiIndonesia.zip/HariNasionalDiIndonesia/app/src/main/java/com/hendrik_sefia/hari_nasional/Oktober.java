package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class Oktober extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal (Setiap Hari Senin Pertama Oktober): Hari Habitat",
            "Tanggal 1 Oktober: Hari Kesaktian Pancasila",
            "Tanggal 1 Oktober: Hari Bea dan Cukai[30]",
            "Tanggal 2 Oktober: Hari Batik Nasional[31]",
            "Tanggal 4 Oktober: Hari Hewan Sedunia [1]",
            "Tanggal 5 Oktober: Hari Tentara Nasional Indonesia (TNI)",
            "Tanggal (Setiap Hari Kamis Kedua Oktober): Hari Mata Sedunia[32]",
            "Tanggal 10 Oktober: Hari Kesehatan Jiwa",
            "Tanggal 12 Oktober: Hari Museum Nasional",
            "Tanggal 12 Oktober: Hari Radang Sendi (Artritis) Sedunia[33]",
            "Tanggal 15 Oktober: Hari Hak Asasi Binatang",
            "Tanggal 16 Oktober: Hari Parlemen Indonesia[34]",
            "Tanggal 16 Oktober: Hari Pangan Sedunia",
            "Tanggal 22 Oktober: Hari Santri Nasional[35]",
            "Tanggal 24 Oktober: Hari Dokter Nasional [36]",
            "Tanggal 24 Oktober: Hari Perserikatan Bangsa-Bangsa (PBB)",
            "Tanggal 24 Oktober: Hari Polio Sedunia[37]",
            "Tanggal 27 Oktober: Hari Listrik Nasional[38]",
            "Tanggal 27 Oktober: Hari Penerbangan Nasional",
            "Tanggal 27 Oktober: Hari Narablog Nasional",
            "Tanggal 28 Oktober: Hari Sumpah Pemuda",
            "Tanggal 29 Oktober: Hari Stroke Sedunia[39]",
            "Tanggal 30 Oktober: Hari Keuangan[40]"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_oktober);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_Oktober); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilOktober.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("oktober", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
