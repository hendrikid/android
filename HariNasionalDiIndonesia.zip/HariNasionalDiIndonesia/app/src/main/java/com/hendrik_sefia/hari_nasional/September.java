package com.hendrik_sefia.hari_nasional;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class September extends AppCompatActivity {
    private ListView listView;
    private ArrayAdapter<String> tampilan_data;
    private String[] Daftar_Tanggal={"Tanggal 1 September: Hari Buruh",
            "Tanggal 1 September: Hari Polisi Wanita (Polwan)",
            "Tanggal 8 September: Hari Aksara",
            "Tanggal 8 September: Hari Pamong Praja",
            "Tanggal 9 September: Hari Olahraga Nasional[25]",
            "Tanggal 11 September: Hari Radio Republik Indonesia (RRI)",
            "Tanggal 11 September: Hari Peringatan Serangan 11 September 2001",
            "Tanggal 17 September: Hari Palang Merah Indonesia",
            "Tanggal 17 September: Hari Perhubungan Nasional",
            "Tanggal 21 September: Hari Perdamaian Dunia[26]",
            "Tanggal 23 September: Hari Bahasa Isyarat Internasional",
            "Tanggal 24 September: Hari Tani",
            "Tanggal 26 September: Hari Statistik",
            "Tanggal 27 September: Hari Pos Telekomunikasi Telegraf (PTT)",
            "Tanggal 28 September: Hari Kereta Api",
            "Tanggal 28 September: Hari Komunitas Nasional",
            "Tanggal 28 September: Hari Rabies Sedunia[27]",
            "Tanggal 28 September: Hari Tunarungu Internasional[28]",
            "Tanggal 29 September: Hari Sarjana Nasional",
            "Tanggal 29 September: Hari Jantung Sedunia[29]",
            "Tanggal 30 September: Hari Peringatan Gerakan 30 September 1965l"};
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_september);

        getSupportActionBar().setTitle("Daftar Tanggal dan Nama Hari");

        listView=(ListView) findViewById(R.id.Tanggal_September); //mengaktifkan listview
        tampilan_data=new ArrayAdapter<String>(this, android.R.layout.simple_list_item_1,Daftar_Tanggal); //mengatur tampilan bulan dilistview
        listView.setAdapter(tampilan_data); //menampilkan data

        listView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                String tanggal=listView.getItemAtPosition(position).toString();//mendapatkan posisi tanggal yang diklik
                Intent intent= new Intent(getApplicationContext(), HasilSeptember.class);//mengaktifkan intent dan mengatur tujuan keactivity hasil
                intent.putExtra("september", tanggal);//membuat id bulan yang akan digunakan untuk meminta informasi tanggal di hasil

                startActivity(intent);//membuka hasil
            }
        });
    }
}
